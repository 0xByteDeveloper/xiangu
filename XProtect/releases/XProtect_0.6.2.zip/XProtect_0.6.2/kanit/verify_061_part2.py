#!/usr/bin/env python3
# verify_061_part2.py — bytecode içerik karşılaştırması (add eax,imm hedefi)
import struct, hashlib

def load(path):
    d = open(path, 'rb').read()
    e = struct.unpack_from('<I', d, 0x3C)[0]
    coff = e + 4
    mach, nsec, ts, symtab, nsym, opt_size, chars = struct.unpack_from('<HHIIIHH', d, coff)
    opt = coff + 20
    sec_off = opt + opt_size
    secs = []
    for i in range(nsec):
        o = sec_off + 40 * i
        vs, va, rs, ra = struct.unpack_from('<IIII', d, o + 8)
        secs.append((va, max(vs, rs), ra, d[o:o+8].rstrip(b'\0').decode('latin1')))
    def r2o(rva):
        for va, sz, ra, nm in secs:
            if va <= rva < va + sz: return ra + (rva - va)
        return None
    return d, r2o

files = [
    ('A-baseline(CALISIYOR)', '/home/z/my-project/upload/metin2client_vmp_d7610_Ultra.exe', 0x5468C8),
    ('B-060broken(BOZUK)',    '/home/z/my-project/upload/metin2client_vmp_d7610_Ultra_loaderCRC.exe', 0x548730),
    ('C-061fixed',            '/tmp/my-project/download/XProtect/metin2client_vmp_d7610_Ultra_loaderCRC_061.exe', 0x548738),
]
blobs = {}
for label, path, bcrva in files:
    d, r2o = load(path)
    off = r2o(bcrva)
    bc = d[off:off+32]
    blobs[label] = bc
    print(f"{label}: bc@0x{bcrva:X} ilk32B={bc.hex()}")
    # cfg alanı: bc-0x48 ve bc-0x40
    for delta in (0x48, 0x40):
        co = r2o(bcrva - delta)
        print(f"   bc-0x{delta:X}: {d[co:co+12].hex(' ')}")
print()
print("A==C (ilk16B):", blobs['A-baseline(CALISIYOR)'][:16] == blobs['C-061fixed'][:16])
print("A==B (ilk16B):", blobs['A-baseline(CALISIYOR)'][:16] == blobs['B-060broken(BOZUK)'][:16])
print("B ilk8B sıfır mı:", blobs['B-060broken(BOZUK)'][:8] == b'\x00'*8)
# A'nın bytecode'u B/C'de başka bir yerde mi? (taşma sonrası kayma)
dA, rA = load(files[0][1])
dB, rB = load(files[1][2 - 1])
target = blobs['A-baseline(CALISIYOR)'][:16]
dBfull = open(files[1][1], 'rb').read()
idx = dBfull.find(target)
print("A'nın bc16'sı B dosyasında ham olarak var mı:", hex(idx) if idx >= 0 else "YOK")
