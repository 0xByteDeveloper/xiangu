#!/usr/bin/env python3
# verify_061_loadercrc.py — 0.6.1 loaderCRC duzeltmesinin BAGIMSIZ dogrulamasi
# 3 dosya: baseline(CALISIYOR) / 060-broken(BOZUK) / 061-fixed
# Zincir: D7610 jmp -> stub -> add eax,imm (bc ref) -> bytecode ilk 16B + cfg XRT1
import struct, sys, hashlib

def read_pe(path):
    d = open(path, 'rb').read()
    e = struct.unpack_from('<I', d, 0x3C)[0]
    assert d[e:e+4] == b'PE\0\0', 'PE imza yok'
    coff = e + 4
    mach, nsec, ts, symtab, nsym, opt_size, chars = struct.unpack_from('<HHIIIHH', d, coff)
    opt = coff + 20
    magic = struct.unpack_from('<H', d, opt)[0]
    is64 = magic == 0x20B
    ep = struct.unpack_from('<I', d, opt + 16)[0]
    sec_off = opt + opt_size
    secs = []
    for i in range(nsec):
        o = sec_off + 40 * i
        name = d[o:o+8].rstrip(b'\0').decode('latin1')
        vs, va, rs, ra = struct.unpack_from('<IIII', d, o + 8)
        secs.append(dict(name=name, vs=vs, va=va, rs=rs, ra=ra))
    return dict(d=d, mach=mach, is64=is64, ep=ep, secs=secs, path=path)

def rva2off(pe, rva):
    for s in pe['secs']:
        if s['va'] <= rva < s['va'] + max(s['vs'], s['rs']):
            return s['ra'] + (rva - s['va'])
    return None

def sec_of(pe, rva):
    for s in pe['secs']:
        if s['va'] <= rva < s['va'] + max(s['vs'], s['rs']):
            return s['name']
    return '?'

def analyze(path, label):
    pe = read_pe(path)
    d = pe['d']
    print(f"=== {label} ===")
    print(f"  machine=0x{pe['mach']:X} boyut={len(d)} EP_rva=0x{pe['ep']:X} ({sec_of(pe,pe['ep'])})")
    print(f"  md5={hashlib.md5(d).hexdigest()}")
    # D7610 jmp
    off = rva2off(pe, 0xD7610)
    b = d[off:off+5]
    if b[0] != 0xE9:
        print(f"  D7610: {b.hex(' ')} (jmp DEGIL — govde yerinde)")
        return
    tgt = 0xD7610 + 5 + struct.unpack_from('<i', b, 1)[0]
    print(f"  D7610: E9 -> 0x{tgt:X} ({sec_of(pe,tgt)})")
    # stub icindeki add eax,imm32 (0x05) adaylari
    soff = rva2off(pe, tgt)
    stub = d[soff:soff+0x90]
    adds = []
    for i in range(len(stub) - 5):
        if stub[i] == 0x05:
            imm = struct.unpack_from('<I', stub, i + 1)[0]
            if 0x400000 < imm < 0x800000:
                adds.append(imm)
    print(f"  stub add eax,imm adaylari: {[hex(x) for x in adds[:4]]}")
    if len(adds) < 2:
        print("  bc referansi bulunamadi")
        return
    bc_rva = adds[1]
    bcoff = rva2off(pe, bc_rva)
    bc16 = d[bcoff:bcoff+16]
    cfgoff = rva2off(pe, bc_rva - 0x48)
    cfg8 = d[cfgoff:cfgoff+8] if cfgoff else b''
    print(f"  bytecode @0x{bc_rva:X} ({sec_of(pe,bc_rva)}): ilk16B={bc16.hex()}")
    print(f"  bc-0x48 (cfg): {cfg8.hex(' ')}  (XRT1=58 52 54 31 beklenir)")
    zcount = sum(1 for x in bc16 if x == 0)
    verdict = 'TAM' if zcount < 8 else 'EZILMIS (sifir-agirlikli)'
    if bc16[:8] == b'\x00' * 8:
        verdict = 'ILK 8B SIFIR — CFG TASMASI KANITI'
    print(f"  SONUC: {verdict}")
    return bc16

a = analyze('/home/z/my-project/upload/metin2client_vmp_d7610_Ultra.exe', 'A) BASELINE (Ultra, CALISIYOR)')
b = analyze('/home/z/my-project/upload/metin2client_vmp_d7610_Ultra_loaderCRC.exe', 'B) 0.6.0 loaderCRC (BOZUK — kullanici raporu)')
import os
p61 = '/tmp/my-project/download/XProtect/metin2client_vmp_d7610_Ultra_loaderCRC_061.exe'
c = analyze(p61, 'C) 0.6.1 loaderCRC (duzeltme sonrasi)') if os.path.exists(p61) else None

print("\n=== KARSILASTIRMA ===")
if a and c:
    print(f"  A==C (bc ilk16B): {'EVET — duzeltme TAM' if a == c else 'HAYIR: ' + a.hex() + ' vs ' + c.hex()}")
if a and b:
    print(f"  A==B (bc ilk16B): {'EVET (beklenmez!)' if a == b else 'HAYIR — 0.6.0 bozuk (beklenen)'}")
