# XProtect 0.6.2 — Değişiklik Günlüğü

## Kritik düzeltme: Bölge modunda sessiz yanlış-sonuç sınıfı (duru RED)

### Bulgu (bağımsız doğrulama sırasında, 0.6.1 doğrulaması yapılırken)
0.6.1 loaderCRC düzeltmesi doğrulanırken kurulan **fonksiyonel regresyon
testi** (SDK işaretli exe + ULTRA/loaderCRC + wine), loaderCRC düzeltmesinin
DOĞRU olduğunu **ve** 0.5.1'den beri süren ikinci bir sessiz hata sınıfını
yakaladı:

```
sdk_u bölgesi (U -> V düşüşü, bölge kipi):
  beklenen sdk_u(0x1234) = 0x1221
  üretilen              = 0            <- sessiz yanlış sonuç
  (sdk_print c'yi kontrol etmediği için exit=42 "sahte-başarı" ile geçiyordu)
```

### Kök neden (kaynak + Unicorn-düzeyi analiz)
VM'nin rsp-uzayı ÖZELDİR: `mem_addr[rsp] = regs[RSP] - VM_DELTA + disp` ve
`regs[RSP]` girişte stub giriş rsp'si ile başlar → tüm rsp-görelative
erişimler VM_DELTA (x64 0x600 / x86 0x420) kadar gerçek yığının altına
gider.

- **Fonksiyon kipinde TUTARLI-SANAL**: okuma/yazma aynı sanal tabanı
  kullanır, gövde kapalıdır → sonuç doğru (kanıt: f_stack=0x1221, exit=42).
- **Bölge kipinde (SDK işareti / U→V düşüşü) KIRILGAN**: korumasız devam
  kodu GERÇEK yığını okur → VM yazmaları "kaybolur" (s=0, c=0).
- ebp-görelative gövdeler (metin2 D7610 gibi) etkilenmez — kullanıcı
  kanıtıyla uyumlu (damage çalışıyor).
- Global (rip-relative) yazmalar etkilenmez (kanıt: g=0x1221 ✓).

### Düzeltme (0.6.2)
1. **Bölge güvenlik guard'ı** (engine_lift.cpp): bölge kipinde rsp-görelative
   bellek erişimi / rsp yeniden-eşleme (mov rsp,x / mov x,rsp / leave)
   = **DURU RED** (0.5.1 "sessiz yanlış sonuç yerine duru RED" geleneği).
   Bölge korunmaz, ORİJİNAL kod çalışır → davranış HER ZAMAN doğru.
   Gerçek-yığın bölge kipi (özel ctx + yigin-değiştirmeli stub) 0.8.0'a
   kaydedildi.
2. **OZET sayacı**: U→V düşüşü artık V derlemesi olarak da sayılıyor
   (V=0 görünümü yanıltıcıydı).
3. Sürüm 0.6.1 → 0.6.2.

## Doğrulama kanıtları (wine64 + Xvfb, 2026-11-09)
1. **GUARD**: sdk_r_s (yığın-yazmalı bölge) → `[RED] bolge rsp-goreli
   erisim` → native → **s=0x1221 DOĞRU**; sdk_r_g (global-yazmalı) korumalı
   → **g=0x1221 DOĞRU**; exit=42.
2. **SDK TESTİ**: sdk_rt_x64 + U/V/M işaretleri + --loadercrc --filecrc →
   `a=78 b=0x16f9 c=0x1221 d=81` (0.6.1'de c=0 idi!) → **exit=42**.
3. **REGRESYON-YOK**: 0.6.1 ve 0.6.2 aynı CLI ile metin2 D7610
   U+loaderCRC+fileCRC → **md5 BİREBİR** (ecd79d2d…); cfg hâlâ bc-0x48'de
   (XRT1), bytecode'un ilk 16 baytı ezik DEĞİL (0.6.1 fix korundu).
4. **FONKSİYON-KİPİ**: isol42 f_stack/f_reg V → 0x1221/0x1221 → exit=42
   (fonksiyon kipi guard'dan etkilenmez).
5. **PACK**: mini42c --pack --loadercrc --filecrc → LZMA akışı + unpack +
   CRC zinciri → **exit=42**.
6. **SELFTEST OK** (x64, Xvfb).
7. x86: aynı kaynakla XProtectUI32.exe derlendi (guard mimariden bağımsız;
   REG_RSP==ESP==4). Bu ortamda wine wow64 (syswow64) eksik olduğundan
   PE32 wine koşusu yapılamadı — x86 kanıtı Unicorn tabanlı önceki
   doğrulamalara dayanır.

## Sürüm damgası
- XPROTECT_VERSION 0.6.1 → 0.6.2
