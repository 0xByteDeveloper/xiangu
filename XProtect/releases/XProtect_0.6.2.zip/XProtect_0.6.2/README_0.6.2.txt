XProtect 0.6.2 — VMProtect 3.5.1 portu (C++ / Win32)
====================================================

0.6.2, 0.6.1'in loaderCRC düzeltmesini KORUR ve bağımsız fonksiyonel
regresyon testiyle bulunan "bölge modunda sessiz yanlış-sonuç" sınıfını
DURU RED ile kapatır.

Kullanıcı kanıtlı hata zinciri (özet):
  0.6.0  XCFG 0x40->0x48 rezerv taşması: ilk bytecode'un ilk 8 baytı
         eziliyordu -> metin2 ULTRA+loaderCRC = sessiz no-op (damage yok).
  0.6.1  Rezerv XCFG_SIZE_E=0x48 + cfg-sonrası bytecode doğrulaması
         (taşma varsa çıktı YAZILMAZ). Kullanıcı: "düzeldi".
  0.6.2  İKİNCİ hata sınıfı: bölge (SDK işareti / U->V düşüşü) kipinde
         VM'nin rsp-uzayı sanal olduğu için bölge yazmaları gerçek yığına
         gitmiyordu (sdk_u c=0 / isol43 s=0). Fonksiyon kipi tutarlı-sanal
         olduğundan etkilenmez. 0.6.2: bölge içinde rsp-görelative erişim
         = sesli RED -> bölge korunmaz, ORİJİNAL kod çalışır (davranış
         her zaman doğru). Gerçek-yığın bölge kipi 0.8.0'da.

İÇİNDEKİLER
  XProtectUI.exe        x64 GUI + CLI motor
  XProtectUI32.exe      x86 GUI + CLI motor
  xprotect_sdk.h        SDK işaret başlığı (B8 bölge işaretleri)
  source/XProtectUI_Source/  tam kaynak (zig ile derlenir: build_ui.sh)
  kanit/                doğrulama kanıtları (wine logları + test çiftleri)
  CHANGELOG_0.6.2.md    ayrıntılı değişiklik günlüğü

CLI KULLANIMI (örnekler)
  XProtectUI.exe --cli <giris.exe> <cikti.exe> --add 0xD7610:0xD766C:U \
      --loadercrc --filecrc
  XProtectUI.exe --cli <giris.exe> <cikti.exe> --sdkonly --loadercrc
  XProtectUI.exe --cli <giris.exe> <cikti.exe> --pack --loadercrc --filecrc
  Seçenekler: --type V|M|U, --add BAS:SON:MOD, --sdkonly/--nosdk,
  --loadercrc/--selfcrc/--textcrc/--filecrc, --pack, --stripfixups,
  --stripdebug, --import(--iat), --antidebug, --strenc, --memprot,
  --novmenc, --strength 0..3, --rt-nomsg/--rt-noexit

0.6.2 DOĞRULAMA KANITLARI (wine64)
  1. sdk yığın-yazmalı bölge -> DURU RED -> native -> 0x1221 DOĞRU
  2. sdk testi U/V/M + loaderCRC + fileCRC -> exit=42 (c=0x1221; 0.6.1'de 0)
  3. metin2 D7610 U+loaderCRC+fileCRC: 0.6.1 ile md5 BİREBİR (regresyon yok)
  4. fonksiyon-kipi V: f_stack/f_reg = 0x1221 -> exit=42
  5. pack+CRC: mini42c -> exit=42
  6. SELFTEST OK

SÜRÜM GEÇMİŞİ: 0.1.0 VM çekirdeği · 0.2.0 Win32 GUI · 0.3.0 mutasyon
çekirdeği · 0.4.x GUI tam kapsam + 3-mod gerçek ayrım · 0.5.0 runtime
katmanı (CRC) + SDK işaretleri · 0.5.1 boru-hattı regresyon fixi ·
0.6.0 LZMA packing + strip + XCFG 0x48 · 0.6.1 cfg-taşması fixi ·
0.6.2 bölge rsp-guard.
