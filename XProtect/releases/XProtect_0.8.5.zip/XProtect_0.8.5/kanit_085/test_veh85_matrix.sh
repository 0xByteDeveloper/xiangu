#!/bin/bash
# test_veh85_matrix.sh — 0.8.5 VEH/DRx yakalama diferansiyel matrisi (x64)
# 0.8.5 = 0.8.4 + K3 (GetThreadContext DR0-3).
# Beklenen (K3 ile degisenler *):
#   clean    -> TEMIZ  (rc=42)
#   ceveh    -> TEMIZ  (bos yabanci VEH — bilinli kapsam disi, 0.8.4 ayni)
#   gameveh  -> TEMIZ  (oyun-VEH tek-adim yutar — yanlis-pozitif YOK)
#   gamedrx* -> POISON (oyun kendi DRx — UniversalObfuscator 1:1 semantigi)
#   cevehdr* -> POISON (CE VEH + DR0 hwbp = KULLANICININ SENARYOSU — K3 FIX)
#   sw       -> POISON (K1: giris 0xCC ARMALI)
#   tfstep   -> POISON (K2: TF=1)
#   peb      -> POISON (PEB.BeingDebugged)
# Kanit: test/x64_wine_matris_085.txt
set -u
cd "$(dirname "$0")/XProtect_0.8.4/source/XProtectUI_Source"
ZIG="python3 -m ziglang"
WINE=/tmp/my-project/scripts/xp081/wine64x.sh
OUT=/home/z/my-project/scripts/xp085/test/x64_wine_matris_085.txt
TESTDIR=/home/z/my-project/scripts/xp085/test
: > $OUT

BIN=$TESTDIR/test_veh85.exe
echo "== [1/3] test_veh85.exe derle (zig cc x64) =="
$ZIG cc -O2 -target x86_64-windows-gnu -o $BIN $TESTDIR/test_veh85.c -lkernel32 2>> $OUT \
    || { echo "DERLEME HATASI" >> $OUT; cat $OUT; exit 1; }

echo "== [2/3] damage RVA =="
read RVA SZ <<< "$(python3 $TESTDIR/find_damage_rva.py $BIN)"
echo "damage RVA=0x$RVA size=0x$SZ" | tee -a $OUT
if [ "$RVA" = "0" ]; then echo "RVA BULUNAMADI" >> $OUT; exit 1; fi
END=$((0x$RVA + 0x$SZ))

echo "== [3/3] koru + kos (8 mod) =="
# XProtectUI GUI-subsystem: Xvfb ayni komut icinde (0.8.1 dersnotu)
Xvfb :97 -screen 0 1024x768x16 >/dev/null 2>&1 &
XVFB_PID=$!
sleep 0.6
export DISPLAY=:97
for MODE in clean ceveh gameveh gamedrx cevehdr sw tfstep peb; do
  "$WINE" "Z:\\home\\z\\my-project\\scripts\\xp085\\XProtect_0.8.4\\source\\XProtectUI_Source\\XProtectUI.exe" \
      --cli "Z:\\home\\z\\my-project\\scripts\\xp085\\test\\test_veh85.exe" \
      "Z:\\home\\z\\my-project\\scripts\\xp085\\test\\v85_${MODE}.exe" \
      --add 0x$RVA:$(printf %X $END):U --antidebug > $TESTDIR/v85_${MODE}.log 2>&1
  RC=$?
  if [ ! -f $TESTDIR/v85_${MODE}.exe ]; then
      echo "x64 $MODE -> KORUMA BASARISIZ (engine rc=$RC)" >> $OUT
      tail -3 $TESTDIR/v85_${MODE}.log >> $OUT
      continue
  fi
  rm -f $TESTDIR/veh85_sonuc64.txt
  "$WINE" "Z:\\home\\z\\my-project\\scripts\\xp085\\test\\v85_${MODE}.exe" $MODE >> $OUT 2>&1
  RC=$?
  RES=$(cat $TESTDIR/veh85_sonuc64.txt 2>/dev/null | tail -1)
  RVAL=$(echo "$RES" | sed -n 's/.*r=\([-0-9]*\).*/\1/p')
  if   [ "$RVAL" = "3812" ]; then ST=CALISTI
  elif [ "$RVAL" = "-559038737" ]; then ST=DURDU
  else ST=BILINMEZ; fi
  echo "x64 $MODE -> mode-satiri: $RES  rc=$RC  $ST" >> $OUT
done
echo "== SONUC =="; cat $OUT
