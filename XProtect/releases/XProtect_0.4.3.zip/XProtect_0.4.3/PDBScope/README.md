# PDBScope 2.0.0

**PDB / MAP / PE sembol ve RVA analiz aracı** — sıfır bağımlılık, taşınabilir C++17.
Windows (VS2019 v142 / MinGW) ve Linux derlemelerini destekler; DIA SDK ya da
dbghelp **gerekmez** (ad çözümleme için dbghelp varsa kullanılır, yoksa ham ad
gösterilir).

v2.0.0 ile gelenler: **TPI/IPI fonksiyon imzaları**, **C13 kaynak satır
bilgisi**, **FPO çerçeve verisi**, **inline (satır içi) semboller**,
**derleyici/araç zinciri raporu**, `_NT_SYMBOL_PATH` desteği ve en önemlisi:
**`pdbless` — PDB OLMADAN fonksiyon bulma motoru** (IDA Pro / Ghidra başlangıç
analizi yaklaşımı, BrainMapCore'un doğrulanmış çok katmanlı güven yöntemi
evrenselleştirilerek).

```
RVA          VA  Bölüm  Boyut  Tip    Modül          İmza                     Kaynak                       Sembol
--------------------------------------------------------------------------------------------------------------------
0x13a0       -   .text    1c     FUNC   test.obj       int __cdecl (void)       ...inputs\test.cpp:16       main
```

---

## Hızlı başlangıç

```
pdbscope semboller metin2client.exe                 # PDB'yi otomatik bulur (GUID+yaş doğrular)
pdbscope pdbless metin2client.exe                   # PDB YOKSA: IDA/Ghidra tarzı fonksiyon bulma
pdbscope vftable metin2client.exe                   # sınıf + vftable dökümü (RTTI)
pdbscope semboller uygulama.exe --imza --satirlar   # imza + kaynak dosya:satır sütunları
```

## Komutlar

| Komut | İş |
|---|---|
| `semboller <hedef>` | PDB/MAP/PE'den RVA sembol listesi (varsayılan komut) |
| `pdbless <pe>` | **PDB olmadan** fonksiyon listesi + güven yüzdesi |
| `vftable <pe>` | RTTI sınıfları ve vftable → sanal fonksiyon eşlemesi |
| `bilgi <hedef>` | PDB üstverisi: GUID, akışlar, modüller, **derleyiciler, FPO, satır özeti** |
| `satir <hedef> <adr>` | RVA/VA → kaynak dosya:satır (+ sembol + FPO) |
| `kaynaklar <hedef>` | kaynak dosya listesi (satır sayıları, RVA aralıkları) |
| `turler <hedef>` | kullanıcı tipleri (class/struct/union/enum, boyutlar) |
| `bolum <pe>` | PE bölüm tablosu |
| `disa <pe>` / `ice <pe>` | export / import tabloları |
| `dizgiler <pe>` | ASCII + UTF-16 dizge taraması (RVA'lı) |
| `enyakin <hedef> <adr>` | adrese en yakın/içeren sembol — **PDB yoksa pdbless motoruna düşer** |
| `yardim` | tüm yardım |

## Önemli seçenekler

```
--imza        fonksiyon imzaları      (TPI/IPI: "int __cdecl Foo(int, char*)")
--satirlar    kaynak dosya:satır      (C13 line info)
--tur <T>     func | pub | thunk | data | label | inline | all
--min-guven <0-100>   pdbless güven eşiği (varsayılan 20)
--sinif <S>   pdbless sınıf filtresi: certain,high,medium,low[,reject]
--tum         pdbless'ta eşiğin altındakileri de göster
--vftable     pdbless çıktısına vftable dökümünü ekle
--no-rtti / --no-cagri / --no-prolog    pdbless katmanlarını kapat
--format <F>  table | csv | json | map
--filtre / --regex / --sirala / --limit / --modul / --cikti ...
```

---

## pdbless: PDB olmadan fonksiyon bulma

**Nasıl çalışır?** (IDA Pro / Ghidra ilk yüklemesindeki otomatik analizle aynı
fikir; beş bağımsız kanıt katmanı her aday adrese puan toplar)

| Katman | Kanıt | Güven |
|---|---|---|
| PE üstveri | `.pdata` (x64, kesin sınırlar), **GFIDS** (CFG), export'lar, **SafeSEH** (x86), TLS geri çağırmaları, **COFF sembol tablosu**, relocation hedefli kod işaretçileri, giriş noktası | 0.90–1.00 |
| RTTI | type_info tanımlayıcıları → Complete Object Locator → **vftable** → sanal fonksiyon başlangıçları (x86 mutlak VA / x64 4 bayt RVA farkı dahil) | 0.88 |
| Çağrı grafı | `E8/E9` doğrudan çağrı/jmp hedefleri + çağıran sayısı | 0.60 |
| Sınır | int3 (CC) dolguları, ret+n, kuyruk `jmp`, hizalama | 0.50–0.75 |
| Prolog | MSVC x86 (hotpatch `8B FF 55 8B EC`, `55 8B EC`, SEH, thiscall, FPO), MSVC x64 (`48 89 5C 24`, `sub rsp`, REX push), GCC/Delphi kalıpları | 0.60–0.99 |

**Doğrulama (yanlış pozitif süzme):**
- her katman ayrı puanlar; toplam = `enİyi × (1 + 0.1×ekKatman)` → **CERTAIN / HIGH / MEDIUM / LOW / REJECT** sınıflandırması
- **JCC-içi reddi**: koşullu dal hedefi olan ve güçlü kanıtı olmayan adaylar fonksiyon-ortası gürültüsü sayılır
- **aralık çakışması**: yüksek güvenli fonksiyonun içinde kalan düşük güvenli adaylar atılır (IDA'nın "function start wins" kuralı)

**Statik/dosyadan çalışır** — process'e bağlanmaya gerek yok. .rdata'daki
mutlak işaretçiler diskte tercih edilen ImageBase VA'larıdır; DLL'lerde yer
değiştirme .reloc tablosuyla çözülür. (BrainMapCore canlı process belleğinden
tarar; PDBScope aynı sonucu IDA/Ghidra gibi doğrudan dosyadan üretir —
i4MConsoleLoader'ın PEManualMapper simülasyonuna da gerek kalmaz.)

Örnek çıktı (üretilmiş Metin2 benzeri x86 test ikilisi):

```
[pdbscope pdbless metin2sim_x86.exe]
aday=26 kabul=22 | CERTAIN=22 HIGH=0 MEDIUM=0 LOW=0 redd=4
  pdata=0 export=3 gfids=0 safeseh=1 tls=0 coff=0 reloc=16 rtti(sınıf=4 vf=10)
RVA        Boyut   Guv  Sınıf   Tür      Ad [kanıt]
0x1030     0x10    100%  CERTAIN  vfunc    CPythonNetworkStream::vf0 [Boundary,Prologue,RTTI_VF,RelocPtr]
0x1031     ...     ...  (aynı sınıfın vf1, vf2, vf3 ...)
0x10e0     0x20    100%  CERTAIN  export   bar [Boundary,CallTarget,Export,Prologue]
0x1120     0x20    100%  CERTAIN  func     sub_1120 [Boundary,CallTarget,Prologue,RelocPtr,SafeSEH]
```

Gerçek ikililerde ölçümler:

| Hedef | mimari | kabul | kapsam | kaynaklar |
|---|---|---|---|---|
| üretilmiş metin2sim_x86.exe | x86 | 22/22 | tümü | RTTI 4 sınıf/10 vf, SafeSEH, export, reloc |
| testlib.dll (MinGW) | x64 | 30 | %91.7 | .pdata 11, COFF 8, export 6 |
| Sysinternals du64.exe | x64 | 766 | %79.9 | .pdata 539, reloc 59, import 24 |
| Sysinternals du.exe | x86 | 457 | — | reloc 225, prolog/sınır/cağrı |
| Electron ~200 MB | x64 | 464.533 | — | .pdata 373.113, export 2.877 (~28 sn) |

`enyakin` komutu PDB bulunamazsa otomatik pdbless motoruna düşer — crash
adreslerini PDB'siz ikililerde de çözersiniz.

---

## PDB tarafındaki yenilikler (v2)

- **İmzalar (`--imza`)**: S_GPROC32/S_GPROC32_ID tip indeksleri TPI/IPI'den
  çözülür: `LF_FUNC_ID`/`LF_MFUNC_ID` → kardeş depodaki `LF_PROCEDURE`/
  `LF_MFUNCTION` → dönüş tipi, çağrı konvansiyonu, argüman listesi. Primitif
  tipler, işaretçiler, diziler, const/volatile, sınıf/union/enum adları
  desteklenir. (`_ID` kayıtlarının tip alanı IPI yerine TPI'ye işaret eder —
  indeks aralıkları örtüştüğü için ayrım kayıt türünden yapılır.)
- **Kaynak satırları (`--satirlar`, `satir`, `kaynaklar`)**: modül C13
  altbölümleri (`DEBUG_S_LINES`/`FILECHKSMS`) çözülür. Dosya adları PDB
  `/names` dizge yığınından gelir (sonek paylaşımı desteklenir); karma türleri
  MD5(0x10)/SHA1(0x11)/SHA256(0x12). OMAP'li (artımlı bağlama) PDB'lerde
  satır RVA'ları da eşleştirilir.
- **FPO (`--fpo`, `bilgi`, `enyakin`)**: eski 16 baytlık FPO akışı (x86) ve
  yeni 32 baytlık FRAMEDATA akışı — çerçeve türü, yerel/param boyutları,
  prolog uzunluğu, SEH bayrakları.
- **Inline (`--tur inline`)**: S_INLINESITE genişletmeleri üst yordamlarıyla
  listelenir; adlar IPI kimlik kayıtlarından gelir (`configure_argv (inline)`).
- **Derleyici raporu (`bilgi`)**: S_COMPILE3 kayıtlarından derleyici adı,
  ön uç/arka uç sürümleri, /GS /hotpatch /LTCG /PGO bayrakları.
- **`turler`**: TPI'daki kullanıcı tipleri (tam tanım + ileri bildirim) boyut
  ve tip indeksiyle.
- **`_NT_SYMBOL_PATH`**: `;<ad>.pdb\<GUID><yaş>\<ad>.pdb` sembol sunucusu
  dizin düzeni de aranır.

## Derleme

**Visual Studio 2019:** `PDBScope.sln` → aç, `Release|x64` (veya Win32) →
derle. Platform araç takımı v142, C++17, `/utf-8`.

**CMake:**
```
cmake -B build -G "Visual Studio 16 2019" -A x64 && cmake --build build --config Release
cmake -B build && cmake --build build          # MinGW / Linux
```

**MinGW (tek dosya, statik):**
```
x86_64-w64-mingw32-g++ -std=c++17 -O2 -static -static-libgcc -static-libstdc++ -o pdbscope.exe src/*.cpp
```

Paket içinde hazır ikililer: `bin/win64/pdbscope.exe` (x64) ve
`bin/win32/pdbscope.exe` (x86) — yalnız UCRT + KERNEL32'e bağımlı (Win10+).

## Kaynak düzeni

```
src/
  msf.cpp/.h       MSF konteyneri (PDB "dosya sistemi")
  pdb.cpp/.h       DBI, modüller, sembol kayıtları, OMAP, FPO, COMPILE3
  types.cpp/.h     TPI/IPI tip deposu + imza çözümleyici
  lines.cpp/.h     C13 satır bilgisi (LINES/FILECHKSMS/STRINGTABLE)
  pdbless.cpp/.h   PDB'siz fonksiyon bulma motoru (5 katman + güven)
  pe.cpp/.h        PE üstverisi, export/import, reloc, rich header, PDB keşfi
  mapfile.cpp/.h   MSVC /MAP + GNU ld .map ayrıştırıcı
  demangle.cpp/.h  dbghelp tabanlı ad çözümleme (dinamik, opsiyonel)
  output.cpp/.h    tablo/CSV/JSON/MAP biçimlendirme
  main.cpp         CLI
  cvconst.h        CodeView sabitleri (microsoft-pdb cvinfo.h referansı)
tests/
  regression.sh    35 testlik regresyon paketi
  testapp.map      GNU/lld biçimi örnek map
  data/crafted/    üretilmiş test PE'leri (metin2sim_x86.exe)
```

## Doğrulama

- 35/35 regresyon testi (v1 geriye dönük uyumluluk + tüm v2 komutları)
- Gerçek MSVC PDB'leri (LLVM test ikilileri): imza/satır/FPO değerleri
  kaynak kodla birebir doğrulandı (`main` → `int __cdecl` @ test.cpp:16)
- Üretilmiş Metin2 benzeri x86 ikilisi: 22/22 fonksiyon, 4 RTTI sınıfı,
  SafeSEH, export — sıfır yanlış pozitif
- pdbless kendi Windows ikililerini analiz ederek öz-denetim (%95.7 kapsam)

## Sınırlar

- Portable PDB (.NET) desteklenmez (açık hata iletisi)
- PDB 2.00 (VC6 öncesi) okunmaz
- pdbless tahmini boyutlar .pdata olmayan (x86) ikililerde buluşsal;
  CERTAIN/HIGH listeler dışındaki sonuçları kullanırken kanıt sütununa bakın
- Satır içi genişletmelerin kesin RVA aralıkları (binary annotations) v2'de
  çözümlenmez; üst yordam RVA'sı gösterilir

## Lisans

MIT — bkz. `LICENSE`. Biçim bilgileri microsoft-pdb (Apache 2.0) ve LLVM
(Apache 2.0 w/ exceptions) projelerinin herkese açık belgelerinden
bağımsız olarak uygulanmıştır.
