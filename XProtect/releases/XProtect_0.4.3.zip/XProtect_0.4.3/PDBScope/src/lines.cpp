// ============================================================================
//  PDBScope — lines.cpp
//  C13 satır bilgisi (deneysel olarak LLVM test PDB'leriyle doğrulanan düzen):
//
//    AltBölüm: {u32 tür, u32 uzunluk}
//    LINES: {u32 offCon, u16 segCon, u16 flags, u32 cbCon}
//           + dosya blokları: {u32 offFile (CHKSMS gövdesi içi bayt ofseti),
//                              u32 nLines, u32 cbBlock}
//             satırlar: {u32 kodOfseti (offCon'e göre), u32 ham}
//               ham: satır:24 | delta:7 | ifadeBayrağı:1
//             sütunlar (flags & 1): {u16 başSütun, u16 sonSütun} * nLines
//    FILECHKSMS: girişler {u32 adOfseti, u8 tür(0x00/0x10/0x11/0x12),
//               karma baytları} — 4 bayt hizalı; adOfseti /names dizge
//               yığınına işaret eder (sonek paylaşımı olabilir).
//    STRINGTABLE (0xf3): varsa modül-yerel ad yığını (yedek kaynak).
//
//  kodOfseti offCon'e görelidir:
//    origRva = bölümler[segCon-1].VA + offCon + kodOfseti
//    rva     = OMAP(omapFrom, origRva)   (artımlı bağlama varsa)
// ============================================================================
#include "lines.h"

#include <algorithm>
#include <cstring>

#include "cvconst.h"
#include "util.h"

namespace pdbscope {

// ---------------------------------------------------------------------------
// Yardımcılar
// ---------------------------------------------------------------------------
static uint32_t rd32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) |
           ((uint32_t)p[3] << 24);
}
static uint16_t rd16(const uint8_t *p) {
    return (uint16_t)(p[0] | (p[1] << 8));
}

// karma türü -> bayt uzunluğu (0x10=MD5, 0x11=SHA1, 0x12=SHA256)
static size_t checksumLen(uint8_t kind) {
    switch (kind) {
    case 0x10: return 16;
    case 0x11: return 20;
    case 0x12: return 32;
    default: return 0;
    }
}

// ---------------------------------------------------------------------------
// Toplama
// ---------------------------------------------------------------------------
bool LineInfo::collect(const PdbFile &pdb, bool withInline, std::string *err) {
    (void)err;
    (void)withInline;
    files_.clear();
    lines_.clear();
    const MsfFile &msf = pdb.msf();

    for (const ModuleInfo &mi : pdb.modules()) {
        if (mi.stream == 0xFFFF || mi.stream >= msf.streamCount()) continue;
        if (mi.c13Bytes == 0) continue;
        std::vector<uint8_t> buf;
        if (!msf.materialize(mi.stream, buf, nullptr)) continue;

        // Modül akışı: [u32 imza + semboller: symBytes][C11][C13][globalRefs]
        size_t c13Off = (size_t)mi.symBytes + (size_t)mi.c11Bytes;
        if (c13Off + (size_t)mi.c13Bytes > buf.size()) continue; // bozuk sınır

        strTab_.clear();
        chksmsOffToFile_.clear();
        curModule_ = mi.index;
        parseModuleC13(pdb, mi, buf.data() + c13Off, (size_t)mi.c13Bytes);
    }

    // RVA'ya göre sırala
    std::sort(lines_.begin(), lines_.end(),
              [](const LineEntry &a, const LineEntry &b) {
                  if (a.rva != b.rva) return a.rva < b.rva;
                  return a.line < b.line;
              });
    return true;
}

bool LineInfo::parseModuleC13(const PdbFile &pdb, const ModuleInfo &mi,
                              const uint8_t *c13, size_t c13Size) {
    // ---- 1. tur: altbölüm konumlarını bul ----
    struct Sub {
        uint32_t kind;
        const uint8_t *body;
        size_t len;
    };
    std::vector<Sub> subs;
    {
        size_t pos = 0;
        while (pos + 8 <= c13Size) {
            uint32_t kind = rd32(c13 + pos);
            uint32_t len = rd32(c13 + pos + 4);
            if (len > c13Size - pos - 8) break;
            subs.push_back({kind, c13 + pos + 8, len});
            pos += 8 + len;
        }
    }

    // ---- 2. tur: STRINGTABLE (varsa modül-yerel ad yığını) ----
    for (const Sub &s : subs)
        if (s.kind == cv::DEBUG_S_STRINGTABLE)
            strTab_.assign(s.body, s.body + s.len);

    // ---- 3. tur: FILECHKSMS -> dosya tablosu ----
    // Giriş ofsetleri (CHKSMS gövdesi içindeki bayt konumu) dosya indeksine
    // eşlenir; LINES bloklarının offFile'ı bu ofsetleri kullanır.
    for (const Sub &s : subs) {
        if (s.kind != cv::DEBUG_S_FILECHKSMS) continue;
        size_t off = 0;
        while (off + 5 <= s.len) {
            uint32_t nameOff = rd32(s.body + off);
            uint8_t kind = s.body[off + 4];
            size_t hashLen = checksumLen(kind);
            size_t entrySize = 5 + hashLen;
            entrySize = (entrySize + 3) & ~(size_t)3; // 4 hizalı
            if (entrySize == 0 || off + entrySize > s.len) break;

            SourceFile f;
            f.checksumKind = kind;
            f.checksum.assign(s.body + off + 5, s.body + off + 5 + hashLen);
            f.module = mi.index;
            // Ad: önce modül-yerel STRINGTABLE, yoksa PDB /names yığını
            if (nameOff < strTab_.size()) {
                const char *p = (const char *)strTab_.data() + nameOff;
                f.name.assign(p, strnlen(p, strTab_.size() - nameOff));
            } else {
                f.name = pdb.ecName(nameOff); // /names (sonek paylaşımı olabilir)
            }
            files_.push_back(std::move(f));
            chksmsOffToFile_[(uint32_t)off] = (uint32_t)files_.size(); // 1 tabanlı
            off += entrySize;
        }
    }

    // ---- 4. tur: LINES altbölümleri ----
    for (const Sub &s : subs) {
        if (s.kind != cv::DEBUG_S_LINES) continue;
        if (s.len < 12) continue;
        uint32_t offCon = rd32(s.body);
        uint16_t segCon = rd16(s.body + 4);
        uint16_t flags = rd16(s.body + 6);
        // uint32_t cbCon = rd32(s.body + 8); (kullanılmıyor)
        bool hasCols = (flags & cv::CV_LINES_HAVE_COLUMNS) != 0;

        // segCon -> orijinal düzen bölüm tabanı (sembollerle aynı kural)
        const std::vector<SectionHdr> *base =
            pdb.hasOmap() && !pdb.sectionsOrig().empty() ? &pdb.sectionsOrig()
                                                         : &pdb.sections();
        if (segCon == 0 || (size_t)segCon > base->size()) continue;
        uint32_t secVa = (*base)[segCon - 1].virtualAddress;

        size_t bpos = 12; // başlık sonrası dosya blokları
        while (bpos + 12 <= s.len) {
            uint32_t offFile = rd32(s.body + bpos);
            uint32_t nLines = rd32(s.body + bpos + 4);
            uint32_t cbBlock = rd32(s.body + bpos + 8);
            if (cbBlock < 12 || bpos + cbBlock > s.len) break;
            const uint8_t *l = s.body + bpos + 12;
            size_t avail = (size_t)cbBlock - 12;
            if ((size_t)nLines * 8 > avail) nLines = (uint32_t)(avail / 8);

            uint32_t fileIdx = 0;
            auto it = chksmsOffToFile_.find(offFile);
            if (it != chksmsOffToFile_.end()) fileIdx = it->second;
            SourceFile *file = fileIdx ? &files_[fileIdx - 1] : nullptr;

            for (uint32_t i = 0; i < nLines; i++) {
                const uint8_t *e = l + (size_t)i * 8;
                uint32_t codeOff = rd32(e);
                uint32_t rawLine = rd32(e + 4);
                LineEntry le;
                le.line = rawLine & 0x00FFFFFF;
                if (le.line == 0) continue; // 0. satır geçersizdir
                le.isStatement = (rawLine & 0x80000000u) != 0;
                le.fileIdx = fileIdx;
                if (hasCols && (size_t)nLines * 12 <= avail) {
                    const uint8_t *cl = l + (size_t)nLines * 8;
                    le.column = rd16(cl + (size_t)i * 4);
                    le.columnEnd = rd16(cl + (size_t)i * 4 + 2);
                }

                // origRva = bölümVA + offCon + kodOfseti; OMAP ile güncelleştir
                uint32_t origRva = secVa + offCon + codeOff;
                le.rva = pdb.hasOmap() ? PdbFile::omapRemap(pdb.omapFromPublic(), origRva)
                                       : origRva;
                lines_.push_back(le);
                if (file) {
                    file->lineCount++;
                    if (file->firstRva == 0 || le.rva < file->firstRva)
                        file->firstRva = le.rva;
                    if (le.rva > file->lastRva) file->lastRva = le.rva;
                }
            }
            bpos += cbBlock;
        }
    }
    return true;
}

// ---------------------------------------------------------------------------
// Sorgular
// ---------------------------------------------------------------------------
const LineEntry *LineInfo::lineForRva(uint32_t rva) const {
    if (lines_.empty()) return nullptr;
    size_t lo = 0, hi = lines_.size();
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        if (lines_[mid].rva <= rva) lo = mid + 1;
        else hi = mid;
    }
    if (lo == 0) return nullptr;
    return &lines_[lo - 1];
}

void LineInfo::filesOfModule(int32_t module, std::vector<const SourceFile *> &out) const {
    out.clear();
    for (const SourceFile &f : files_)
        if (module < 0 || f.module == module) out.push_back(&f);
}

} // namespace pdbscope
