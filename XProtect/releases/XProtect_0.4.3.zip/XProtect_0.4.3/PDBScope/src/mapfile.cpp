// ============================================================================
//  PDBScope — mapfile.cpp
//  Bağlayıcı .map dosyası ayrıştırıcı.
//
//  Desteklenen biçimler:
//   1) MSVC link /MAP:
//      Preferred load address is 01400000h
//      Start         Length     Name            Class
//       0001:00000000 00000e08cH .text           CODE
//      Address         Publics by Value   Rva+Base     Lib:Object
//       0001:00001000  _main              014001000 f  main.obj
//
//   2) lld (MinGW clang) haritası — RVA tabanlı:
//      Address  Size     Align Out     In      Symbol
//      00001000 00000d76  4096 .text
//      000013a0 00000000     0                 add_cdecl
//
//   3) klasik GNU ld haritası — mutlak VA:
//      .text           0x00401000     0x1a2c
//                     0x0040101e                main
// ============================================================================
#include "mapfile.h"

#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <regex>
#include <sstream>

#include "pe.h"
#include "util.h"

namespace pdbscope {

static bool isTextFile(const std::vector<uint8_t> &d) {
    size_t n = std::min<size_t>(d.size(), 4096);
    if (n == 0) return false;
    size_t binary = 0;
    for (size_t i = 0; i < n; i++)
        if (d[i] == 0) binary++;
    return binary == 0;
}

MapFormat detectMapFormat(const std::vector<uint8_t> &data) {
    if (!isTextFile(data)) return MapFormat::Unknown;
    std::string text((const char *)data.data(), std::min<size_t>(data.size(), 256 * 1024));
    std::istringstream ss(text);
    std::string line;
    int lines = 0;
    while (std::getline(ss, line) && lines++ < 512) {
        if (line.find("Publics by Value") != std::string::npos) return MapFormat::Msvc;
        if (line.find("Preferred load address") != std::string::npos) return MapFormat::Msvc;
        // lld (LLVM linker) haritası başlığı
        if (line.find("Align Out") != std::string::npos &&
            line.find("Symbol") != std::string::npos)
            return MapFormat::Gnu;
        if (line.find("Linker script and memory map") != std::string::npos) return MapFormat::Gnu;
        if (line.find("Archive member included") != std::string::npos) return MapFormat::Gnu;
        if (line.find("Memory Configuration") != std::string::npos) return MapFormat::Gnu;
    }
    return MapFormat::Unknown;
}

// MSVC satır desenleri
static const std::regex reMsvcSym(
    "^\\s*([0-9A-Fa-f]{1,4}):([0-9A-Fa-f]{4,8})\\s+(\\S+)\\s+([0-9A-Fa-f]+)"
    "(?:\\s+([a-zA-Z]))?(?:\\s+(.*))?\\s*$");
static const std::regex reMsvcSect(
    "^\\s*([0-9A-Fa-f]{1,4}):([0-9A-Fa-f]{4,8})\\s+([0-9A-Fa-f]+)H?\\s+(\\S+)\\s+(\\S+)\\s*$");
static const std::regex reLoadAddr("Preferred load address is ([0-9A-Fa-f]+)[hH]?");

// klasik GNU sembolü: " 0x0040101e   main"
static const std::regex reGnuSym("^\\s+(0x[0-9A-Fa-f]+)\\s+([^\\s/][^\\s]*)\\s*$");
// klasik GNU çıktı bölümü: " .text  0x00401000  0x1a2c"
static const std::regex reGnuSect("^\\s(\\S+)\\s+(0x[0-9A-Fa-f]+)\\s+(0x[0-9A-Fa-f]+).*$");

// lld satırı: "000013a0 00000000     0                 add_cdecl"
// (adres onaltılık, boyut onaltılık, hizalama ondalık)
static bool parseLldLine(const std::string &line, uint64_t &addr, uint64_t &size,
                         std::string &last) {
    std::istringstream ss(line);
    std::string a, s, al, rest;
    if (!(ss >> a >> s >> al)) return false;
    std::getline(ss, rest);
    // adres ve boyut onaltılık, hizalama ondalık olmalı
    auto isHex = [](const std::string &t) {
        return t.size() >= 1 && t.find_first_not_of("0123456789abcdefABCDEF") ==
                                    std::string::npos;
    };
    if (!isHex(a) || !isHex(s)) return false;
    if (al.find_first_not_of("0123456789") != std::string::npos) return false;
    // lld sütunları öneksiz ONALTILIKTIR
    uint64_t va = 0, vs = 0;
    try {
        va = std::stoull(a, nullptr, 16);
        vs = std::stoull(s, nullptr, 16);
    } catch (...) {
        return false;
    }
    // satır sonundaki simge (boşlukla ayrılmış son alan)
    std::string sym = trim(rest);
    if (sym.empty()) return false; // bölüm/kırık satır
    addr = va;
    size = vs;
    last = sym;
    return true;
}

static std::vector<std::string> readLines(const std::vector<uint8_t> &data) {
    std::vector<std::string> lines;
    std::string text((const char *)data.data(), data.size());
    std::istringstream ss(text);
    std::string line;
    while (std::getline(ss, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        lines.push_back(line);
    }
    return lines;
}

bool parseMapFile(const std::string &path, const PeFile *pe, MapParseResult &out,
                  std::string *err) {
    std::vector<uint8_t> data = readFile(path, err);
    if (data.empty()) return false;

    out = MapParseResult{};
    MapFormat fmt = detectMapFormat(data);
    if (fmt == MapFormat::Unknown) {
        fmt = MapFormat::Msvc; // en olası biçim: dene
        out.parseErrors++;
    }
    out.format = fmt;

    uint64_t peBase = pe ? pe->imageBase() : 0;

    if (fmt == MapFormat::Msvc) {
        std::smatch m;
        std::vector<std::string> lines = readLines(data);
        bool inSymbols = false;
        for (const std::string &line : lines) {
            if (std::regex_search(line, m, reLoadAddr)) {
                // değer öneksiz onaltılık (h son ekli olabilir)
                std::string digits = m[1].str();
                if (!digits.empty() && (digits.back() == 'h' || digits.back() == 'H'))
                    digits.pop_back();
                try {
                    out.imageBase = std::stoull(digits, nullptr, 16);
                    out.imageBaseKnown = true;
                } catch (...) {
                }
                continue;
            }
            if (line.find("Publics by Value") != std::string::npos ||
                line.find("Static symbols") != std::string::npos) {
                inSymbols = true;
                continue;
            }
            if (inSymbols && std::regex_match(line, m, reMsvcSym)) {
                Symbol s;
                // MSVC map sütunları öneksiz ONALTILIKTIR
                auto hexNum = [](const std::string &t) -> std::optional<uint64_t> {
                    try {
                        if (t.empty() ||
                            t.find_first_not_of("0123456789abcdefABCDEF") != std::string::npos)
                            return std::nullopt;
                        return std::stoull(t, nullptr, 16);
                    } catch (...) {
                        return std::nullopt;
                    }
                };
                auto seg = hexNum(m[1].str());
                auto off = hexNum(m[2].str());
                auto rvaBase = hexNum(m[4].str());
                s.name = m[3].str();
                std::string flags = m[5].matched ? m[5].str() : "";
                if (seg && off && rvaBase) {
                    s.seg = (uint16_t)*seg;
                    s.off = (uint32_t)*off;
                    uint64_t base = out.imageBaseKnown ? out.imageBase : peBase;
                    uint64_t rva = *rvaBase - base;
                    s.rva = s.origRva = (uint32_t)rva;
                    s.isCode = flags.find('f') != std::string::npos ||
                               flags.find('i') != std::string::npos;
                    s.isFunction = s.isCode;
                    s.kind = s.isFunction ? SymKind::Function : SymKind::Public;
                    out.symbols.push_back(std::move(s));
                }
                continue;
            }
            if (!inSymbols && std::regex_match(line, m, reMsvcSect)) {
                SectionHdr sh;
                std::string nm = m[4].str();
                std::memcpy(sh.name, nm.c_str(), std::min<size_t>(nm.size(), 8));
                try {
                    sh.virtualSize = (uint32_t)std::stoull(m[3].str(), nullptr, 16);
                } catch (...) {
                }
                sh.virtualAddress = 0xFFFFFFFF; // PE eşleşmesiyle doldurulur
                out.sections.push_back(sh);
                continue;
            }
        }
        if (pe) {
            const std::vector<SectionHdr> &ps = pe->sections();
            for (size_t i = 0; i < out.sections.size() && i < ps.size(); i++)
                out.sections[i].virtualAddress = ps[i].virtualAddress;
        }
    } else {
        // ---- GNU ailesi: lld mi klasik ld mi? ----
        std::vector<std::string> lines = readLines(data);
        bool lldStyle = false;
        for (const std::string &line : lines) {
            if (line.find("Align Out") != std::string::npos) {
                lldStyle = true;
                break;
            }
        }

        if (lldStyle) {
            // lld haritası: adresler zaten RVA'dır (görüntü tabanı hariç)
            for (const std::string &line : lines) {
                uint64_t addr, sz;
                std::string sym;
                if (!parseLldLine(line, addr, sz, sym)) continue;
                if (!sym.empty() && sym[0] == '.') {
                    // çıktı bölümü: ".text 00001000 00000d76 4096"
                    SectionHdr sh;
                    std::memcpy(sh.name, sym.c_str(), std::min<size_t>(sym.size(), 8));
                    sh.virtualAddress = (uint32_t)addr;
                    sh.virtualSize = (uint32_t)sz;
                    out.sections.push_back(sh);
                    continue;
                }
                // simge satırı — yol/nesne adlarını ele
                if (sym.find(':') != std::string::npos && sym.find('(') != std::string::npos)
                    continue; // "obj.o:(.text)" girdi bölümü
                if (sym[0] == '/') continue; // mutlak yol
                Symbol s;
                s.rva = s.origRva = (uint32_t)addr;
                s.seg = 1;
                s.off = s.rva;
                s.name = sym;
                s.size = (uint32_t)sz;
                s.kind = SymKind::Public;
                out.symbols.push_back(std::move(s));
            }
            // görüntü tabanı: PE'den ya da .text RVA'sından türetilemez (lld
            // RVA verir); PE varsa gerçek taban, yoksa 0
            if (pe && peBase) {
                out.imageBase = peBase;
                out.imageBaseKnown = true;
            }
        } else {
            // klasik GNU ld: mutlak VA'lar
            uint64_t firstSectVa = 0;
            bool haveFirst = false;
            for (const std::string &line : lines) {
                std::smatch m;
                if (std::regex_match(line, m, reGnuSect)) {
                    std::string nm = m[1].str();
                    if (line.find("DISCARDED") != std::string::npos) continue;
                    auto va = parseNumber(m[2].str());
                    auto len = parseNumber(m[3].str());
                    if (va && len) {
                        SectionHdr sh;
                        std::memcpy(sh.name, nm.c_str(), std::min<size_t>(nm.size(), 8));
                        sh.virtualAddress = (uint32_t)*va;
                        sh.virtualSize = (uint32_t)*len;
                        out.sections.push_back(sh);
                        if (!haveFirst && nm == ".text") {
                            firstSectVa = *va;
                            haveFirst = true;
                        }
                        if (!haveFirst) {
                            firstSectVa = *va;
                            haveFirst = true;
                        }
                    }
                }
            }
            if (pe && peBase) {
                out.imageBase = peBase;
                out.imageBaseKnown = true;
            } else if (haveFirst && firstSectVa >= 0x1000) {
                out.imageBase = firstSectVa - 0x1000; // .text genelde taban+0x1000
                out.imageBaseKnown = true;
            }
            for (const std::string &line : lines) {
                std::smatch m;
                if (!std::regex_match(line, m, reGnuSym)) continue;
                auto va = parseNumber(m[1].str());
                std::string name = m[2].str();
                if (!va || name.empty() || name[0] == '*' || name[0] == '.') continue;
                if (name.size() > 2 && name.compare(0, 2, "0x") == 0) continue;
                Symbol s;
                uint64_t base = out.imageBaseKnown ? out.imageBase : 0x400000;
                s.rva = s.origRva = (uint32_t)(*va - base);
                s.seg = 1;
                s.off = s.rva;
                s.name = name;
                s.kind = SymKind::Public;
                out.symbols.push_back(std::move(s));
            }
        }
    }

    // Tekilleştir
    std::sort(out.symbols.begin(), out.symbols.end(),
              [](const Symbol &a, const Symbol &b) {
                  if (a.rva != b.rva) return a.rva < b.rva;
                  return a.name < b.name;
              });
    out.symbols.erase(std::unique(out.symbols.begin(), out.symbols.end(),
                                  [](const Symbol &a, const Symbol &b) {
                                      return a.rva == b.rva && a.name == b.name;
                                  }),
                      out.symbols.end());

    if (out.symbols.empty()) {
        if (err) *err = "map dosyasında sembol bulunamadı (bilinmeyen biçim?)";
        return false;
    }
    return true;
}

} // namespace pdbscope
