// ============================================================================
//  PDBScope — pdbless.h
//  PDB OLMADAN fonksiyon bulma motoru: IDA Pro / Ghidra başlangıç analizi
//  yaklaşımının taşınabilir uygulaması (BrainMapCore'un doğrulanmış çok
//  katmanlı güven yöntemi temel alınarak evrensel hale getirildi).
//
//  Katmanlar (her aday adres hepsinden puan toplar):
//    PE üstveri : giriş noktası, export'lar, GFIDS (CFG), SafeSEH, TLS
//                 geri çağırmaları, .pdata (x64 kesin sınırlar), COFF sembol
//                 tablosu, relocation hedef işaretçileri
//    RTTI       : type_info tanımlayıcıları -> Complete Object Locator ->
//                 vftable -> sanal fonksiyon başlangıçları (x86 VA / x64 RVA)
//    Çağrı      : E8/E9 (call/jmp rel32) doğrudan hedefleri + çağıran sayısı
//    Sınır      : int3 dolgusu, ret+n, kuyruk jmp, hizalama
//    Prolog     : MSVC (x86+x64), GCC, Delphi/Borland prolog kalıpları
//
//  Doğrulama: katman puanlarının en yükseği × (1 + 0.1×ekKatman); JCC-içi
//  reddi (orta-function hedef yanlış pozitiflerini süzer). Sınıflandırma:
//    CERTAIN >= 0.90  HIGH >= 0.70  MEDIUM >= 0.40  LOW >= 0.20  REJECT
// ============================================================================
#pragma once

#include <cstdint>
#include <map>
#include <set>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "pe.h"

namespace pdbscope {

struct PlFunction {
    uint32_t rva = 0;
    uint32_t size = 0;        // 0 = tahmin edilemedi
    float confidence = 0;     // 0..1
    // sınıflandırma
    enum Class { CERTAIN, HIGH, MEDIUM, LOW, REJECT } cls = REJECT;
    std::string name;         // sub_XXXX / export / Sınıf::vf3 / imp:DLL!fn
    std::string kind;         // func | thunk | vfunc | import | entry | coff
    std::set<std::string> sources;
    std::vector<std::string> evidence;
    int callerCount = 0;

    const char *classStr() const {
        switch (cls) {
        case CERTAIN: return "CERTAIN";
        case HIGH: return "HIGH";
        case MEDIUM: return "MEDIUM";
        case LOW: return "LOW";
        default: return "REJECT";
        }
    }
};

struct PlVtable {
    uint32_t rva = 0;         // vftable başlangıcı
    uint32_t colRva = 0;      // Complete Object Locator
    std::string className;    // ".?AVFoo@" -> "Foo"
    std::vector<uint32_t> funcRvas;
};

struct PlStats {
    uint32_t candidates = 0;      // tüm adaylar
    uint32_t accepted = 0;        // eşiği geçenler
    uint32_t certain = 0, high = 0, medium = 0, low = 0, rejected = 0;
    uint32_t pdataFuncs = 0;      // x64 .pdata'dan
    uint32_t exportFuncs = 0, gfidsFuncs = 0, sehFuncs = 0, tlsFuncs = 0;
    uint32_t coffFuncs = 0, relocPtrFuncs = 0;
    uint32_t rttiClasses = 0, rttiVfuncs = 0;
    uint32_t callTargets = 0, prologueHits = 0;
    uint32_t importThunks = 0;
    uint32_t textSize = 0;        // çalıştırılabilir toplam
    uint32_t covered = 0;         // kabul edilen fonksiyonların kapladığı bayt
    uint32_t vftables = 0;
};

struct PdblessOpts {
    bool scanRtti = true;
    bool scanCalls = true;
    bool scanPrologues = true;
    bool scanPdata = true;
    bool scanGfids = true;
    bool scanSafeSEH = true;
    bool scanCoff = true;
    bool scanRelocPtrs = true;
    float minConfidence = 0.20f; // altındakiler listede REJECT olarak düşer
};

class PdblessAnalyzer {
public:
    bool analyze(const PeFile &pe, const PdblessOpts &opts, std::string *err);

    const std::vector<PlFunction> &functions() const { return funcs_; }
    const std::vector<PlVtable> &vtables() const { return vtables_; }
    const PlStats &stats() const { return stats_; }

    // (test/CLI) güven katmanı adı -> katkı açıklaması
    static const char *layerName(const std::string &src);

private:
    struct Cand {
        float peMeta = 0, rtti = 0, call = 0, boundary = 0, prologue = 0;
        int callers = 0;
        bool jccInside = false;   // koşullu dal hedefi (fonksiyon ortası?)
        std::set<std::string> sources;
        std::vector<std::string> evidence;
        std::string name;         // biliniyorsa (export/coff/rtti/imp)
        std::string kind;
    };

    // bölüm görünümü: ham dosya ofsetleriyle hızlı tarama için
    struct SecView {
        uint32_t va = 0;    // bölüm RVA'sı
        uint32_t span = 0;  // diskte taranan bayt
        size_t off = 0;     // dosya ofseti
        bool exec = false;
    };

    // bölüm/araçlar
    bool isExecRva(uint32_t rva) const;
    bool rvaToOff(uint32_t rva, uint32_t &off) const {
        return pe_->rvaToOffset(rva, off);
    }
    uint8_t at(uint32_t off) const { return off < raw_->size() ? (*raw_)[off] : 0; }
    uint32_t rva8(uint32_t rva) const {
        uint32_t o;
        return rvaToOff(rva, o) ? at(o) : 0;
    }
    uint32_t rd32rva(uint32_t rva) const {
        uint32_t o;
        if (!rvaToOff(rva, o) || o + 4 > raw_->size()) return 0;
        return (uint32_t)(*raw_)[o] | ((uint32_t)(*raw_)[o + 1] << 8) |
               ((uint32_t)(*raw_)[o + 2] << 16) | ((uint32_t)(*raw_)[o + 3] << 24);
    }
    uint64_t rd64rva(uint32_t rva) const {
        uint32_t o;
        if (!rvaToOff(rva, o) || o + 8 > raw_->size()) return 0;
        uint64_t v = 0;
        for (int i = 7; i >= 0; i--) v = (v << 8) | (*raw_)[o + i];
        return v;
    }

    // katman tarayıcıları
    void scanExports(std::unordered_map<uint32_t, Cand> &cands);
    void scanPdata(std::unordered_map<uint32_t, Cand> &cands);
    void scanGfids(std::unordered_map<uint32_t, Cand> &cands);
    void scanSafeSEH(std::unordered_map<uint32_t, Cand> &cands);
    void scanTlsCallbacks(std::unordered_map<uint32_t, Cand> &cands);
    void scanCoffSymbols(std::unordered_map<uint32_t, Cand> &cands);
    void scanRelocTargets(std::unordered_map<uint32_t, Cand> &cands);
    void scanRtti(std::unordered_map<uint32_t, Cand> &cands);
    void scanCalls(std::unordered_map<uint32_t, Cand> &cands);
    void scanPrologues(std::unordered_map<uint32_t, Cand> &cands);
    void scoreAndFinish(std::unordered_map<uint32_t, Cand> &cands,
                        const PdblessOpts &opts);
    void estimateSizes();
    void dropInside();
    void scanImportThunks(std::unordered_map<uint32_t, Cand> &cands);

    // prolog tespiti
    struct PrologueResult {
        bool found = false;
        int confidence = 0; // 0..100
        const char *desc = "";
        int length = 0;
    };
    PrologueResult detectPrologue(uint32_t rva, int &lenUsed) const;

    const PeFile *pe_ = nullptr;
    const std::vector<uint8_t> *raw_ = nullptr;
    bool is64_ = false;
    uint64_t imageBase_ = 0;
    uint32_t imageSize_ = 0;
    uint32_t entryRva_ = 0;
    std::vector<std::pair<uint32_t, uint32_t>> execRanges_; // [rva, rvaEnd)
    std::vector<std::pair<uint32_t, uint32_t>> dataRanges_; // veri bölümleri
    std::vector<SecView> secViews_;
    std::set<uint32_t> pdataStarts_;            // x64 kesin başlangıçlar
    std::map<uint32_t, uint32_t> pdataEnds_;    // başlangıç -> son
    std::unordered_map<uint32_t, std::string> importNames_; // IAT RVA -> ad
    std::vector<PlFunction> funcs_;
    std::vector<PlVtable> vtables_;
    PlStats stats_;
};

} // namespace pdbscope
