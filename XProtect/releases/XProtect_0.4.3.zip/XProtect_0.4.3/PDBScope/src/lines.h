// ============================================================================
//  PDBScope — lines.h
//  C13 satır bilgisi: modül akışlarındaki DEBUG_S_LINES altbölümlerini
//  çözümleyip RVA -> kaynak dosya:satır haritası üretir.
//
//  Yapı (cvinfo.h "V7 line number data types"):
//    AltBölüm başlığı { u32 tür, u32 uzunluk }
//    LINES başlığı   { u32 offCon, u16 segCon, u16 flags, u32 cbCon }
//    Dosya bloğu     { u32 offFile (CHKSMS ofseti), u32 nLines, u32 cbBlock,
//                      { u32 kodOfseti, u32 satır:24|bitBayrakları } * nLines,
//                      (HAVE_COLUMNS ise) { u16 sütunBaş, u16 sütunSon } * n }
//    FILECHKSMS      girişleri { u32 adOfseti (STRINGTABLE), u8 karmaTürü,
//                      karma baytları... } 4 bayt hizalı
//    STRINGTABLE     null ayraçlı ham ad yığını (başlıksız)
//  kodOfseti offCon'e görelidir: RVA = segRva(segCon) + offCon + kodOfseti
// ============================================================================
#pragma once

#include <cstdint>
#include <map>
#include <string>
#include <vector>

#include "pdb.h"

namespace pdbscope {

struct LineEntry {
    uint32_t rva = 0;
    uint32_t line = 0;         // 1 tabanlı
    uint16_t column = 0;       // 0 = yok
    uint16_t columnEnd = 0;
    uint32_t fileIdx = 0;      // dosya indeksi (dosyalar() vektörüne)
    bool isStatement = true;
};

struct SourceFile {
    std::string name;          // STRINGTABLE'dan
    uint32_t checksumKind = 0; // 0=yok 1=MD5 2=SHA1 3=SHA256
    std::vector<uint8_t> checksum;
    uint32_t lineCount = 0;
    uint32_t firstRva = 0, lastRva = 0;
    int32_t module = -1;
};

class LineInfo {
public:
    // Bir PDB'nin tüm modüllerinden satır bilgisi toplar.
    bool collect(const PdbFile &pdb, bool withInline, std::string *err);

    const std::vector<SourceFile> &files() const { return files_; }
    const std::vector<LineEntry> &lines() const { return lines_; }

    // RVA aralığındaki en iyi eşleşme: RVA'dan küçük/eşit en büyük giriş
    const LineEntry *lineForRva(uint32_t rva) const;

    // Belirli modülün dosyaları (tümü boş modül filtresi)
    void filesOfModule(int32_t module, std::vector<const SourceFile *> &out) const;

    uint32_t totalEntries() const { return (uint32_t)lines_.size(); }

private:
    bool parseModuleC13(const PdbFile &pdb, const ModuleInfo &mi,
                        const uint8_t *c13, size_t c13Size);

    std::vector<SourceFile> files_;
    std::vector<LineEntry> lines_; // RVA sıralı (toplam sonunda sıralanır)
    std::vector<uint8_t> strTab_;  // modül başına geçici (0xf3 varsa)
    std::map<uint32_t, uint32_t> chksmsOffToFile_; // CHKSMS ofseti -> dosya
    int32_t curModule_ = -1;       // dosya atfı için
};

} // namespace pdbscope
