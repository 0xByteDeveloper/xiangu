// ============================================================================
//  PDBScope — output.h
//  Sembol listesi biçimlendirme: tablo / CSV / JSON / MAP çıktısı.
// ============================================================================
#pragma once

#include <cstdint>
#include <functional>
#include <string>
#include <vector>

#include "pdb.h"

namespace pdbscope {

struct OutOpts {
    std::string format = "table"; // table | csv | json | map
    std::string sortBy = "rva";   // rva | name | size
    std::string filter;           // alt dizge (küçük harf duyarsız)
    std::string regex;            // düzenli ifade (filtre ile birlikte)
    std::string moduleFilter;     // modül adı alt dizgesi
    uint64_t imageBase = 0;
    bool imageBaseKnown = false;
    int limit = 0;                // 0 = sınırsız
    bool demangle = true;         // tabloda çözümlü adı göster
    bool jsonPretty = false;
    bool noHeader = false;        // başlık satırlarını atla
    bool showMangled = false;     // tabloda ham adı da göster
    // v2 ek sütunlar (doldurulursa gösterilir)
    std::function<std::string(const Symbol &)> signatureOf; // "int __cdecl (int)"
    std::function<std::string(const Symbol &)> lineOf;       // "kaynak.cpp:123"
    const std::vector<SectionHdr> *sections = nullptr; // güncel bölümler
};

// Filtre + sıralama uygulanmış sembol listesi (görüntülenmeden önce)
std::vector<Symbol> prepareSymbols(const std::vector<Symbol> &symbols,
                                   const OutOpts &opts);

// Biçimlendirilmiş çıktı üretir.
std::string renderSymbols(const std::vector<Symbol> &symbols,
                          const std::string &sourcePath,
                          const std::vector<std::string> &moduleNames,
                          const OutOpts &opts, size_t *shownCount);

// Verilen RVA'ya en yakın sembolü bul (liste RVA'ya göre sıralı olmalı).
// Dönen indeks: içeren sembol yoksa önceki en yakın sembol.
struct NearestResult {
    bool found = false;
    bool exact = false;
    size_t index = 0;      // sembol indeksi
    int64_t delta = 0;     // hedef - sembolRVA (pozitif = ileride)
};
NearestResult findNearest(const std::vector<Symbol> &sorted, uint32_t rva);

} // namespace pdbscope
