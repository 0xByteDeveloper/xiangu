// ============================================================================
//  PDBScope — pdbless.cpp
//  PDB'siz statik fonksiyon bulma: katmanlı güven motoru.
//
//  Yaklaşım IDA/Ghidra başlangıç analizine eşdeğerdir ve BrainMapCore'ta
//  doğrulanmış yöntem evrenselleştirilmiştir: aday adresler beş bağımsız
//  katmandan puan toplar; JCC-içi reddi yanlış pozitifleri süzer.
//  Tüm işlemler DOSYADAN yapılır (process gerekmez): .rdata'daki mutlak
//  işaretçiler diskte tercih edilen ImageBase VA'larıdır — statik çözümleme
//  IDA/Ghidra'nın dosya analizine eşdeğerdir.
// ============================================================================
#include "pdbless.h"

#include <algorithm>
#include <cstring>
#include <unordered_map>

#include "util.h"

namespace pdbscope {

// ---------------------------------------------------------------------------
// Yardımcılar
// ---------------------------------------------------------------------------
static uint32_t rd32at(const std::vector<uint8_t> &d, size_t o) {
    if (o + 4 > d.size()) return 0;
    return (uint32_t)d[o] | ((uint32_t)d[o + 1] << 8) | ((uint32_t)d[o + 2] << 16) |
           ((uint32_t)d[o + 3] << 24);
}
static uint64_t rd64at(const std::vector<uint8_t> &d, size_t o) {
    if (o + 8 > d.size()) return 0;
    uint64_t v = 0;
    for (int i = 7; i >= 0; i--) v = (v << 8) | d[o + i];
    return v;
}

const char *PdblessAnalyzer::layerName(const std::string &src) {
    if (src == "GFIDS") return "CFG gecerli cagri hedefi";
    if (src == "Export") return "Export tablosu";
    if (src == "SafeSEH") return "SafeSEH isleyici tablosu";
    if (src == "EntryPoint") return "Giris noktasi";
    if (src == "Pdata") return ".pdata (x64 unwind)";
    if (src == "COFF") return "COFF sembol tablosu";
    if (src == "RelocPtr") return "Relocation hedefli isaretci";
    if (src == "RTTI_VF") return "RTTI sanal fonksiyon";
    if (src == "CallTarget") return "Dogrudan cagri/jmp hedefi";
    if (src == "Boundary") return "Sinir kaniti (int3/ret)";
    if (src == "Prologue") return "Prolog kalibi";
    if (src == "TLS") return "TLS geri cagirma";
    if (src == "Import") return "Import thunk";
    return src.c_str();
}

bool PdblessAnalyzer::isExecRva(uint32_t rva) const {
    for (const auto &r : execRanges_)
        if (rva >= r.first && rva < r.second) return true;
    return false;
}

// ---------------------------------------------------------------------------
// analyze
// ---------------------------------------------------------------------------
bool PdblessAnalyzer::analyze(const PeFile &pe, const PdblessOpts &opts,
                              std::string *err) {
    (void)err;
    pe_ = &pe;
    raw_ = &pe.raw();
    is64_ = pe.is64();
    imageBase_ = pe.imageBase();
    imageSize_ = pe.sizeOfImage();
    entryRva_ = pe.entryPointRva();
    funcs_.clear();
    vtables_.clear();
    stats_ = PlStats{};
    pdataStarts_.clear();
    pdataEnds_.clear();
    importNames_.clear();
    execRanges_.clear();
    dataRanges_.clear();
    secViews_.clear();

    for (const SectionHdr &s : pe.sections()) {
        uint32_t span = s.virtualSize ? s.virtualSize : s.sizeOfRawData;
        if (span == 0 || s.sizeOfRawData == 0) continue;
        std::string nm(s.name);
        bool exec = (s.characteristics & 0x20000000) != 0 || nm == ".text" ||
                    nm == "code" || nm == "INIT" || nm == "PAGE";
        SecView v;
        v.va = s.virtualAddress;
        v.span = std::min(span, s.sizeOfRawData); // diskte olan kısım
        v.off = 0;
        uint32_t rawOff;
        v.off = 0;
        // ham ofset: bölüm tablosundaki PointerToRawData'ya ihtiyaç var; PeFile
        // rvaToOffset ile bulur — her bölümün ilk RVA'sını çevir
        if (!pe.rvaToOffset(s.virtualAddress, rawOff)) continue;
        v.off = rawOff;
        v.exec = exec;
        secViews_.push_back(v);
        if (exec) {
            execRanges_.push_back({s.virtualAddress, s.virtualAddress + span});
            stats_.textSize += span;
        } else {
            dataRanges_.push_back({s.virtualAddress, s.virtualAddress + span});
        }
    }
    if (execRanges_.empty()) {
        if (err) *err = "calistirilabilir bolum yok";
        return false;
    }

    // IAT -> import adları (thunk adlandırma)
    {
        std::vector<ImportEntry> imports;
        if (pe.readImports(imports, nullptr)) {
            for (const ImportEntry &ie : imports) {
                if (ie.iatRva)
                    importNames_[ie.iatRva] = ie.dll + "!" +
                        (ie.name.empty() ? ("ordinal#" + std::to_string(ie.ordinal))
                                         : ie.name);
            }
        }
    }

    std::unordered_map<uint32_t, Cand> cands;

    // --- katman A: PE üstveri ---
    scanExports(cands);
    if (entryRva_ && isExecRva(entryRva_)) {
        Cand &c = cands[entryRva_];
        c.peMeta = 1.0f;
        c.sources.insert("EntryPoint");
        if (c.name.empty()) { c.name = "entry_point"; c.kind = "entry"; }
    }
    if (opts.scanPdata) scanPdata(cands);
    if (opts.scanGfids) scanGfids(cands);
    if (opts.scanSafeSEH && !is64_) scanSafeSEH(cands);
    scanTlsCallbacks(cands);
    if (opts.scanCoff) scanCoffSymbols(cands);
    if (opts.scanRelocPtrs) scanRelocTargets(cands);
    scanImportThunks(cands);

    // --- katman B: RTTI ---
    if (opts.scanRtti) scanRtti(cands);

    // --- katman C: çağrı hedefleri ---
    if (opts.scanCalls) scanCalls(cands);

    // --- katman E: prolog kalıpları ---
    if (opts.scanPrologues) scanPrologues(cands);

    // --- puanlama + sınıflandırma ---
    scoreAndFinish(cands, opts);
    estimateSizes();

    // --- IDA tarzı aralık çakışması çözümü: yüksek güvenli fonksiyonların
    //     içinde kalan düşük güvenli adaylar atılır (fonksiyon-ortası gürültü) ---
    dropInside();
    estimateSizes();

    // kapsam istatistiği: kabul edilen fonksiyonların birleşik aralığı
    {
        std::vector<std::pair<uint32_t, uint32_t>> iv;
        for (const PlFunction &f : funcs_)
            if (f.size && f.cls != PlFunction::REJECT)
                iv.push_back({f.rva, f.rva + f.size});
        std::sort(iv.begin(), iv.end());
        uint32_t cov = 0;
        size_t i = 0;
        while (i < iv.size()) {
            uint32_t s = iv[i].first, e = iv[i].second;
            size_t j = i + 1;
            while (j < iv.size() && iv[j].first <= e) {
                e = std::max(e, iv[j].second);
                j++;
            }
            cov += e - s;
            i = j;
        }
        stats_.covered = cov;
    }
    return true;
}

// ---------------------------------------------------------------------------
// Katman A
// ---------------------------------------------------------------------------
void PdblessAnalyzer::scanExports(std::unordered_map<uint32_t, Cand> &cands) {
    std::vector<ExportEntry> exports;
    if (!pe_->readExports(exports, nullptr)) return;
    for (const ExportEntry &e : exports) {
        if (!isExecRva(e.rva)) continue;
        Cand &c = cands[e.rva];
        c.peMeta = 0.95f;
        c.sources.insert("Export");
        if (!e.name.empty()) {
            c.name = e.name;
            c.kind = "export";
        }
        stats_.exportFuncs++;
    }
}

void PdblessAnalyzer::scanPdata(std::unordered_map<uint32_t, Cand> &cands) {
    // x64 .pdata: RUNTIME_FUNCTION {u32 başlangıç, u32 son, u32 unwindBilgisi}
    uint32_t dirRva = pe_->dataDirRva(3), dirSize = pe_->dataDirSize(3);
    if (!dirRva || dirSize < 12 || !is64_) return;
    for (uint32_t off = 0; off + 12 <= dirSize; off += 12) {
        uint32_t recRva = dirRva + off, o;
        if (!rvaToOff(recRva, o) || o + 12 > raw_->size()) continue;
        uint32_t begin = rd32at(*raw_, o), end = rd32at(*raw_, o + 4),
                 unwind = rd32at(*raw_, o + 8);
        if (!begin || begin >= end || end > imageSize_) continue;
        uint32_t uo;
        uint8_t uFlags = 0;
        if (rvaToOff(unwind, uo) && uo + 2 <= raw_->size()) uFlags = (*raw_)[uo + 1] >> 3;
        if (uFlags & 0x4) continue; // UNW_FLAG_CHAININFO: devam bloğu
        pdataStarts_.insert(begin);
        pdataEnds_[begin] = end;
        Cand &c = cands[begin];
        c.peMeta = std::max(c.peMeta, 0.95f);
        c.sources.insert("Pdata");
        stats_.pdataFuncs++;
    }
}

void PdblessAnalyzer::scanGfids(std::unordered_map<uint32_t, Cand> &cands) {
    uint32_t dirRva = pe_->dataDirRva(10), dirSize = pe_->dataDirSize(10);
    if (!dirRva || dirSize < 0x60) return;
    uint32_t o;
    if (!rvaToOff(dirRva, o)) return;
    uint32_t lcSize = rd32at(*raw_, o);
    uint32_t tabOff = is64_ ? 0x70 : 0x54;
    uint32_t cntOff = is64_ ? 0x78 : 0x58;
    if (lcSize < cntOff + 4) return;
    uint32_t tabRva = rd32at(*raw_, o + tabOff);
    uint32_t count = rd32at(*raw_, o + cntOff);
    if (!tabRva || count == 0 || count > imageSize_) return;
    for (uint32_t i = 0; i < count; i++) {
        uint32_t recRva = tabRva + i * 4, ro;
        if (!rvaToOff(recRva, ro) || ro + 4 > raw_->size()) break;
        uint32_t rva = rd32at(*raw_, ro);
        if (!isExecRva(rva)) continue;
        Cand &c = cands[rva];
        c.peMeta = 1.0f; // CFG: işletim sistemi doğrulamış çağrı hedefi
        c.sources.insert("GFIDS");
        stats_.gfidsFuncs++;
    }
}

void PdblessAnalyzer::scanSafeSEH(std::unordered_map<uint32_t, Cand> &cands) {
    uint32_t dirRva = pe_->dataDirRva(10), dirSize = pe_->dataDirSize(10);
    if (!dirRva || dirSize < 0x50) return;
    uint32_t o;
    if (!rvaToOff(dirRva, o)) return;
    if (rd32at(*raw_, o) < 0x50) return;
    uint32_t tblVA = rd32at(*raw_, o + 0x44); // SEHandlerTable (mutlak VA)
    uint32_t count = rd32at(*raw_, o + 0x48); // SEHandlerCount
    if (!tblVA || !count || count > 0x10000) return;
    uint32_t tblRva = (uint32_t)(tblVA - imageBase_);
    if (tblRva >= imageSize_) return;
    for (uint32_t i = 0; i < count; i++) {
        uint32_t recRva = tblRva + i * 4, ro;
        if (!rvaToOff(recRva, ro) || ro + 4 > raw_->size()) break;
        uint32_t va = rd32at(*raw_, ro);
        uint32_t rva = (uint32_t)(va - imageBase_);
        if (!isExecRva(rva)) continue;
        Cand &c = cands[rva];
        c.peMeta = std::max(c.peMeta, 0.9f);
        c.sources.insert("SafeSEH");
        stats_.sehFuncs++;
    }
}

void PdblessAnalyzer::scanTlsCallbacks(std::unordered_map<uint32_t, Cand> &cands) {
    uint32_t dirRva = pe_->dataDirRva(9), dirSize = pe_->dataDirSize(9);
    if (!dirRva || dirSize < (is64_ ? 40u : 24u)) return;
    uint32_t o;
    if (!rvaToOff(dirRva, o)) return;
    uint64_t cbVA = is64_ ? rd64at(*raw_, o + 24) : rd32at(*raw_, o + 12);
    if (!cbVA) return;
    uint32_t cbRva = (uint32_t)(cbVA - imageBase_);
    if (cbRva >= imageSize_) return;
    for (uint32_t i = 0; i < 64; i++) {
        uint32_t recRva = cbRva + i * (is64_ ? 8u : 4u), ro;
        if (!rvaToOff(recRva, ro)) break;
        uint64_t fn = is64_ ? rd64at(*raw_, ro) : rd32at(*raw_, ro);
        if (!fn) break;
        uint32_t rva = (uint32_t)(fn - imageBase_);
        if (!isExecRva(rva)) continue;
        Cand &c = cands[rva];
        c.peMeta = 1.0f;
        c.sources.insert("TLS");
        stats_.tlsFuncs++;
    }
}

void PdblessAnalyzer::scanCoffSymbols(std::unordered_map<uint32_t, Cand> &cands) {
    uint32_t symOff = pe_->coffSymTabOff(), symCount = pe_->coffSymCount();
    if (!symOff || !symCount || symOff >= raw_->size()) return;
    size_t strOff = (size_t)symOff + (size_t)symCount * 18;
    if (strOff + 4 > raw_->size()) return;
    uint32_t strSize = rd32at(*raw_, strOff);
    size_t strBase = strOff + 4;
    auto coffName = [&](const uint8_t *p) -> std::string {
        if (p[0] != 0) return std::string((const char *)p, strnlen((const char *)p, 8));
        uint32_t so = (uint32_t)p[1] | ((uint32_t)p[2] << 8) | ((uint32_t)p[3] << 16) |
                      ((uint32_t)p[4] << 24);
        if (so == 0 || (size_t)so >= strSize) return std::string();
        size_t p2 = strBase + so;
        if (p2 >= raw_->size()) return std::string();
        const char *s = (const char *)raw_->data() + p2;
        return std::string(s, strnlen(s, raw_->size() - p2));
    };

    const auto &secs = pe_->sections();
    for (uint32_t i = 0; i < symCount; i++) {
        size_t so = (size_t)symOff + (size_t)i * 18;
        if (so + 18 > raw_->size()) break;
        const uint8_t *p = raw_->data() + so;
        int16_t secNum = (int16_t)(p[12] | (p[13] << 8));
        uint8_t storage = p[16], numAux = p[17];
        if (numAux) i += numAux; // yardımcı kayıtları atla
        if (secNum <= 0 || (size_t)secNum > secs.size()) continue;
        if (storage != 2 && storage != 3) continue; // dış / yerel
        const SectionHdr &sec = secs[secNum - 1];
        if (!(sec.characteristics & 0x20000000)) continue; // yalnız kod bölümü
        uint32_t value = rd32at(*raw_, so + 8);
        uint32_t rva = sec.virtualAddress + value;
        if (!isExecRva(rva)) continue;
        std::string nm = coffName(p);
        if (nm.empty()) continue;
        if (nm.size() > 1 && nm[0] == '.' && isdigit((unsigned char)nm[1])) continue;
        if (nm.rfind("__merge", 0) == 0 || nm == ".text" || nm == "code") continue;
        if (nm.find("$LN") == 0) continue; // MSVC satır etiketleri
        Cand &c = cands[rva];
        c.peMeta = 1.0f; // derleyici üretimi sembol: kesin
        c.sources.insert("COFF");
        if (c.name.empty()) {
            c.name = nm;
            c.kind = "coff";
        }
        stats_.coffFuncs++;
    }
}

void PdblessAnalyzer::scanRelocTargets(std::unordered_map<uint32_t, Cand> &cands) {
    uint32_t dirRva = pe_->dataDirRva(5), dirSize = pe_->dataDirSize(5);
    if (!dirRva || !dirSize) return;
    uint32_t pos = 0;
    while (pos + 8 <= dirSize) {
        uint32_t blkRva = dirRva + pos, o;
        if (!rvaToOff(blkRva, o) || o + 8 > raw_->size()) break;
        uint32_t pageRva = rd32at(*raw_, o), blockSize = rd32at(*raw_, o + 4);
        if (blockSize < 8 || pos + blockSize > dirSize) break;
        size_t entries = (blockSize - 8) / 2;
        for (size_t i = 0; i < entries; i++) {
            if (o + 8 + i * 2 + 2 > raw_->size()) break;
            uint16_t e = (uint16_t)((*raw_)[o + 8 + i * 2] |
                                    ((*raw_)[o + 8 + i * 2 + 1] << 8));
            uint32_t type = e >> 12, off = e & 0xFFF;
            if (type == 0) continue; // ABS
            uint32_t locRva = pageRva + off;
            if (type == 2) { i++; continue; } // HIGHADJ: iki giriş
            uint64_t val;
            uint32_t vo;
            if (type == 10) { // DIR64
                if (!rvaToOff(locRva, vo)) continue;
                val = rd64at(*raw_, vo);
            } else if (type == 3) { // HIGHLOW
                if (!rvaToOff(locRva, vo)) continue;
                val = rd32at(*raw_, vo);
            } else {
                continue;
            }
            if (val < imageBase_ || val >= imageBase_ + imageSize_) continue;
            uint32_t target = (uint32_t)(val - imageBase_);
            if (!isExecRva(target)) continue;
            if (importNames_.count(locRva)) continue; // IAT: veri, işlev değil
            Cand &c = cands[target];
            c.peMeta = std::max(c.peMeta, 0.92f);
            c.sources.insert("RelocPtr");
            stats_.relocPtrFuncs++;
        }
        pos += blockSize;
    }
}

void PdblessAnalyzer::scanImportThunks(std::unordered_map<uint32_t, Cand> &cands) {
    // jmp [IAT] saplamaları: x86/x64: FF 25 <rel32>
    if (importNames_.empty()) return;
    for (const SecView &v : secViews_) {
        if (!v.exec) continue;
        size_t end = std::min<size_t>((size_t)v.off + v.span, raw_->size());
        for (size_t o = v.off; o + 6 <= end; o++) {
            if ((*raw_)[o] != 0xFF || (*raw_)[o + 1] != 0x25) continue;
            uint32_t rva = v.va + (uint32_t)(o - v.off);
            int32_t rel = (int32_t)rd32at(*raw_, o + 2);
            uint32_t target = rva + 6 + (uint32_t)rel;
            auto it = importNames_.find(target);
            if (it == importNames_.end()) continue;
            Cand &c = cands[rva];
            c.peMeta = std::max(c.peMeta, 0.95f);
            c.sources.insert("Import");
            if (c.name.empty()) {
                c.name = "imp:" + it->second;
                c.kind = "import";
            }
            stats_.importThunks++;
        }
    }
}

// ---------------------------------------------------------------------------
// Katman B: RTTI + vftable
// ---------------------------------------------------------------------------
static std::string rttiNameClean(const char *s) {
    std::string n(s);
    if (n.size() < 5) return n;
    size_t p = 4; // ".?AV" class / ".?AU" struct / ".?AW" interface / ".?AT" union
    if (n.size() > 5 && n[2] == 'W' && n[3] == '4') p = 5; // ".?AW4" enum
    n = n.substr(p);
    if (n.size() >= 2 && n.substr(n.size() - 2) == "@@") n.resize(n.size() - 2);
    for (size_t i = 0; i + 1 < n.size(); i++) {
        if (n[i] == '@' && n[i + 1] == '@') {
            n[i] = ':';
            n[i + 1] = ':';
            i++;
        }
    }
    return n;
}

void PdblessAnalyzer::scanRtti(std::unordered_map<uint32_t, Cand> &cands) {
    struct Td {
        uint32_t rva;
        std::string className;
    };
    std::vector<Td> tds;

    // 1) type_info tanımlayıcıları: veri bölümlerinde ".?A?" dizgeleri.
    //    TD: x86 {u32 vftPtr, u32 yedek=0, ad}; x64 {u64 vftPtr, u64 yedek, ad}
    uint64_t tiVftVA = 0;
    for (const SecView &v : secViews_) {
        if (v.exec) continue;
        size_t end = std::min<size_t>((size_t)v.off + v.span, raw_->size() - 1);
        for (size_t o = v.off; o + 8 < end; o++) { // isimler hizasız olabilir: her bayt
            if (memcmp(raw_->data() + o, ".?A", 3) != 0) continue;
            char c4 = (char)(*raw_)[o + 3];
            if (c4 != 'V' && c4 != 'U' && c4 != 'W' && c4 != 'T') continue;
            const char *s = (const char *)raw_->data() + o;
            size_t rem = std::min<size_t>(raw_->size() - o, 120);
            size_t len = strnlen(s, rem);
            if (len < 6 || len >= rem) continue;
            if (len < 2 || strcmp(s + len - 2, "@@") != 0) continue;

            uint32_t nameRva = v.va + (uint32_t)(o - v.off);
            if (is64_) {
                if (nameRva < 16 || o < 16) continue;
                if (rd32at(*raw_, o - 8) != 0) continue; // yedek u64 sıfır
                uint64_t vft = rd64at(*raw_, o - 16);
                if (vft < imageBase_ || vft >= imageBase_ + imageSize_) continue;
                if (strcmp(s, ".?AVtype_info@@") == 0) tiVftVA = vft;
                tds.push_back({nameRva - 16, rttiNameClean(s)});
            } else {
                if (nameRva < 8 || o < 8) continue;
                if (rd32at(*raw_, o - 4) != 0) continue; // yedek u32 sıfır
                uint32_t vft = rd32at(*raw_, o - 8);
                if (vft < imageBase_ || vft >= imageBase_ + imageSize_) continue;
                if (strcmp(s, ".?AVtype_info@@") == 0) tiVftVA = vft;
                tds.push_back({nameRva - 8, rttiNameClean(s)});
            }
        }
    }
    if (tds.empty() || tiVftVA == 0) {
        // type_info vftable bilinmiyorsa doğrulama zayıflar; yine de devam
        // (tiVftVA == 0 durumunda TD'leri olduğu gibi kabul ediyoruz)
    }

    // 2) COL'lar: {u32 imza (x86=0/x64=1), u32 offCol, u32 pTD}
    //    (pTD eşleşmesi karma tabloyla — sınıf sayısı büyük olabilir)
    struct Col {
        uint32_t colRva, tdRva;
    };
    std::vector<Col> cols;
    {
        std::unordered_map<uint32_t, uint32_t> tdMap; // tdRva -> tds indeksi
        for (uint32_t i = 0; i < tds.size(); i++) tdMap.emplace(tds[i].rva, i);
        for (const SecView &v : secViews_) {
            if (v.exec) continue;
            size_t end = std::min<size_t>((size_t)v.off + v.span, raw_->size() - 1);
            for (size_t o = v.off; o + 16 < end; o += 4) {
                uint32_t sig = rd32at(*raw_, o), offCol = rd32at(*raw_, o + 4),
                         pTd = rd32at(*raw_, o + 8);
                if (is64_ ? (sig != 1) : (sig != 0)) continue;
                if (offCol > 0x10000) continue;
                uint32_t tdRva = is64_ ? pTd : (uint32_t)(pTd - imageBase_);
                if (!tdRva || tdRva >= imageSize_) continue;
                if (tdMap.count(tdRva))
                    cols.push_back({v.va + (uint32_t)(o - v.off), tdRva});
            }
        }
    }
    if (cols.empty()) return;

    // 3) vftable: COL'a işaret eden sözcük (tek geçiş, tablo araması)
    //    x86: işaretçi değeri = ImageBase + colRva (mutlak VA)
    //    x64: işaretçi değeri = colRva (4 bayt RVA)
    std::unordered_map<uint32_t, uint32_t> colByPtr; // beklenen değer -> col idx
    for (uint32_t i = 0; i < cols.size(); i++) {
        uint32_t val = is64_ ? cols[i].colRva
                             : (uint32_t)(imageBase_ + cols[i].colRva);
        colByPtr.emplace(val, i);
    }
    for (const SecView &v : secViews_) {
        if (v.exec) continue;
        size_t end = std::min<size_t>((size_t)v.off + v.span, raw_->size() - 1);
        for (size_t o = v.off; o + 4 < end; o += 4) {
            auto it = colByPtr.find(rd32at(*raw_, o));
            if (it == colByPtr.end()) continue;
            const Col &col = cols[it->second];

            uint32_t vtRva = v.va + (uint32_t)(o - v.off) + 4;
            PlVtable vt;
            vt.rva = vtRva;
            vt.colRva = col.colRva;
            for (const Td &td : tds)
                if (td.rva == col.tdRva) vt.className = td.className;

            int nonCode = 0;
            for (uint32_t i = 0; i < 512; i++) {
                uint32_t eRva = vtRva + i * (is64_ ? 8u : 4u);
                uint64_t fn = is64_ ? rd64rva(eRva) : rd32rva(eRva);
                if (fn == 0) break;
                if (fn < imageBase_ || fn >= imageBase_ + imageSize_) break;
                uint32_t fRva = (uint32_t)(fn - imageBase_);
                if (!isExecRva(fRva)) {
                    nonCode++;
                    if (nonCode >= 2) break; // art arda 2 kod-dışı: tablo bitti
                    continue;
                }
                nonCode = 0;
                vt.funcRvas.push_back(fRva);
            }
            if (!vt.className.empty() && !vt.funcRvas.empty())
                vtables_.push_back(std::move(vt));
        }
    }

    // 4) sanal fonksiyon adayları
    for (const PlVtable &vt : vtables_) {
        for (size_t i = 0; i < vt.funcRvas.size(); i++) {
            uint32_t rva = vt.funcRvas[i];
            Cand &c = cands[rva];
            c.rtti = 0.88f;
            c.sources.insert("RTTI_VF");
            if (c.name.empty()) {
                c.name = vt.className + "::vf" + std::to_string(i);
                c.kind = "vfunc";
            }
            stats_.rttiVfuncs++;
        }
    }
    stats_.rttiClasses = (uint32_t)vtables_.size();
}

// ---------------------------------------------------------------------------
// Katman C: doğrudan çağrı hedefleri + JCC hedefleri
// ---------------------------------------------------------------------------
void PdblessAnalyzer::scanCalls(std::unordered_map<uint32_t, Cand> &cands) {
    std::unordered_set<uint32_t> jccTargets;

    for (const SecView &v : secViews_) {
        if (!v.exec) continue;
        size_t end = std::min<size_t>((size_t)v.off + v.span, raw_->size() - 1);
        for (size_t o = v.off; o + 6 < end; o++) {
            uint8_t b0 = (*raw_)[o];
            uint32_t rva = v.va + (uint32_t)(o - v.off);

            if (b0 == 0xE8 || b0 == 0xE9) { // call/jmp rel32
                int32_t rel = (int32_t)rd32at(*raw_, o + 1);
                uint32_t target = rva + 5 + (uint32_t)rel;
                if (isExecRva(target)) {
                    Cand &c = cands[target];
                    c.call = 0.6f;
                    c.callers++;
                    c.sources.insert("CallTarget");
                }
            } else if (b0 >= 0x70 && b0 <= 0x7F) { // kısa JCC
                int8_t rel = (int8_t)(*raw_)[o + 1];
                uint32_t target = rva + 2 + (uint32_t)rel;
                if (isExecRva(target)) jccTargets.insert(target);
            } else if (b0 == 0x0F) { // yakın JCC
                uint8_t b1 = (*raw_)[o + 1];
                if (b1 >= 0x80 && b1 <= 0x8F) {
                    int32_t rel = (int32_t)rd32at(*raw_, o + 2);
                    uint32_t target = rva + 6 + (uint32_t)rel;
                    if (isExecRva(target)) jccTargets.insert(target);
                }
            }
        }
    }

    // JCC-içi reddi işaretle (puanlamada değerlendirilir)
    for (uint32_t t : jccTargets) {
        auto it = cands.find(t);
        if (it != cands.end() && it->second.callers > 0) it->second.jccInside = true;
    }
}

// ---------------------------------------------------------------------------
// Katman E: prolog kalıpları
// ---------------------------------------------------------------------------
PdblessAnalyzer::PrologueResult PdblessAnalyzer::detectPrologue(uint32_t rva,
                                                                int &lenUsed) const {
    (void)lenUsed;
    PrologueResult r;
    uint32_t o;
    if (!rvaToOff(rva, o) || o + 16 > raw_->size()) return r;
    const uint8_t *p = raw_->data() + o;

    if (is64_) {
        if (p[0] == 0x48 && p[1] == 0x89 && p[2] == 0x5C && p[3] == 0x24) {
            r.found = true; r.confidence = 92; r.desc = "mov[rsp+8],rbx"; r.length = 5;
        } else if (p[0] == 0x48 && p[1] == 0x89 &&
                   (p[2] == 0x6C || p[2] == 0x74 || p[2] == 0x7C || p[2] == 0x4C) &&
                   p[3] == 0x24) {
            r.found = true; r.confidence = 90; r.desc = "mov[rsp+8],r64"; r.length = 5;
        } else if (p[0] == 0x55 && p[1] == 0x48 && p[2] == 0x8B && p[3] == 0xEC) {
            r.found = true; r.confidence = 93; r.desc = "push rbp; mov rbp,rsp"; r.length = 4;
        } else if (p[0] == 0x48 && p[1] == 0x8B && p[2] == 0xEC) {
            r.found = true; r.confidence = 88; r.desc = "mov rbp,rsp"; r.length = 3;
        } else if (p[0] == 0x48 && p[1] == 0x83 && p[2] == 0xEC) {
            r.found = true; r.confidence = 85; r.desc = "sub rsp,imm8"; r.length = 4;
        } else if (p[0] == 0x48 && p[1] == 0x81 && p[2] == 0xEC) {
            r.found = true; r.confidence = 85; r.desc = "sub rsp,imm32"; r.length = 7;
        } else if (p[0] == 0x4C && p[1] == 0x8B && p[2] == 0xDC) {
            r.found = true; r.confidence = 85; r.desc = "mov r11,rsp"; r.length = 3;
        } else if (p[0] == 0x40 && (p[1] >= 0x53 && p[1] <= 0x57)) {
            r.found = true; r.confidence = 88; r.desc = "push r64 (rex)"; r.length = 2;
        } else if (p[0] == 0x41 && (p[1] >= 0x54 && p[1] <= 0x57)) {
            r.found = true; r.confidence = 86; r.desc = "push r12..r15"; r.length = 2;
        } else if (p[0] == 0x48 && p[1] == 0x89 && p[2] == 0x44 && p[3] == 0x24) {
            r.found = true; r.confidence = 85; r.desc = "mov[rsp+8],rax"; r.length = 5;
        } else if (p[0] >= 0x50 && p[0] <= 0x57) {
            r.found = true; r.confidence = 60; r.desc = "push r64"; r.length = 1;
        }
        return r;
    }

    // x86
    if (p[0] == 0x8B && p[1] == 0xFF && p[2] == 0x55 && p[3] == 0x8B && p[4] == 0xEC) {
        r.found = true; r.confidence = 99; r.desc = "hotpatch+ebp"; r.length = 5;
    } else if (p[0] == 0x55 && p[1] == 0x8B && p[2] == 0xEC) {
        if (p[3] == 0x6A) {
            r.found = true; r.confidence = 97; r.desc = "ebp+push imm8"; r.length = 4;
        } else if (p[3] == 0x68) {
            r.found = true; r.confidence = 97; r.desc = "ebp+push imm32"; r.length = 7;
        } else if (p[3] == 0x81 && p[4] == 0xEC) {
            r.found = true; r.confidence = 97; r.desc = "ebp+sub esp,imm32"; r.length = 9;
        } else if (p[3] == 0x83 && p[4] == 0xEC) {
            r.found = true; r.confidence = 95; r.desc = "ebp+sub esp,imm8"; r.length = 6;
        } else {
            r.found = true; r.confidence = 90; r.desc = "ebp cercevesi"; r.length = 3;
        }
    } else if (p[0] == 0x55 && p[1] == 0x89 && p[2] == 0xE5) {
        r.found = true; r.confidence = 88; r.desc = "gcc ebp cercevesi"; r.length = 3;
    } else if (p[0] == 0x68) {
        // push imm32; mov eax, fs:[0] — SEH
        if (o + 11 <= raw_->size() && (*raw_)[o + 5] == 0x64 && (*raw_)[o + 6] == 0xA1) {
            r.found = true; r.confidence = 80; r.desc = "SEH kurulum"; r.length = 10;
        }
    } else if (p[0] == 0x6A && p[1] == 0xFF && p[2] == 0x68) {
        r.found = true; r.confidence = 88; r.desc = "SEH4 prolog"; r.length = 8;
    } else if ((p[0] == 0x56 || p[0] == 0x57) && p[1] == 0x8B && p[2] == 0xF1) {
        r.found = true; r.confidence = 72; r.desc = "thiscall esi,ecx"; r.length = 3;
    } else if (p[0] == 0x57 && p[1] == 0x8B && p[2] == 0xF9) {
        r.found = true; r.confidence = 72; r.desc = "thiscall edi,ecx"; r.length = 3;
    } else if (p[0] == 0x83 && p[1] == 0xEC) {
        r.found = true; r.confidence = 65; r.desc = "sub esp,imm8 (FPO)"; r.length = 3;
    } else if (p[0] == 0x81 && p[1] == 0xEC) {
        r.found = true; r.confidence = 68; r.desc = "sub esp,imm32 (FPO)"; r.length = 6;
    }
    return r;
}

void PdblessAnalyzer::scanPrologues(std::unordered_map<uint32_t, Cand> &cands) {
    // .pdata zenginse (x64): pdata'ya girmeyen saf-prolog adayları çoğunlukla
    // veri/hizalama gürültüsüdür — yüksek güvenli kalıplar istenir
    int minConf = pdataStarts_.size() > 50 ? 85 : 60;
    for (const SecView &v : secViews_) {
        if (!v.exec) continue;
        size_t end = std::min<size_t>((size_t)v.off + v.span, raw_->size() - 1);
        for (size_t o = v.off; o + 4 < end; o++) {
            uint32_t rva = v.va + (uint32_t)(o - v.off);
            int lenUsed = 0;
            PrologueResult pr = detectPrologue(rva, lenUsed);
            if (!pr.found || pr.confidence < minConf) continue;
            Cand &c = cands[rva];
            if (pr.confidence / 100.0f > c.prologue) {
                c.prologue = pr.confidence / 100.0f;
                c.sources.insert("Prologue");
                c.evidence.push_back(pr.desc);
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Puanlama + sınıflandırma (BrainMapCore ConfidenceEngine yöntemi)
// ---------------------------------------------------------------------------
void PdblessAnalyzer::scoreAndFinish(std::unordered_map<uint32_t, Cand> &cands,
                                     const PdblessOpts &opts) {
    funcs_.clear();
    std::vector<std::pair<uint32_t, Cand>> sorted(cands.begin(), cands.end());
    std::sort(sorted.begin(), sorted.end(),
              [](const auto &a, const auto &b) { return a.first < b.first; });
    stats_.candidates = (uint32_t)cands.size();

    for (auto &kv : sorted) {
        uint32_t rva = kv.first;
        Cand &c = kv.second;

        // --- katman D: sınır kanıtı ---
        {
            float bc = 0;
            int cc = 0;
            bool retBefore = false;
            for (int i = 1; i <= 20 && rva >= (uint32_t)i; i++) {
                uint8_t b = rva8(rva - i);
                if (b == 0xCC) cc++;
                else if (b == 0xC3 || b == 0xC2) { retBefore = true; break; }
                else if (b == 0x90) continue;
                else break;
            }
            if (cc >= 2) bc = 0.6f;
            else if (cc == 1) bc = 0.15f;
            if (retBefore) bc = std::max(bc, 0.5f);
            if (cc >= 2 && retBefore) bc = 0.75f;
            uint32_t o5;
            if (rva >= 5 && rvaToOff(rva - 5, o5) && (*raw_)[o5] == 0xE9)
                bc = std::max(bc, 0.55f); // kuyruk jmp
            if (bc > 0) {
                c.boundary = bc;
                c.sources.insert("Boundary");
                c.evidence.push_back(cc >= 2 ? "int3 dolgusu"
                                             : (retBefore ? "ret oncesi" : "jmp siniri"));
            }
        }

        float mx = std::max({c.peMeta, c.rtti, c.call, c.boundary, c.prologue});
        int layers = 0;
        if (c.peMeta > 0.3f) layers++;
        if (c.rtti > 0.3f) layers++;
        if (c.call > 0.3f) layers++;
        if (c.boundary > 0.3f) layers++;
        if (c.prologue > 0.3f) layers++;
        float mult = 1.0f + 0.1f * std::max(layers - 1, 0);
        float conf = std::min(mx * mult, 1.0f);
        if (c.peMeta >= 0.9f && layers >= 2) conf = 1.0f;
        if (c.rtti > 0.5f && c.call > 0.5f) conf = std::max(conf, 0.95f);

        // JCC-içi reddi: zayıf destekli fonksiyon-ortası adayları süz
        if (c.jccInside) {
            bool strongSupport = (c.peMeta >= 0.5f) || (c.rtti >= 0.5f) ||
                                 (c.boundary >= 0.5f) || (c.prologue >= 0.7f);
            if (!strongSupport) conf = std::min(conf, 0.15f);
        }
        // çağıranı olmayan salt-çağrı-hedefi adayı zayıflat
        if (c.call > 0 && c.callers == 0 && mx <= c.call) conf *= 0.7f;

        PlFunction f;
        f.rva = rva;
        f.confidence = conf;
        f.callerCount = c.callers;
        f.sources = c.sources;
        f.evidence = c.evidence;
        f.name = c.name.empty() ? ("sub_" + hexU32(rva, 1)) : c.name;
        f.kind = c.kind.empty() ? "func" : c.kind;

        if (conf >= 0.9f) { f.cls = PlFunction::CERTAIN; stats_.certain++; }
        else if (conf >= 0.7f) { f.cls = PlFunction::HIGH; stats_.high++; }
        else if (conf >= 0.4f) { f.cls = PlFunction::MEDIUM; stats_.medium++; }
        else if (conf >= 0.2f) { f.cls = PlFunction::LOW; stats_.low++; }
        else { f.cls = PlFunction::REJECT; stats_.rejected++; }

        if (conf >= opts.minConfidence || f.cls == PlFunction::CERTAIN)
            funcs_.push_back(std::move(f));
    }
    stats_.accepted = (uint32_t)funcs_.size();
}

// ---------------------------------------------------------------------------
// Aralık çakışması çözümü: önce kesin (.pdata / yüksek güvenli) aralıklar
// yerleşir; içine düşen düşük güvenli adaylar fonksiyon-ortası gürültü
// olarak atılır. IDA'nın başlangıç analizindeki "function start wins" kuralı.
// ---------------------------------------------------------------------------
void PdblessAnalyzer::dropInside() {
    if (funcs_.empty()) return;

    struct Iv {
        uint32_t s, e;
        float conf;
        size_t idx;
        bool pdata;
    };
    std::vector<Iv> ivs;
    ivs.reserve(funcs_.size());
    for (size_t i = 0; i < funcs_.size(); i++) {
        const PlFunction &f = funcs_[i];
        if (f.cls == PlFunction::REJECT) continue;
        auto pe = pdataEnds_.find(f.rva);
        uint32_t end = pe != pdataEnds_.end() ? pe->second
                                              : (f.size ? f.rva + f.size : f.rva + 1);
        if (end <= f.rva) end = f.rva + 1;
        ivs.push_back({f.rva, end, f.confidence, i, pe != pdataEnds_.end()});
    }

    // öncelik: pdata > güven > küçük RVA (önce yerleşen kazanır)
    std::sort(ivs.begin(), ivs.end(), [](const Iv &a, const Iv &b) {
        if (a.pdata != b.pdata) return a.pdata;
        if (a.conf != b.conf) return a.conf > b.conf;
        return a.s < b.s;
    });

    // yerleşen aralıklar başlangıca göre sıralı tutulur (ikili arama, O(n log n))
    std::vector<std::pair<uint32_t, uint32_t>> placed; // [başlangıç, son)
    std::vector<bool> drop(funcs_.size(), false);
    for (const Iv &iv : ivs) {
        bool inside = false;
        // iv.s'yi içeren aralık: başlangıcı <= iv.s olan en büyük
        auto it = std::upper_bound(placed.begin(), placed.end(),
                                   std::make_pair(iv.s, UINT32_MAX));
        if (it != placed.begin()) {
            --it;
            if (iv.s >= it->first && iv.s < it->second) inside = true;
            else if (it != placed.begin() && iv.s == it->first) inside = true;
        }
        if (!inside && it != placed.begin()) {
            // aynı başlangıçlı önceki (önceliği yüksek) var mı?
            auto pit = it;
            while (pit != placed.begin() && (pit - 1)->first == iv.s) {
                --pit;
                if (iv.s >= pit->first && iv.s < pit->second) { inside = true; break; }
                if (iv.s == pit->first) { inside = true; break; }
            }
        }
        if (inside) {
            drop[iv.idx] = true;
            stats_.rejected++;
            stats_.accepted--;
        } else {
            placed.insert(std::upper_bound(placed.begin(), placed.end(),
                                           std::make_pair(iv.s, iv.e)),
                          {iv.s, iv.e});
        }
    }

    std::vector<PlFunction> kept;
    kept.reserve(funcs_.size());
    for (size_t i = 0; i < funcs_.size(); i++)
        if (!drop[i]) kept.push_back(std::move(funcs_[i]));
    funcs_.swap(kept);

    // sınıf sayaçlarını yeniden hesapla
    stats_.certain = stats_.high = stats_.medium = stats_.low = 0;
    for (const PlFunction &f : funcs_) {
        switch (f.cls) {
        case PlFunction::CERTAIN: stats_.certain++; break;
        case PlFunction::HIGH: stats_.high++; break;
        case PlFunction::MEDIUM: stats_.medium++; break;
        case PlFunction::LOW: stats_.low++; break;
        default: break;
        }
    }
}

// ---------------------------------------------------------------------------
// Boyut tahmini
// ---------------------------------------------------------------------------
void PdblessAnalyzer::estimateSizes() {
    for (size_t i = 0; i < funcs_.size(); i++) {
        PlFunction &f = funcs_[i];
        auto pe = pdataEnds_.find(f.rva);
        if (pe != pdataEnds_.end() && pe->second > f.rva) {
            f.size = pe->second - f.rva; // x64 .pdata: kesin
            continue;
        }
        // tarama sınırı: fonksiyonun çalıştırılabilir bölümü + sonraki aday.
        // NOT: yalnız BAŞLANGIÇ KANITI olan adaylar (pdata/export/coff/rtti/
        // reloc/import/bölge) sınır belirler; saf prolog gürültüsü kesmez.
        uint32_t rangeEnd = f.rva + 1;
        for (const auto &r : execRanges_)
            if (f.rva >= r.first && f.rva < r.second) { rangeEnd = r.second; break; }
        uint32_t limit = std::min(rangeEnd, f.rva + 0x10000);
        for (size_t j = i + 1; j < funcs_.size(); j++) {
            if (funcs_[j].rva <= f.rva) continue;
            bool hasStartEvidence = pdataStarts_.count(funcs_[j].rva) ||
                                     funcs_[j].sources.count("Export") ||
                                     funcs_[j].sources.count("COFF") ||
                                     funcs_[j].sources.count("RTTI_VF") ||
                                     funcs_[j].sources.count("RelocPtr") ||
                                     funcs_[j].sources.count("Import") ||
                                     funcs_[j].sources.count("TLS") ||
                                     funcs_[j].sources.count("EntryPoint") ||
                                     funcs_[j].sources.count("SafeSEH") ||
                                     funcs_[j].sources.count("GFIDS");
            if (hasStartEvidence) {
                limit = std::min(limit, funcs_[j].rva);
                break;
            }
        }
        if (limit <= f.rva + 1) { f.size = 0; continue; }

        uint32_t lastRet = 0;
        bool done = false;
        for (uint32_t a = f.rva; a < limit && !done; a++) {
            uint8_t b = rva8(a);
            if (b == 0xC3) {
                lastRet = a + 1;
                uint32_t ar = a + 1;
                if (rva8(ar) == 0xCC) {
                    while (rva8(ar) == 0xCC && ar < limit) ar++;
                    f.size = ar - f.rva;
                    done = true;
                }
            } else if (b == 0xC2 && a + 3 < limit) {
                lastRet = a + 3;
                uint32_t ar = a + 3;
                if (rva8(ar) == 0xCC) {
                    while (rva8(ar) == 0xCC && ar < limit) ar++;
                    f.size = ar - f.rva;
                    done = true;
                }
            } else if (b == 0xCC && lastRet) {
                f.size = lastRet - f.rva;
                done = true;
            }
        }
        if (!done && lastRet) f.size = lastRet - f.rva;
        // bölüm dışına taşan/geçersiz boyutları temizle
        if (f.size && (f.rva + f.size > rangeEnd || f.size > 0x100000)) f.size = 0;
    }
}

} // namespace pdbscope
