// ============================================================================
//  PDBScope — pdb.h
//  Yerel (CodeView) PDB dosyası ayrıştırıcı: bilgi akışı, DBI, modüller,
//  sembol kayıtları, OMAP, bölüm başlıkları.
//
//  Akış yerleşimi (LLVM DebugInfo/PDB referansı):
//    1 = PDB bilgi akışı   2 = TPI   3 = DBI   4 = IPI
//    Diğer akışlar DBI başlığı / adlandırılmış akış haritasından bulunur.
// ============================================================================
#pragma once

#include <cstdint>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include "msf.h"
#include "types.h"

namespace pdbscope {

// ---------------------------------------------------------------------------
enum class SymKind {
    Function,   // S_GPROC32 / S_LPROC32 (+_ID, +_ST)
    Public,     // S_PUB32
    Thunk,      // S_THUNK32
    Trampoline, // S_TRAMPOLINE
    Data,       // S_GDATA32 / S_LDATA32
    Label,      // S_LABEL32
    Inline,     // S_INLINESITE (satır içi genişleme)
};

const char *symKindName(SymKind k);

struct Symbol {
    uint32_t rva = 0;       // son RVA (OMAP uygulanmış); 0 = bilinmiyor
    uint32_t origRva = 0;   // OMAP öncesi orijinal düzen RVA'sı
    uint16_t seg = 0;       // 1 tabanlı bölüm indeksi (orijinal düzen)
    uint32_t off = 0;       // bölüm içi göreli konum
    uint32_t size = 0;      // 0 = bilinmiyor (PUB32'de boyut yoktur)
    SymKind kind = SymKind::Public;
    bool isCode = false;
    bool isFunction = false;
    uint32_t typeIndex = 0;
    int32_t module = -1;    // -1: global/public akışından
    std::string name;       // ham (mangled) ad

    // v2: satır içi (inline) semboller için
    uint32_t inlineeId = 0; // IPI kimlik indeksi (LF_FUNC_ID)
    uint32_t parentRva = 0; // içine genişletildiği yordamın RVA'sı
    bool typeIdIsId = false; // typeIndex IPI kimliği mi (S_GPROC32_ID), TPI tipi mi

    bool hasRva() const { return rva != 0 || origRva != 0; }
};

// FPO çerçeve bilgisi (eski FPO akışı + yeni FRAMEDATA akışı)
struct FpoEntry {
    uint32_t origRva = 0;   // kayıttaki (orijinal düzen) başlangıç
    uint32_t rva = 0;       // OMAP sonrası
    uint32_t size = 0;      // cbProcSize / cbBlock
    uint32_t localsBytes = 0;
    uint32_t paramsBytes = 0;
    uint16_t prologBytes = 0;
    uint16_t savedRegs = 0; // eski FPO: kayıt sayısı; Yeni: bayt
    uint8_t frameType = 0;  // 0=FPO, 1=trap, 2=tss, 3=ebp çerçevesi
    bool hasSEH = false;
    bool hasEH = false;     // yalnız FRAMEDATA
    bool usesBP = false;    // yalnız eski FPO
    bool isFuncStart = true; // yalnız FRAMEDATA
    bool isNew = false;     // kaynağı: NewFPO akışı mı
};

// Derleyici bilgisi (modül akışındaki S_COMPILE3)
struct CompilerInfo {
    bool found = false;
    uint16_t machine = 0;    // hedef işlemci (CV_CPU_TYPE)
    uint16_t feMajor = 0, feMinor = 0, feBuild = 0, feQfe = 0;
    uint16_t beMajor = 0, beMinor = 0, beBuild = 0, beQfe = 0;
    uint8_t language = 0;    // CV_CFL_LANG
    bool gs = false, hotpatch = false, ltcg = false, sdl = false, pgo = false;
    std::string versionStr;  // örn. "Microsoft (R) Optimizing Compiler"
    int32_t module = -1;
};

// PE / PDB bölüm başlığı (IMAGE_SECTION_HEADER ile aynı düzende)
struct SectionHdr {
    char name[9] = {0};
    uint32_t virtualSize = 0;
    uint32_t virtualAddress = 0;
    uint32_t sizeOfRawData = 0;
    uint32_t characteristics = 0;
};

struct OmapEntry {
    uint32_t from;
    uint32_t to;
};

struct ModuleInfo {
    int32_t index = 0;
    std::string moduleName;   // örn. "* CIL *", "main.obj"
    std::string objName;      // tam nesne dosyası yolu
    uint16_t stream = 0xFFFF;
    uint32_t symBytes = 0;
    uint32_t c11Bytes = 0;
    uint32_t c13Bytes = 0;
    uint16_t numFiles = 0;
    // ilk bölüm katkısı
    uint16_t scSect = 0;
    uint32_t scOff = 0;
    uint32_t scSize = 0;
    bool hasSymbols = false;
    uint32_t symbolCount = 0; // ayrıştırma sonrası doldurulur
};

struct DbiInfo {
    uint32_t version = 0;
    uint32_t age = 0;
    uint16_t gsiStream = 0xFFFF;
    uint16_t publicStream = 0xFFFF;
    uint16_t symrecStream = 0xFFFF;
    uint16_t machine = 0;
    uint16_t flags = 0;
    uint16_t buildNumber = 0;
    uint16_t pdbDllVersion = 0;
    // dbg alt akışı indeksleri (DbgHeaderType sırası)
    uint16_t dbgStreams[11] = {0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
                               0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF};
};

struct TpiInfo {
    uint32_t version = 0;
    uint32_t firstIndex = 0;
    uint32_t lastIndex = 0;
    uint32_t recordBytes = 0;
    uint16_t hashStream = 0xFFFF;
    uint32_t typeCount() const { return lastIndex > firstIndex ? lastIndex - firstIndex : 0; }
};

struct CollectOpts {
    bool walkModules = true;   // modül akışlarından yordam/thunk/veri
    bool walkGlobals = true;   // sembol kayıt akışından public/global veri
    bool includeData = true;
    bool includeLabels = false;
    bool includeThunks = true;
    bool includeInline = false; // S_INLINESITE genişletmeleri
    bool merge = true;         // (adres+ad) tekilleştirme
};

struct CollectStats {
    uint32_t moduleRecords = 0;
    uint32_t globalRecords = 0;
    uint32_t skippedBad = 0;
    uint32_t mergedAway = 0;
    uint32_t noSection = 0;
};

class PdbFile {
public:
    bool open(const std::string &path, std::string *err);

    // ---- üstveri ----
    const std::string &path() const { return path_; }
    uint32_t infoVersion() const { return infoVersion_; }
    uint32_t age() const { return age_; }
    const uint8_t *guid() const { return guid_; } // 16 bayt
    uint32_t features() const { return features_; }
    const DbiInfo &dbi() const { return dbi_; }
    const TpiInfo &tpi() const { return tpi_; }
    const TpiInfo &ipi() const { return ipi_; }
    const std::vector<ModuleInfo> &modules() const { return modules_; }
    const std::map<std::string, uint32_t> &namedStreams() const { return namedStreams_; }
    const MsfFile &msf() const { return msf_; }
    const std::string &ecName(uint32_t ni) const; // /names dizge tablosu

    // ---- bölüm/OMAP bilgisi ----
    const std::vector<SectionHdr> &sections() const { return sections_; }        // güncel
    const std::vector<SectionHdr> &sectionsOrig() const { return sectionsOrig_; } // orijinal
    bool hasOmap() const { return !omapFrom_.empty(); }
    const std::vector<OmapEntry> &omapFromPublic() const { return omapFrom_; }
    const std::vector<OmapEntry> &omapToPublic() const { return omapTo_; }
    static uint32_t omapRemap(const std::vector<OmapEntry> &entries, uint32_t addr);

    // ---- semboller ----
    // Tüm sembol kaynaklarını gezerek birleşik liste üretir.
    bool collectSymbols(const CollectOpts &opts, std::vector<Symbol> &out,
                        CollectStats *stats, std::string *err);

    // (seg, off) -> (origRva, rva). Bölüm bulunamazsa false.
    bool segOffToRva(uint16_t seg, uint32_t off, uint32_t &origRva, uint32_t &rva) const;

    // ---- v2: TPI/IPI tipleri ----
    // Tip depolarını (ilk kullanımda) yükler. Başarısızsa boş depolar.
    const TypeStore &tpiStore() const;
    const TypeStore &ipiStore() const;

    // ---- v2: FPO ----
    bool hasFpo() const { return !fpo_.empty(); }
    const std::vector<FpoEntry> &fpoEntries() const { return fpo_; }
    // origRva'ya en yakın FPO kaydı (binary search)
    const FpoEntry *fpoFor(uint32_t rva) const;

    // ---- v2: derleyici bilgisi ----
    // Modül akışlarından S_COMPILE3 kayıtlarını toplar.
    bool collectCompilers(std::vector<CompilerInfo> &out) const;

    // IPI kimliğinden ad (inline semboller için)
    std::string idNameOf(uint32_t idIndex) const;

private:
    bool parseInfoStream(std::string *err);
    bool parseDbiStream(std::string *err);
    bool parseSectionHdrStream(uint16_t idx, std::vector<SectionHdr> &out);
    bool parseOmapStream(uint16_t idx, std::vector<OmapEntry> &out);
    bool parseTpiStream(uint32_t idx, TpiInfo &out);
    bool parseStringTable(std::string *err);

    void walkSymbolRecords(const uint8_t *data, size_t size, int32_t moduleIdx,
                           const CollectOpts &opts, std::vector<Symbol> &out,
                           CollectStats *stats);
    void addSymbol(const Symbol &s, const CollectOpts &opts, std::vector<Symbol> &out,
                   CollectStats *stats);
    void parseFpoStreams();
    void remapFpoEntries();
    void ensureTypes() const;

    std::string path_;
    MsfFile msf_;

    uint32_t infoVersion_ = 0;
    uint32_t age_ = 0;
    uint8_t guid_[16] = {0};
    uint32_t features_ = 0;
    std::map<std::string, uint32_t> namedStreams_;
    std::vector<uint8_t> namesBuf_; // /names ham dizge tamponu

    DbiInfo dbi_;
    TpiInfo tpi_, ipi_;
    std::vector<ModuleInfo> modules_;
    std::vector<SectionHdr> sections_;
    std::vector<SectionHdr> sectionsOrig_;
    std::vector<OmapEntry> omapFrom_;
    std::vector<OmapEntry> omapTo_;

    // v2
    std::vector<FpoEntry> fpo_;
    mutable std::unique_ptr<class TypeStore> tpiStore_;
    mutable std::unique_ptr<class TypeStore> ipiStore_;
    mutable bool typesLoaded_ = false;
};

// Makine türü adı (DBI başlığındaki IMAGE_FILE_MACHINE_* değeri)
const char *machineName(uint16_t machine);

} // namespace pdbscope
