// ============================================================================
//  PDBScope — main.cpp
//  Komut satırı arayüzü.
//
//  Kullanım özetı için: pdbscope yardim
// ============================================================================
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <memory>
#include <string>
#include <vector>

#include "cvconst.h"
#include "demangle.h"
#include "lines.h"
#include "mapfile.h"
#include "output.h"
#include "pdb.h"
#include "pdbless.h"
#include "pe.h"
#include "types.h"
#include "util.h"

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif

using namespace pdbscope;

static const char *VERSION = "PDBScope 2.0.0";

// ---------------------------------------------------------------------------
// Yardım
// ---------------------------------------------------------------------------
static void printHelp() {
    std::printf(
        "%s — PDB / MAP / PE sembol ve RVA analiz aracı\n"
        "Yerel (CodeView) PDB'leri sıfır bağımlılıkla ayrıştırır; MSVC link\n"
        "/MAP ve GNU ld .map dosyalarını okur; PE export/import/bölümleri\n"
        "listeler. OMAP (artımlı bağlama) desteğiyle doğru RVA hesaplar.\n"
        "PDB olmayan ikililerde pdbless ile IDA/Ghidra tarzı fonksiyon\n"
        "bulma ve çok katmanlı güven doğrulaması yapar.\n"
        "\n"
        "KULLANIM:\n"
        "  pdbscope [komut] [seçenekler] <dosya...>\n"
        "\n"
        "KOMUTLAR:\n"
        "  semboller <hedef>      PDB/MAP/PE'den RVA sembol listesi (varsayılan)\n"
        "                         hedef: .pdb / .exe / .dll / .map\n"
        "  pdbless <pe>           PDB OLMADAN fonksiyon bulma (IDA/Ghidra tarzı)\n"
        "                         RTTI+vftable, çağrı grafı, prolog, sınır,\n"
        "                         .pdata, GFIDS, SafeSEH, COFF, relocation\n"
        "  bilgi <hedef>          PDB üstverisi (GUID, yaş, akışlar, modüller,\n"
        "                         derleyiciler, FPO, satır özeti)\n"
        "  satir <hedef> <adr>    RVA/VA'ya karşılık gelen kaynak dosya:satır\n"
        "  kaynaklar <hedef>      PDB'deki kaynak dosya listesi (satır sayıları)\n"
        "  turler <hedef>         PDB'deki kullanıcı tipleri (class/struct/enum)\n"
        "  bolum <pe>             PE bölüm tablosu\n"
        "  disa <pe>              PE export fonksiyonları (DLL)\n"
        "  ice <pe>               PE import tablosu\n"
        "  dizgiler <pe>          ASCII/UTF-16 dizge taraması (RVA'lı)\n"
        "  vftable <pe>           pdbless: sınıf + vftable dökümü\n"
        "  enyakin <hedef> <adr>  RVA/VA'ya en yakın ya da içeren sembol\n"
        "                         (PDB yoksa pdbless motoruna düşer)\n"
        "  yardim                 Bu yardım\n"
        "\n"
        "SEÇENEKLER (semboller / bilgi / enyakin):\n"
        "  --pdb <yol>        PDB'yi açıkça belirt (PE verilmişse)\n"
        "  --exe <yol>        Bölüm başlıkları + görüntü tabanı için PE kullan\n"
        "  --format <F>       table | csv | json | map   (varsayılan: table)\n"
        "  --tur <T>          func | pub | thunk | data | label | inline | all\n"
        "                     (virgülle çoklu; varsayılan: func,pub,thunk)\n"
        "  --imza             Fonksiyon imzalarını göster (TPI/IPI tipleri)\n"
        "  --satirlar         Kaynak dosya:satır sütunu ekle (C13)\n"
        "  --fpo              FPO çerçeve bilgisini göster (x86)\n"
        "  --filtre <s>       Ada göre alt dizge filtresi (küçük harf duyarsız)\n"
        "  --regex <ifade>    Düzenli ifade filtresi\n"
        "  --sirala <k>       rva | ad | boyut | guven (varsayılan: rva)\n"
        "  --limit <n>        Yalnız ilk n sonuç\n"
        "  --modul <ad>       Modül adı filtresi (örn. msvcrt)\n"
        "  --cozumleme        Ad çözümlemeyi (demangle) kapat\n"
        "  --ham              Tabloda mangled adları da göster\n"
        "  --ayrik            Aynı sembolün PUB/FUNC kopyalarını birleştirme\n"
        "  --cikti <dosya>    Sonucu dosyaya yaz\n"
        "  --json-guzel       Okunabilir JSON çıktısı\n"
        "  --istatistik       Sayıları stderr'e yaz\n"
        "  --versiyon         Sürümü yaz\n"
        "\n"
        "PDBLESS SEÇENEKLERİ:\n"
        "  --min-guven <0-100> Eşik (varsayılan 20; 0 = RED dahil tümü)\n"
        "  --sinif <S>         certain|high|medium|low|reject (virgülle çoklu)\n"
        "  --vftable           vftable dökümünü de yazdır\n"
        "  --no-rtti           RTTI taramasını kapat\n"
        "  --no-cagri          Çağrı hedefi taramasını kapat\n"
        "  --no-prolog         Prolog taramasını kapat\n"
        "  --tum               Eşik altını da (REJECT) göster\n"
        "\n"
        "ÖRNEKLER:\n"
        "  pdbscope semboller uygulama.exe\n"
        "      (uygulama.pdb'yi otomatik bulur, GUID+yaş doğrular)\n"
        "  pdbscope semboller uygulama.pdb --exe uygulama.exe --imza --satirlar\n"
        "  pdbscope pdbless \"C:\\...\\metin2client.exe\"\n"
        "  pdbscope pdbless hedef.exe --min-guven 70 --format csv --cikti f.csv\n"
        "  pdbscope vftable hedef.exe\n"
        "  pdbscope satir uygulama.exe 0x401234\n"
        "  pdbscope kaynaklar uygulama.pdb --filtre Network\n"
        "  pdbscope enyakin hedef.exe 0x140001234\n"
        "  pdbscope dizgiler hedef.exe --min 12 --filtre http\n"
        "\n"
        "ÇIKTI SÜTUNLARI (tablo):\n"
        "  RVA  göreli sanal adres (dosyanın yüklenme biçiminden bağımsız)\n"
        "  VA   tercih edilen görüntü tabanı + RVA (--exe verilmişse)\n"
        "  Tip  FUNC=yordam, PUB=public, PUB*=fonksiyon public'i,\n"
        "       THUNK=geçiş kodu, TRAMP=trampoline, DATA=veri, LABEL=etiket,\n"
        "       INLINE=satır içi genişleme\n"
        "  pdbless tablosu: Guv=yzde güven, Sinif=CERTAIN/HIGH/MEDIUM/LOW,\n"
        "       Kaynaklar=kanıt katmanları (Export/Pdata/RTTI_VF/CallTarget/...)\n",
        VERSION);
}

// ---------------------------------------------------------------------------
// Hedef türü algılama
// ---------------------------------------------------------------------------
enum class TargetKind { Pdb, Pe, MapFile, Unknown };

static TargetKind detectTarget(const std::string &path) {
    std::vector<uint8_t> head = readFile(path);
    if (head.size() >= 32) {
        static const uint8_t MSF[8] = {'M', 'i', 'c', 'r', 'o', 's', 'o', 'f'};
        if (!std::memcmp(head.data(), MSF, 8)) return TargetKind::Pdb;
        if (!std::memcmp(head.data(), "MZ", 2)) return TargetKind::Pe;
        if (!std::memcmp(head.data(), "BSJB", 4)) return TargetKind::Unknown; // portable pdb
    }
    if (!head.empty()) {
        // metin mi?
        bool text = true;
        for (size_t i = 0; i < head.size() && i < 4096; i++)
            if (head[i] == 0) {
                text = false;
                break;
            }
        if (text) return TargetKind::MapFile;
    }
    return TargetKind::Unknown;
}

// ---------------------------------------------------------------------------
// Sembol komutu
// ---------------------------------------------------------------------------
struct CliArgs {
    std::string cmd = "semboller";
    std::vector<std::string> files;
    std::string pdbPath, exePath, format = "table", sortBy = "rva", filter, regex,
                       moduleFilter, outFile;
    std::string types = "func,pub,thunk";
    std::string plClasses;                       // pdbless sınıf filtresi
    int limit = 0;
    int minConf = 20;                            // pdbless eşiği (%)
    int strMin = 6;                              // dizgiler: en az uzunluk
    bool demangle = true;
    bool noMerge = false;
    bool jsonPretty = false;
    bool stats = false;
    bool showMangled = false;
    bool showSig = false;                        // --imza
    bool showLines = false;                      // --satirlar
    bool showFpo = false;                        // --fpo
    bool includeInline = false;                  // inline semboller
    bool plVftables = false;                     // pdbless vftable dökümü
    bool plAll = false;                          // --tum (REJECT dahil)
    bool plNoRtti = false, plNoCalls = false, plNoProlog = false;
    uint64_t forceBase = 0;
    bool haveBase = false;
    bool badUsage = false;
};

static bool hasType(const std::string &types, const char *t) {
    return types.find(t) != std::string::npos || types == "all" ||
           types.find("hepsi") != std::string::npos;
}

static int cmdSymbols(const CliArgs &args) {
    if (args.files.empty()) {
        std::fprintf(stderr, "HATA: hedef dosya belirtilmedi.\n");
        return 2;
    }

    bool first = true;
    int rc = 0;
    for (const std::string &target : args.files) {
        if (!first) std::printf("\n");
        first = false;

        TargetKind kind = detectTarget(target);
        std::string pdbPath, exePath = args.exePath, mapPath;
        if (kind == TargetKind::Unknown) {
            std::vector<uint8_t> head = readFile(target);
            if (!head.empty() && !std::memcmp(head.data(), "BSJB", 4)) {
                std::fprintf(stderr, "HATA: %s bir Portable PDB (.NET). Yerel PDB "
                                     "gerekli; yönetilen semboller desteklenmiyor.\n",
                             target.c_str());
                rc = 1;
                continue;
            }
            std::fprintf(stderr, "HATA: %s tanınan bir biçim değil (PDB/PE/MAP).\n",
                         target.c_str());
            rc = 1;
            continue;
        }

        // Hedef türüne göre kaynak belirleme
        PeFile pe; // kapsamda tut: bölüm adları + görüntü tabanı için
        std::unique_ptr<PdbFile> pdb;
        MapParseResult mapRes;
        bool havePdb = false;
        bool imageBaseKnown = false;
        uint64_t imageBase = 0;

        if (kind == TargetKind::MapFile) {
            mapPath = target;
            kind = TargetKind::MapFile;
        } else if (kind == TargetKind::Pdb) {
            pdbPath = target;
        } else { // PE
            exePath = args.exePath.empty() ? target : args.exePath;
        }

        // PE gerekli mi?
        auto openPe = [&](const std::string &p) -> bool {
            std::string err;
            if (!pe.open(p, &err)) {
                std::fprintf(stderr, "UYARI: PE açılamadı (%s): %s\n", err.c_str(), p.c_str());
                return false;
            }
            imageBase = pe.imageBase();
            imageBaseKnown = true;
            return true;
        };

        if (!exePath.empty()) openPe(exePath);

        // PE hedefli çalışıyorsa PDB'yi bul
        if (kind == TargetKind::Pe) {
            std::string note, err;
            pdbPath = locatePdbFor(target, args.pdbPath, /*verify=*/true, &note, &err);
            if (!note.empty()) std::fprintf(stderr, "%s\n", note.c_str());
            if (pdbPath.empty()) {
                std::fprintf(stderr, "HATA: %s\n", err.c_str());
                if (pe.valid() && pe.isDll())
                    std::fprintf(stderr,
                                 "İpucu: hedef bir DLL — export tablosunu görmek için: "
                                 "pdbscope disa %s\n",
                                 target.c_str());
                rc = 1;
                continue;
            }
        } else if (!args.pdbPath.empty()) {
            pdbPath = args.pdbPath;
        }

        // PDB varsa aç
        if (!pdbPath.empty()) {
            std::string err;
            pdb.reset(new PdbFile());
            if (!pdb->open(pdbPath, &err)) {
                std::fprintf(stderr, "HATA: PDB açılamadı: %s (%s)\n", pdbPath.c_str(),
                             err.c_str());
                rc = 1;
                continue;
            }
            havePdb = true;
            // PDB'den gelen güncel bölümler (PE yoksa bölüm adları için)
            if (!imageBaseKnown && pdb->sections().empty() == false) {
                // görüntü tabanı PDB'den bilinmez
            }
        }

        // Sembolleri topla
        std::vector<Symbol> symbols;
        std::vector<std::string> moduleNames;
        std::string sourceLabel;

        if (havePdb) {
            CollectOpts copts;
            copts.includeData = true; // tür filtresi görüntülemede uygulanır
            copts.includeLabels = true;
            copts.includeThunks = true;
            copts.includeInline = args.includeInline || hasType(args.types, "inline");
            copts.merge = !args.noMerge;
            CollectStats st;
            std::string err;
            pdb->collectSymbols(copts, symbols, &st, &err);
            if (args.stats) {
                std::fprintf(stderr,
                             "[istatistik] akış kaydı: %u, modül kaydı: %u, "
                             "birleştirilen: %u, bozuk: %u, bölümsüz: %u\n",
                             st.globalRecords, st.moduleRecords, st.mergedAway,
                             st.skippedBad, st.noSection);
            }
            // inline sembollere IPI adlarını ver
            if (copts.includeInline) {
                for (Symbol &s : symbols) {
                    if (s.kind != SymKind::Inline || !s.inlineeId) continue;
                    std::string nm = pdb->idNameOf(s.inlineeId);
                    if (!nm.empty()) s.name = nm + " (inline)";
                }
            }
            for (const ModuleInfo &m : pdb->modules()) moduleNames.push_back(m.moduleName);
            sourceLabel = pdbPath;
        } else if (mapPath.empty() && kind == TargetKind::MapFile) {
            // (buraya düşülmez)
        }

        if (kind == TargetKind::MapFile) {
            std::string err;
            if (!parseMapFile(mapPath, pe.valid() ? &pe : nullptr, mapRes, &err)) {
                std::fprintf(stderr, "HATA: MAP ayrıştırılamadı: %s (%s)\n", mapPath.c_str(),
                             err.c_str());
                rc = 1;
                continue;
            }
            symbols = mapRes.symbols;
            if (args.stats)
                std::fprintf(stderr, "[istatistik] map biçimi: %s, sembol: %zu\n",
                             mapRes.format == MapFormat::Msvc ? "MSVC" : "GNU",
                             symbols.size());
            if (mapRes.imageBaseKnown && !imageBaseKnown) {
                imageBase = mapRes.imageBase;
                imageBaseKnown = true;
            }
            sourceLabel = mapPath;
        }

        if (symbols.empty() && havePdb) {
            std::fprintf(stderr, "UYARI: PDB'de sembol bulunamadı (stripped olabilir).\n");
        }

        // Tür filtresi
        std::vector<Symbol> typed;
        bool all = hasType(args.types, "all");
        for (const Symbol &s : symbols) {
            bool ok = all;
            if (!ok) {
                switch (s.kind) {
                case SymKind::Function: ok = hasType(args.types, "func"); break;
                case SymKind::Public:
                    ok = hasType(args.types, "pub") ||
                         (s.isFunction && hasType(args.types, "func"));
                    break;
                case SymKind::Thunk:
                case SymKind::Trampoline: ok = hasType(args.types, "thunk"); break;
                case SymKind::Data: ok = hasType(args.types, "data"); break;
                case SymKind::Label: ok = hasType(args.types, "label"); break;
                case SymKind::Inline: ok = hasType(args.types, "inline"); break;
                }
            }
            if (ok) typed.push_back(s);
        }

        // Görüntüleme seçenekleri
        OutOpts oo;
        oo.format = args.format;
        oo.sortBy = args.sortBy;
        oo.filter = args.filter;
        oo.regex = args.regex;
        oo.moduleFilter = args.moduleFilter;
        oo.imageBase = imageBase;
        oo.imageBaseKnown = imageBaseKnown;
        oo.limit = args.limit;
        oo.demangle = args.demangle;
        oo.jsonPretty = args.jsonPretty;
        oo.showMangled = args.showMangled;
        // v2: imza + satır sütunları (yalnız PDB hedeflerinde)
        LineInfo lineInfo;
        if (havePdb && (args.showSig || args.showLines)) {
            if (args.showLines) lineInfo.collect(*pdb, true, nullptr);
            const PdbFile *pdbPtr = pdb.get();
            if (args.showSig) {
                oo.signatureOf = [pdbPtr](const Symbol &s) -> std::string {
                    if (!s.typeIndex) return std::string();
                    const TypeStore &ts = s.typeIdIsId ? pdbPtr->ipiStore()
                                                       : pdbPtr->tpiStore();
                    FuncSignature fs = ts.signatureOfType(s.typeIndex);
                    return fs.valid ? fs.signatureStr("") : std::string();
                };
            }
            if (args.showLines) {
                oo.lineOf = [&lineInfo](const Symbol &s) -> std::string {
                    if (!s.hasRva()) return std::string();
                    const LineEntry *le = lineInfo.lineForRva(s.rva);
                    if (!le || !le->fileIdx || le->fileIdx > lineInfo.files().size())
                        return std::string();
                    return lineInfo.files()[le->fileIdx - 1].name + ":" +
                           std::to_string(le->line);
                };
            }
        }
        std::vector<SectionHdr> currentSections;
        if (pe.valid())
            currentSections = pe.sections();
        else if (havePdb)
            currentSections = pdb->sections();
        else if (!mapRes.sections.empty())
            currentSections = mapRes.sections;
        if (!currentSections.empty()) oo.sections = &currentSections;

        std::vector<Symbol> prepared = prepareSymbols(typed, oo);
        size_t shown = 0;
        std::string text = renderSymbols(prepared, sourceLabel, moduleNames, oo, &shown);

        if (!args.outFile.empty()) {
            std::string err;
            bool bom = args.format == "csv";
            if (!writeFileText(args.outFile, text, bom, &err)) {
                std::fprintf(stderr, "HATA: %s\n", err.c_str());
                rc = 1;
                continue;
            }
            std::fprintf(stderr, "%zu sembol yazıldı: %s\n", shown, args.outFile.c_str());
        } else {
            std::fputs(text.c_str(), stdout);
        }
    }
    return rc;
}

// ---------------------------------------------------------------------------
// pdbless komutu: PDB olmadan fonksiyon bulma
// ---------------------------------------------------------------------------
static int cmdPdbless(const CliArgs &args, bool vftablesOnly = false) {
    if (args.files.empty()) {
        std::fprintf(stderr, "HATA: hedef PE belirtilmedi.\n");
        return 2;
    }
    int rc = 0;
    for (const std::string &target : args.files) {
        PeFile pe;
        std::string err;
        if (!pe.open(target, &err)) {
            std::fprintf(stderr, "HATA: %s (%s)\n", err.c_str(), target.c_str());
            rc = 1;
            continue;
        }
        if (pe.cvDebug().found)
            std::fprintf(stderr,
                         "NOT: %s bir PDB kaydı taşıyor (%s). Semboller için: "
                         "pdbscope semboller %s\n",
                         target.c_str(), pe.cvDebug().pdbPath.c_str(), target.c_str());

        PdblessOpts po;
        po.scanRtti = !args.plNoRtti;
        po.scanCalls = !args.plNoCalls;
        po.scanPrologues = !args.plNoProlog;
        po.minConfidence = args.plAll ? 0.0f : args.minConf / 100.0f;
        PdblessAnalyzer a;
        if (!a.analyze(pe, po, &err)) {
            std::fprintf(stderr, "HATA: %s\n", err.c_str());
            rc = 1;
            continue;
        }
        const PlStats &st = a.stats();

        // sınıf filtresi
        auto classOk = [&](PlFunction::Class c) {
            if (args.plClasses.empty()) return c != PlFunction::REJECT || args.plAll;
            const char *n = c == PlFunction::CERTAIN   ? "certain"
                            : c == PlFunction::HIGH    ? "high"
                            : c == PlFunction::MEDIUM  ? "medium"
                            : c == PlFunction::LOW     ? "low"
                                                       : "reject";
            return containsCI(args.plClasses, n);
        };

        // filtre (ad)
        std::string flt = toLower(args.filter);

        if (vftablesOnly) {
            // vftable dökümü
            std::vector<PlVtable> vts = a.vtables();
            std::sort(vts.begin(), vts.end(),
                      [](const PlVtable &x, const PlVtable &y) { return x.rva < y.rva; });
            if (args.format == "json") {
                std::string text = "{\"source\":\"" + jsonEscape(target) +
                                   "\",\"vftables\":[";
                bool first = true;
                for (const PlVtable &vt : vts) {
                    if (!flt.empty() && !containsCI(vt.className, flt)) continue;
                    if (!first) text += ",";
                    first = false;
                    text += "{\"rva\":" + std::to_string(vt.rva) +
                            ",\"col_rva\":" + std::to_string(vt.colRva) +
                            ",\"class\":\"" + jsonEscape(vt.className) +
                            "\",\"functions\":[";
                    for (size_t i = 0; i < vt.funcRvas.size(); i++) {
                        if (i) text += ",";
                        text += std::to_string(vt.funcRvas[i]);
                    }
                    text += "]}";
                }
                text += "]}\n";
                std::fputs(text.c_str(), stdout);
            } else {
                std::printf("%s — %zu vftable (%u sınıf)\n", target.c_str(), vts.size(),
                            st.rttiClasses);
                std::printf("%-10s %-36s %s\n", "RVA", "Sınıf", "Sanal fonksiyonlar (RVA)");
                for (const PlVtable &vt : vts) {
                    if (!flt.empty() && !containsCI(vt.className, flt)) continue;
                    std::printf("0x%-8x %-36s", vt.rva, vt.className.c_str());
                    for (size_t i = 0; i < vt.funcRvas.size(); i++) {
                        std::printf("%s0x%x", i ? " " : "", vt.funcRvas[i]);
                    }
                    std::printf("\n");
                }
            }
            continue;
        }

        // istatistik başlığı
        std::fprintf(stderr,
                     "[%s] aday=%u kabul=%u | CERTAIN=%u HIGH=%u MEDIUM=%u LOW=%u "
                     "redd=%u\n"
                     "  pdata=%u export=%u gfids=%u safeseh=%u tls=%u coff=%u reloc=%u "
                     "rtti(sınıf=%u vf=%u) import=%u\n"
                     "  .text=%u bayt kapsam=%u (%.1f%%)\n",
                     target.c_str(), st.candidates, st.accepted, st.certain, st.high,
                     st.medium, st.low, st.rejected, st.pdataFuncs, st.exportFuncs,
                     st.gfidsFuncs, st.sehFuncs, st.tlsFuncs, st.coffFuncs,
                     st.relocPtrFuncs, st.rttiClasses, st.rttiVfuncs, st.importThunks,
                     st.textSize, st.covered,
                     st.textSize ? 100.0 * st.covered / st.textSize : 0.0);

        if (args.format == "json") {
            std::string text = "{\"source\":\"" + jsonEscape(target) +
                               "\",\"image_base\":" + std::to_string(pe.imageBase()) +
                               ",\"functions\":[";
            bool first = true;
            int shown = 0;
            for (const PlFunction &f : a.functions()) {
                if (!classOk(f.cls)) continue;
                if (!flt.empty() && !containsCI(f.name, flt)) continue;
                if (args.limit && ++shown > args.limit) break;
                if (!first) text += ",";
                first = false;
                text += "{\"rva\":" + std::to_string(f.rva) + ",\"va\":" +
                        std::to_string(pe.imageBase() + f.rva) + ",\"size\":" +
                        std::to_string(f.size) + ",\"confidence\":" +
                        std::to_string(f.confidence).substr(0, 4) + ",\"class\":\"" +
                        f.classStr() + "\",\"kind\":\"" + jsonEscape(f.kind) +
                        "\",\"name\":\"" + jsonEscape(f.name) + "\",\"callers\":" +
                        std::to_string(f.callerCount) + ",\"sources\":\"";
                std::string srcs;
                for (const auto &s : f.sources) {
                    if (!srcs.empty()) srcs += ",";
                    srcs += s;
                }
                text += jsonEscape(srcs) + "\"}";
            }
            text += "]}\n";
            std::fputs(text.c_str(), stdout);
        } else if (args.format == "csv") {
            std::printf("rva,va,size,confidence,percent,class,kind,callers,sources,name\n");
            int shown = 0;
            for (const PlFunction &f : a.functions()) {
                if (!classOk(f.cls)) continue;
                if (!flt.empty() && !containsCI(f.name, flt)) continue;
                if (args.limit && ++shown > args.limit) break;
                std::string srcs;
                for (const auto &s : f.sources) {
                    if (!srcs.empty()) srcs += ",";
                    srcs += s;
                }
                std::printf("%u,%llu,%u,%s,%d,%s,%s,%d,%s,%s\n", f.rva,
                            (unsigned long long)(pe.imageBase() + f.rva), f.size,
                            std::to_string(f.confidence).substr(0, 4).c_str(),
                            (int)(f.confidence * 100), f.classStr(), f.kind.c_str(),
                            f.callerCount, csvEscape(srcs).c_str(),
                            csvEscape(f.name).c_str());
            }
        } else {
            // tablo
            std::printf("%s — PDB'siz analiz (%s, taban 0x%llx)\n", target.c_str(),
                        pe.is64() ? "x64" : "x86", (unsigned long long)pe.imageBase());
            std::printf("%-10s %-10s %-6s %-8s %-10s %-6s %s\n", "RVA", "Boyut", "Guv",
                        "Sınıf", "Tür", "Cağrn", "Ad [kanıt]");
            int shown = 0;
            for (const PlFunction &f : a.functions()) {
                if (!classOk(f.cls)) continue;
                if (!flt.empty() && !containsCI(f.name, flt)) continue;
                if (args.regex.size() && !containsCI(f.name, "")) {
                    // regex desteği pdbless'ta filtre üzerinden verilir
                }
                if (args.limit && ++shown > args.limit) break;
                std::string srcs;
                for (const auto &s : f.sources) {
                    if (!srcs.empty()) srcs += ",";
                    srcs += s;
                }
                std::string dm = args.demangle ? demangle(f.name) : std::string();
                std::string disp = dm.empty() || dm == f.name ? f.name : dm;
                std::printf("0x%-8x %-10s %-3d%%  %-8s %-10s %-6d %s [%s]\n", f.rva,
                            f.size ? ("0x" + hexU32(f.size, 1)).c_str() : "-",
                            (int)(f.confidence * 100), f.classStr(), f.kind.c_str(),
                            f.callerCount, disp.c_str(), srcs.c_str());
            }
        }

        // vftable dökümü istenmişse ekle
        if (args.plVftables && !a.vtables().empty()) {
            std::printf("\nvftable (%zu):\n", a.vtables().size());
            for (const PlVtable &vt : a.vtables()) {
                if (!flt.empty() && !containsCI(vt.className, flt)) continue;
                std::printf("  0x%-8x %-36s %zu vf | ", vt.rva, vt.className.c_str(),
                            vt.funcRvas.size());
                for (size_t i = 0; i < vt.funcRvas.size() && i < 8; i++)
                    std::printf("0x%x ", vt.funcRvas[i]);
                std::printf("\n");
            }
        }
    }
    return rc;
}

// ---------------------------------------------------------------------------
// satir komutu: RVA/VA -> kaynak dosya:satır
// ---------------------------------------------------------------------------
static int cmdLine(const CliArgs &args) {
    if (args.files.size() < 2) {
        std::fprintf(stderr, "HATA: kullanım: pdbscope satir <hedef> <adres>\n");
        return 2;
    }
    std::string target = args.files[0];
    auto addr = parseNumber(args.files[1]);
    if (!addr) {
        std::fprintf(stderr, "HATA: adres çözümlenemedi: %s\n", args.files[1].c_str());
        return 2;
    }

    // PDB'yi bul (PE ya da doğrudan .pdb)
    std::string pdbPath;
    PeFile pe;
    bool havePe = false;
    TargetKind kind = detectTarget(target);
    if (kind == TargetKind::Pe) {
        std::string note, err;
        if (pe.open(target, &err)) havePe = true;
        pdbPath = locatePdbFor(target, args.pdbPath, true, &note, &err);
        if (!note.empty()) std::fprintf(stderr, "%s\n", note.c_str());
    } else if (kind == TargetKind::Pdb) {
        pdbPath = target;
        if (!args.exePath.empty() && pe.open(args.exePath, nullptr)) havePe = true;
    } else {
        std::fprintf(stderr, "HATA: hedef bir PE ya da PDB olmalı.\n");
        return 1;
    }
    if (pdbPath.empty()) {
        std::fprintf(stderr, "HATA: PDB bulunamadı; satır bilgisi PDB gerektirir.\n");
        return 1;
    }
    PdbFile pdb;
    std::string err;
    if (!pdb.open(pdbPath, &err)) {
        std::fprintf(stderr, "HATA: %s\n", err.c_str());
        return 1;
    }

    // VA -> RVA
    uint64_t a = *addr;
    if (havePe && a >= pe.imageBase() && a < pe.imageBase() + pe.sizeOfImage())
        a -= pe.imageBase();
    if (a > 0xFFFFFFFFull) {
        std::fprintf(stderr, "HATA: adres 32-bit RVA aralığında değil.\n");
        return 2;
    }
    uint32_t rva = (uint32_t)a;

    LineInfo li;
    li.collect(pdb, true, nullptr);
    const LineEntry *le = li.lineForRva(rva);
    if (!le || !le->fileIdx || le->fileIdx > li.files().size()) {
        std::fprintf(stderr, "HATA: 0x%x için satır bilgisi yok.\n", rva);
        // en yakın sembol bilgisi yine de ver
    } else {
        const SourceFile &f = li.files()[le->fileIdx - 1];
        std::printf("Kaynak : %s\n", f.name.c_str());
        std::printf("Satır  : %u%s\n", le->line,
                    le->column ? (" (sütun " + std::to_string(le->column) + ")").c_str()
                               : "");
    }
    // sembol de çözümle
    CollectOpts co;
    std::vector<Symbol> syms;
    pdb.collectSymbols(co, syms, nullptr, nullptr);
    std::vector<Symbol> sorted = prepareSymbols(syms, OutOpts{});
    NearestResult nr = findNearest(sorted, rva);
    if (nr.found) {
        const Symbol &s = sorted[nr.index];
        std::string dm = demangle(s.name);
        std::printf("Sembol : 0x%08x %s\n", s.rva,
                    dm.empty() ? s.name.c_str() : dm.c_str());
        std::printf("Konum  : %s\n",
                    nr.exact ? "adres sembol içinde" : "en yakın sembol");
    }
    return le ? 0 : 1;
}

// ---------------------------------------------------------------------------
// kaynaklar / turler komutları
// ---------------------------------------------------------------------------
static int cmdSources(const CliArgs &args) {
    if (args.files.empty()) {
        std::fprintf(stderr, "HATA: hedef belirtilmedi.\n");
        return 2;
    }
    for (const std::string &target : args.files) {
        TargetKind kind = detectTarget(target);
        std::string pdbPath, note, err;
        if (kind == TargetKind::Pe)
            pdbPath = locatePdbFor(target, args.pdbPath, true, &note, &err);
        else if (kind == TargetKind::Pdb)
            pdbPath = target;
        else {
            std::fprintf(stderr, "HATA: %s PE ya da PDB değil.\n", target.c_str());
            return 1;
        }
        if (!note.empty()) std::fprintf(stderr, "%s\n", note.c_str());
        if (pdbPath.empty()) {
            std::fprintf(stderr, "HATA: PDB bulunamadı: %s\n", err.c_str());
            return 1;
        }
        PdbFile pdb;
        if (!pdb.open(pdbPath, &err)) {
            std::fprintf(stderr, "HATA: %s\n", err.c_str());
            return 1;
        }
        LineInfo li;
        li.collect(pdb, false, nullptr);
        std::printf("%s — %zu kaynak dosya, %u satır kaydı\n", pdbPath.c_str(),
                    li.files().size(), li.totalEntries());
        if (args.format == "csv") std::printf("module,file,lines,first_rva,last_rva\n");
        else std::printf("%-8s %-52s %-8s %-10s %-10s\n", "Modül", "Dosya", "Satır",
                         "İlkRVA", "SonRVA");
        int shown = 0;
        for (const SourceFile &f : li.files()) {
            if (f.lineCount == 0) continue;
            if (!args.filter.empty() && !containsCI(f.name, args.filter)) continue;
            if (args.limit && ++shown > args.limit) break;
            if (args.format == "csv")
                std::printf("%d,%s,%u,%u,%u\n", f.module, csvEscape(f.name).c_str(),
                            f.lineCount, f.firstRva, f.lastRva);
            else
                std::printf("%-8d %-52.52s %-8u 0x%-8x 0x%-8x\n", f.module, f.name.c_str(),
                            f.lineCount, f.firstRva, f.lastRva);
        }
    }
    return 0;
}

static int cmdTypes(const CliArgs &args) {
    if (args.files.empty()) {
        std::fprintf(stderr, "HATA: hedef belirtilmedi.\n");
        return 2;
    }
    for (const std::string &target : args.files) {
        TargetKind kind = detectTarget(target);
        std::string pdbPath, note, err;
        if (kind == TargetKind::Pe)
            pdbPath = locatePdbFor(target, args.pdbPath, true, &note, &err);
        else if (kind == TargetKind::Pdb)
            pdbPath = target;
        else {
            std::fprintf(stderr, "HATA: %s PE ya da PDB değil.\n", target.c_str());
            return 1;
        }
        if (!note.empty()) std::fprintf(stderr, "%s\n", note.c_str());
        if (pdbPath.empty()) {
            std::fprintf(stderr, "HATA: PDB bulunamadı: %s\n", err.c_str());
            return 1;
        }
        PdbFile pdb;
        if (!pdb.open(pdbPath, &err)) {
            std::fprintf(stderr, "HATA: %s\n", err.c_str());
            return 1;
        }
        const TypeStore &tpi = pdb.tpiStore();
        std::vector<UdtEntry> udts;
        tpi.collectUdts(udts);
        // tam tanımlı olanları öne al, ada göre sırala
        std::sort(udts.begin(), udts.end(), [](const UdtEntry &a, const UdtEntry &b) {
            if (a.fwdRef != b.fwdRef) return !a.fwdRef;
            return a.name < b.name;
        });
        std::printf("%s — %zu kullanıcı tipi\n", pdbPath.c_str(), udts.size());
        if (args.format == "csv") std::printf("kind,name,size,fwdref,type_index\n");
        else std::printf("%-10s %-52s %-10s %s\n", "Tür", "Ad", "Boyut", "İndeks");
        int shown = 0;
        for (const UdtEntry &u : udts) {
            if (!args.filter.empty() && !containsCI(u.name, args.filter)) continue;
            if (args.limit && ++shown > args.limit) break;
            if (args.format == "csv")
                std::printf("%s,%s,%llu,%d,%u\n", u.kind.c_str(), csvEscape(u.name).c_str(),
                            (unsigned long long)u.size, u.fwdRef ? 1 : 0, u.typeIndex);
            else
                std::printf("%-10s %-52.52s %-10s 0x%x%s\n", u.kind.c_str(), u.name.c_str(),
                            ("0x" + hexU32((uint32_t)u.size, 1)).c_str(), u.typeIndex,
                            u.fwdRef ? " (ileri bildirim)" : "");
        }
    }
    return 0;
}

// ---------------------------------------------------------------------------
// dizgiler komutu: ASCII + UTF-16 taraması
// ---------------------------------------------------------------------------
static int cmdStrings(const CliArgs &args) {
    if (args.files.empty()) {
        std::fprintf(stderr, "HATA: hedef PE belirtilmedi.\n");
        return 2;
    }
    for (const std::string &target : args.files) {
        PeFile pe;
        std::string err;
        if (!pe.open(target, &err)) {
            std::fprintf(stderr, "HATA: %s (%s)\n", err.c_str(), target.c_str());
            return 1;
        }
        const std::vector<uint8_t> &d = pe.raw();
        std::string flt = toLower(args.filter);
        auto printStr = [&](uint32_t rva, const char *kind, const std::string &s) {
            if (!flt.empty() && !containsCI(s, flt)) return;
            std::printf("0x%-8x %-5s %s\n", rva, kind, s.c_str());
        };
        // bölümler üzerinde tara (bölüm dışı başlıkları atla)
        for (const SectionHdr &sec : pe.sections()) {
            uint32_t off = 0;
            if (!pe.rvaToOffset(sec.virtualAddress, off)) continue;
            uint32_t span = std::min(sec.virtualSize ? sec.virtualSize : sec.sizeOfRawData,
                                     sec.sizeOfRawData);
            // ASCII
            std::string cur;
            uint32_t curStart = 0;
            for (uint32_t i = 0; i < span; i++) {
                uint8_t c = d[off + i];
                if (c >= 0x20 && c < 0x7F) {
                    if (cur.empty()) curStart = i;
                    cur += (char)c;
                } else {
                    if ((int)cur.size() >= args.strMin)
                        printStr(sec.virtualAddress + curStart, "ascii", cur);
                    cur.clear();
                }
            }
            // UTF-16LE
            cur.clear();
            curStart = 0;
            for (uint32_t i = 0; i + 1 < span; i += 2) {
                uint16_t w = (uint16_t)(d[off + i] | (d[off + i + 1] << 8));
                if (w >= 0x20 && w < 0x7F) {
                    if (cur.empty()) curStart = i;
                    cur += (char)w;
                } else {
                    if ((int)cur.size() >= args.strMin)
                        printStr(sec.virtualAddress + curStart, "utf16", cur);
                    cur.clear();
                }
            }
        }
    }
    return 0;
}

// ---------------------------------------------------------------------------
// bilgi komutu
// ---------------------------------------------------------------------------
static int cmdInfo(const CliArgs &args) {
    if (args.files.empty()) {
        std::fprintf(stderr, "HATA: hedef dosya belirtilmedi.\n");
        return 2;
    }
    for (const std::string &target : args.files) {
        TargetKind kind = detectTarget(target);
        std::string pdbPath;
        if (kind == TargetKind::Pe) {
            std::string note, err;
            pdbPath = locatePdbFor(target, args.pdbPath, true, &note, &err);
            if (!note.empty()) std::fprintf(stderr, "%s\n", note.c_str());
            if (pdbPath.empty()) {
                std::fprintf(stderr, "HATA: %s\n", err.c_str());
                return 1;
            }
        } else if (kind == TargetKind::Pdb) {
            pdbPath = target;
        } else {
            std::fprintf(stderr, "HATA: bilgi komutu bir PDB ya da PE ister.\n");
            return 2;
        }

        PdbFile pdb;
        std::string err;
        if (!pdb.open(pdbPath, &err)) {
            std::fprintf(stderr, "HATA: PDB açılamadı: %s (%s)\n", pdbPath.c_str(), err.c_str());
            return 1;
        }

        const MsfFile &msf = pdb.msf();
        std::printf("PDB üstverisi: %s\n", pdbPath.c_str());
        std::printf("  Dosya boyutu      : %llu bayt\n", (unsigned long long)msf.fileSize());
        std::printf("  Blok boyutu       : %u bayt, blok sayısı: %u\n", msf.blockSize(),
                    msf.blockCount());
        std::printf("  Akış sayısı       : %u\n", msf.streamCount());
        std::printf("  GUID              : %s\n", guidToString(pdb.guid()).c_str());
        std::printf("  Yaş (age)         : %u\n", pdb.age());
        std::printf("  Sürüm             : %u (%s)\n", pdb.infoVersion(),
                    pdb.infoVersion() >= cv::PdbImplVC140 ? "VC140+ (VS2015+)"
                    : pdb.infoVersion() >= cv::PdbImplVC110 ? "VC110 (VS2012)"
                    : pdb.infoVersion() >= cv::PdbImplVC80  ? "VC80 (VS2005)"
                                                            : "VC70 (VS2003)");
        std::printf("  Makine            : %s\n", machineName(pdb.dbi().machine));
        std::printf("  Artımlı bağlama   : %s\n",
                    (pdb.dbi().flags & 0x1) ? "evet" : "hayır");
        std::printf("  OMAP              : %s\n",
                    pdb.hasOmap() ? "var (RVA'lar yeniden eşlenir)" : "yok");
        std::printf("  TPI tipleri       : %u\n", pdb.tpi().typeCount());
        std::printf("  IPI tipleri       : %u\n", pdb.ipi().typeCount());
        std::printf("  Bölüm başlıkları  : %zu güncel, %zu orijinal\n",
                    pdb.sections().size(), pdb.sectionsOrig().size());

        std::printf("\nAdlandırılmış akışlar:\n");
        for (const auto &kv : pdb.namedStreams())
            std::printf("  %-24s -> akış %u (%u bayt)\n", kv.first.c_str(), kv.second,
                        msf.streamSize(kv.second));

        // sembolleri say
        CollectOpts co;
        co.merge = true;
        CollectStats st;
        std::vector<Symbol> syms;
        pdb.collectSymbols(co, syms, &st, nullptr);
        std::printf("\nSembol istatistikleri:\n");
        std::printf("  Public/global kayıt: %u\n", st.globalRecords);
        std::printf("  Modül kaydı        : %u\n", st.moduleRecords);
        std::printf("  Birleştirilen      : %u\n", st.mergedAway);
        std::printf("  Bozuk kayıt        : %u\n", st.skippedBad);
        std::printf("  Sonuç sembol       : %zu\n", syms.size());

        // v2: derleyiciler
        std::vector<CompilerInfo> comps;
        pdb.collectCompilers(comps);
        if (!comps.empty()) {
            std::printf("\nDerleyici/araç zinciri (%zu benzersiz):\n", comps.size());
            for (const CompilerInfo &c : comps) {
                if (c.versionStr.size() < 3) continue;
                std::printf("  %-42s FE %u.%u.%u", c.versionStr.c_str(), c.feMajor,
                            c.feMinor, c.feBuild);
                if (c.beMajor)
                    std::printf(" | BE %u.%u.%u", c.beMajor, c.beMinor, c.beBuild);
                std::printf(" %s%s%s%s\n", c.gs ? "/GS" : "", c.hotpatch ? "/hotpatch" : "",
                            c.ltcg ? "/LTCG" : "", c.pgo ? "/PGO" : "");
            }
        }

        // v2: FPO özeti
        if (pdb.hasFpo()) {
            std::printf("\nFPO çerçeve verisi: %zu kayıt\n", pdb.fpoEntries().size());
            size_t fpoFrames = 0, ebpFrames = 0;
            for (const FpoEntry &e : pdb.fpoEntries()) {
                if (e.frameType == cv::CV_FRAME_FPO) fpoFrames++;
                else ebpFrames++;
            }
            std::printf("  FPO çerçevesi: %zu, ebp çerçevesi: %zu\n", fpoFrames, ebpFrames);
        }

        // v2: satır bilgisi özeti
        {
            LineInfo li;
            li.collect(pdb, false, nullptr);
            size_t withLines = 0;
            for (const SourceFile &f : li.files())
                if (f.lineCount) withLines++;
            std::printf("\nSatır bilgisi (C13): %u kayıt, %zu dosya (%zu satırlı)\n",
                        li.totalEntries(), li.files().size(), withLines);
        }

        std::printf("\nModüller (%zu):\n", pdb.modules().size());
        std::printf("  %-4s %-32s %-6s %-10s %s\n", "#", "Modül", "Akış", "Sembol",
                    "Bölüm katkısı");
        for (const ModuleInfo &m : pdb.modules()) {
            std::string contrib =
                m.scSize ? (std::to_string(m.scSect) + ":" + hexU32(m.scOff, 6) + " +" +
                            std::to_string(m.scSize))
                         : "-";
            std::printf("  %-4d %-32.32s %-6u %-10u %s\n", m.index, m.moduleName.c_str(),
                        (unsigned)m.stream, m.symbolCount, contrib.c_str());
        }
    }
    return 0;
}

// ---------------------------------------------------------------------------
// PE komutları
// ---------------------------------------------------------------------------
static int cmdSections(const CliArgs &args) {
    for (const std::string &f : args.files) {
        PeFile pe;
        std::string err;
        if (!pe.open(f, &err)) {
            std::fprintf(stderr, "HATA: %s (%s)\n", err.c_str(), f.c_str());
            return 1;
        }
        std::printf("%s — %s, makine: %s, taban: 0x%llx, boyut: 0x%x\n", f.c_str(),
                    pe.isDll() ? "DLL" : "EXE", machineName(pe.machine()),
                    (unsigned long long)pe.imageBase(), pe.sizeOfImage());
        std::printf("%-4s %-10s %-12s %-12s %-12s %s\n", "#", "Ad", "VA", "VSize",
                    "HamBoyut", "Özellikler");
        for (size_t i = 0; i < pe.sections().size(); i++) {
            const SectionHdr &s = pe.sections()[i];
            std::printf("%-4zu %-10s 0x%08x   0x%08x   0x%08x   0x%08x\n", i + 1, s.name,
                        s.virtualAddress, s.virtualSize, s.sizeOfRawData,
                        s.characteristics);
        }
        if (pe.cvDebug().found)
            std::printf("PDB: %s (yaş %u, GUID %s)\n", pe.cvDebug().pdbPath.c_str(),
                        pe.cvDebug().age, guidToString(pe.cvDebug().guid).c_str());
    }
    return 0;
}

static int cmdExports(const CliArgs &args) {
    for (const std::string &f : args.files) {
        PeFile pe;
        std::string err;
        if (!pe.open(f, &err)) {
            std::fprintf(stderr, "HATA: %s (%s)\n", err.c_str(), f.c_str());
            return 1;
        }
        std::vector<ExportEntry> exports;
        if (!pe.readExports(exports, &err)) {
            std::fprintf(stderr, "HATA: %s\n", err.c_str());
            return 1;
        }
        std::string text;
        if (args.format == "json") {
            text += "{\"source\":\"" + jsonEscape(f) + "\",\"image_base\":" +
                    std::to_string(pe.imageBase()) + ",\"exports\":[";
            bool first = true;
            for (const ExportEntry &e : exports) {
                if (!first) text += ",";
                first = false;
                text += "{\"ordinal\":" + std::to_string(e.ordinal) + ",\"rva\":" +
                        std::to_string(e.rva) + ",\"name\":\"" + jsonEscape(e.name) +
                        "\",\"forwarder\":\"" + jsonEscape(e.forwarder) + "\"}";
            }
            text += "]}\n";
        } else if (args.format == "csv") {
            text += "ordinal,rva,va,name,forwarder,section\n";
            for (const ExportEntry &e : exports)
                text += std::to_string(e.ordinal) + "," + std::to_string(e.rva) + "," +
                        std::to_string(pe.imageBase() + e.rva) + "," + csvEscape(e.name) +
                        "," + csvEscape(e.forwarder) + "," + pe.sectionOfRva(e.rva) + "\n";
        } else {
            std::printf("%s — %zu export (taban 0x%llx)\n", f.c_str(), exports.size(),
                        (unsigned long long)pe.imageBase());
            std::printf("%-8s %-12s %-12s %-8s %s\n", "Ordinal", "RVA", "VA", "Bölüm",
                        "Ad");
            for (const ExportEntry &e : exports) {
                std::string name = e.name.empty() ? std::string("(ordinal #") +
                                                        std::to_string(e.ordinal) + ")"
                                                  : e.name;
                std::string disp = args.demangle ? demangle(name) : std::string();
                if (disp.empty()) disp = name;
                std::printf("%-8u 0x%08x   0x%012llx %-8s %s%s%s\n", e.ordinal, e.rva,
                            (unsigned long long)(pe.imageBase() + e.rva),
                            pe.sectionOfRva(e.rva).c_str(), disp.c_str(),
                            e.forwarder.empty() ? "" : " -> ",
                            e.forwarder.c_str());
            }
            continue;
        }
        std::fputs(text.c_str(), stdout);
    }
    return 0;
}

static int cmdImports(const CliArgs &args) {
    for (const std::string &f : args.files) {
        PeFile pe;
        std::string err;
        if (!pe.open(f, &err)) {
            std::fprintf(stderr, "HATA: %s (%s)\n", err.c_str(), f.c_str());
            return 1;
        }
        std::vector<ImportEntry> imports;
        if (!pe.readImports(imports, &err)) {
            std::fprintf(stderr, "HATA: %s\n", err.c_str());
            return 1;
        }
        std::string text;
        if (args.format == "json") {
            text += "{\"source\":\"" + jsonEscape(f) + "\",\"imports\":[";
            bool first = true;
            for (const ImportEntry &e : imports) {
                if (!first) text += ",";
                first = false;
                text += "{\"dll\":\"" + jsonEscape(e.dll) + "\",\"name\":\"" +
                        jsonEscape(e.name) + "\",\"ordinal\":" + std::to_string(e.ordinal) +
                        ",\"iat_rva\":" + std::to_string(e.iatRva) + "}";
            }
            text += "]}\n";
        } else if (args.format == "csv") {
            text += "dll,name,ordinal,iat_rva\n";
            for (const ImportEntry &e : imports)
                text += csvEscape(e.dll) + "," + csvEscape(e.name) + "," +
                        std::to_string(e.ordinal) + "," + std::to_string(e.iatRva) + "\n";
        } else {
            std::printf("%s — %zu import\n", f.c_str(), imports.size());
            std::string lastDll;
            for (const ImportEntry &e : imports) {
                if (e.dll != lastDll) {
                    lastDll = e.dll;
                    std::printf("\n[%s]\n", e.dll.c_str());
                }
                std::string nm = e.name.empty() ? std::string("ordinal #") +
                                                      std::to_string(e.ordinal)
                                                : e.name;
                std::printf("  IAT 0x%08x  %s\n", e.iatRva, nm.c_str());
            }
            continue;
        }
        std::fputs(text.c_str(), stdout);
    }
    return 0;
}

// ---------------------------------------------------------------------------
// enyakin komutu
// ---------------------------------------------------------------------------
static int cmdNearest(const CliArgs &args) {
    if (args.files.size() < 2) {
        std::fprintf(stderr, "HATA: kullanım: pdbscope enyakin <hedef> <adres>\n");
        return 2;
    }
    std::string target = args.files[0];
    auto addr = parseNumber(args.files[1]);
    if (!addr) {
        std::fprintf(stderr, "HATA: adres çözümlenemedi: %s\n", args.files[1].c_str());
        return 2;
    }

    TargetKind kind = detectTarget(target);
    std::string pdbPath;
    PeFile pe;
    bool havePe = false;
    uint64_t imageBase = 0;

    auto openPe = [&](const std::string &p) {
        std::string err;
        if (pe.open(p, &err)) {
            imageBase = pe.imageBase();
            havePe = true;
            return true;
        }
        std::fprintf(stderr, "UYARI: PE açılamadı (%s)\n", err.c_str());
        return false;
    };

    if (kind == TargetKind::Pe) {
        openPe(target);
        std::string note, err;
        pdbPath = locatePdbFor(target, args.pdbPath, true, &note, &err);
        if (!note.empty()) std::fprintf(stderr, "%s\n", note.c_str());
    } else if (kind == TargetKind::Pdb) {
        pdbPath = target;
        if (!args.exePath.empty()) openPe(args.exePath);
    } else if (kind == TargetKind::MapFile) {
        MapParseResult res;
        std::string err;
        if (!parseMapFile(target, nullptr, res, &err)) {
            std::fprintf(stderr, "HATA: %s (%s)\n", err.c_str(), target.c_str());
            return 1;
        }
        uint64_t base = res.imageBaseKnown ? res.imageBase : 0x400000;
        uint64_t a = *addr;
        // VA mı RVA mı?
        if (a >= base && a < base + 0x10000000ull) a -= base;
        std::vector<Symbol> sorted = prepareSymbols(res.symbols, OutOpts{});
        NearestResult nr = findNearest(sorted, (uint32_t)a);
        if (!nr.found) {
            std::fprintf(stderr, "HATA: sembol yok\n");
            return 1;
        }
        const Symbol &s = sorted[nr.index];
        std::printf("Hedef : 0x%llx\n", (unsigned long long)*addr);
        std::printf("Sembol: 0x%08x %s\n", s.rva, s.name.c_str());
        if (nr.exact) std::printf("Durum: adrese denk (içeriyor)\n");
        else std::printf("Durum: en yakın, fark: %+lld bayt\n", (long long)nr.delta);
        return 0;
    } else {
        std::fprintf(stderr, "HATA: tanınmayan hedef.\n");
        return 1;
    }

    if (pdbPath.empty()) {
        // v2: PDB yoksa pdbless motoruyla en yakın fonksiyonu bul
        std::fprintf(stderr,
                     "PDB bulunamadı — pdbless motoru (statik analiz) kullanılıyor.\n");
        PdblessOpts po;
        PdblessAnalyzer a;
        std::string aerr;
        if (!a.analyze(pe, po, &aerr)) {
            std::fprintf(stderr, "HATA: %s\n", aerr.c_str());
            return 1;
        }
        uint64_t a2 = *addr;
        if (a2 >= imageBase && a2 < imageBase + pe.sizeOfImage()) a2 -= imageBase;
        if (a2 > 0xFFFFFFFFull) {
            std::fprintf(stderr, "HATA: adres 32-bit RVA aralığında değil.\n");
            return 2;
        }
        uint32_t rva = (uint32_t)a2;
        const PlFunction *best = nullptr;
        int64_t bestDelta = 0;
        for (const PlFunction &f : a.functions()) {
            if (f.cls == PlFunction::REJECT) continue;
            if (f.rva > rva) break;
            best = &f;
            bestDelta = (int64_t)rva - (int64_t)f.rva;
        }
        if (!best) {
            std::fprintf(stderr, "HATA: pdbless analizinde fonksiyon bulunamadı.\n");
            return 1;
        }
        std::printf("Hedef  : 0x%llx (RVA 0x%x, bölüm %s) [pdbless]\n",
                    (unsigned long long)*addr, rva, pe.sectionOfRva(rva).c_str());
        std::printf("Fonksiyon: 0x%08x %s\n", best->rva, best->name.c_str());
        std::printf("Güven : %d%% (%s)%s\n", (int)(best->confidence * 100),
                    best->classStr(), best->size ? "" : " (boyut bilinmiyor)");
        if (best->size && (uint64_t)bestDelta < best->size)
            std::printf("Konum : fonksiyon içinde, +%lld bayt\n", (long long)bestDelta);
        else
            std::printf("Konum : en yakın başlangıç, fark %+lld bayt\n",
                        (long long)bestDelta);
        return 0;
    }
    PdbFile pdb;
    std::string err;
    if (!pdb.open(pdbPath, &err)) {
        std::fprintf(stderr, "HATA: %s (%s)\n", err.c_str(), pdbPath.c_str());
        return 1;
    }

    CollectOpts co;
    co.merge = true;
    std::vector<Symbol> syms;
    pdb.collectSymbols(co, syms, nullptr, nullptr);
    std::vector<Symbol> sorted = prepareSymbols(syms, OutOpts{});

    // VA -> RVA dönüşümü (görüntü tabanı biliniyorsa)
    uint64_t a = *addr;
    if (havePe) {
        if (a >= imageBase && a < imageBase + pe.sizeOfImage()) a -= imageBase;
    } else if (a > 0xFFFFFFFFull) {
        std::fprintf(stderr, "UYARI: görüntü tabanı bilinmiyor; değer RVA varsayılıyor.\n");
    }
    if (a > 0xFFFFFFFFull) {
        std::fprintf(stderr, "HATA: adres 32-bit RVA aralığında değil.\n");
        return 2;
    }

    NearestResult nr = findNearest(sorted, (uint32_t)a);
    if (!nr.found) {
        std::fprintf(stderr, "HATA: sembol yok\n");
        return 1;
    }
    const Symbol &s = sorted[nr.index];
    std::string section = havePe ? pe.sectionOfRva((uint32_t)a)
                                 : pdb.sections().empty() ? "?" : [&] {
                                       for (size_t i = 0; i < pdb.sections().size(); i++)
                                           if ((uint32_t)a >= pdb.sections()[i].virtualAddress &&
                                               (uint32_t)a < pdb.sections()[i].virtualAddress +
                                                                 pdb.sections()[i].virtualSize)
                                               return std::string(pdb.sections()[i].name);
                                       return std::string("?");
                                   }();

    std::printf("Hedef  : 0x%llx (RVA 0x%llx, bölüm %s)\n", (unsigned long long)*addr,
                (unsigned long long)a, section.c_str());
    std::string dm = demangle(s.name);
    std::printf("Sembol : 0x%08x %s\n", s.rva,
                dm.empty() ? s.name.c_str() : dm.c_str());
    if (!dm.empty() && dm != s.name) std::printf("         (mangled: %s)\n", s.name.c_str());
    if (s.size) std::printf("Boyut  : %u bayt\n", s.size);
    if (nr.exact) {
        std::printf("Durum  : adres sembol içinde (içeren/fark %lld)\n",
                    (long long)nr.delta);
    } else {
        std::printf("Durum  : en yakın sembol, fark: %+lld bayt\n",
                    (long long)nr.delta);
    }
    // v2: satır bilgisi + FPO
    {
        LineInfo li;
        li.collect(pdb, true, nullptr);
        const LineEntry *le = li.lineForRva((uint32_t)a);
        if (le && le->fileIdx && le->fileIdx <= li.files().size()) {
            std::printf("Kaynak : %s:%u%s\n", li.files()[le->fileIdx - 1].name.c_str(),
                        le->line,
                        le->column ? (" (sütun " + std::to_string(le->column) + ")").c_str()
                                   : "");
        }
    }
    if (pdb.hasFpo()) {
        const FpoEntry *fe = pdb.fpoFor(s.rva);
        if (fe)
            std::printf("FPO    : %s çerçevesi, yerel %u bayt, param %u bayt, "
                        "prolog %u%s%s\n",
                        fe->frameType == cv::CV_FRAME_FPO ? "FPO (ebp yok)" : "ebp",
                        fe->localsBytes, fe->paramsBytes, fe->prologBytes,
                        fe->hasSEH ? ", SEH" : "", fe->hasEH ? ", C++ EH" : "");
    }
    // sonraki sembol
    if (nr.index + 1 < sorted.size())
        std::printf("Sonraki: 0x%08x %s\n", sorted[nr.index + 1].rva,
                    sorted[nr.index + 1].name.c_str());
    return 0;
}

// ---------------------------------------------------------------------------
// Argüman ayrıştırma
// ---------------------------------------------------------------------------
int mainImpl(int argc, char **argv) {
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif
    demangleInit();

    CliArgs args;
    std::vector<std::string> raw;
    for (int i = 1; i < argc; i++) raw.push_back(argv[i]);

    if (raw.empty()) {
        printHelp();
        return 0;
    }

    // ilk argüman komut mu?
    auto isOpt = [](const std::string &s) { return s.size() >= 2 && s[0] == '-'; };
    std::string first = raw[0];
    if (!isOpt(first)) {
        // "pdbscope exe pdbless <dosya>" kalıbında baştaki exe/dll belirteci
        // atlanır (hedef türü vurgusu)
        if ((toLower(first) == "exe" || toLower(first) == "dll") && raw.size() > 1 &&
            !isOpt(raw[1])) {
            raw.erase(raw.begin());
            first = raw[0];
        }
        std::string c = toLower(first);
        if (c == "semboller" || c == "symbols" || c == "sym" || c == "s")
            args.cmd = "semboller";
        else if (c == "pdbless" || c == "pdbsiz" || c == "n pdb")
            args.cmd = "pdbless";
        else if (c == "bilgi" || c == "info")
            args.cmd = "bilgi";
        else if (c == "satir" || c == "line" || c == "satırlar")
            args.cmd = "satir";
        else if (c == "kaynaklar" || c == "sources" || c == "files")
            args.cmd = "kaynaklar";
        else if (c == "turler" || c == "türler" || c == "types" || c == "udt")
            args.cmd = "turler";
        else if (c == "bolum" || c == "sections" || c == "sec")
            args.cmd = "bolum";
        else if (c == "disa" || c == "exports" || c == "export")
            args.cmd = "disa";
        else if (c == "ice" || c == "imports" || c == "import")
            args.cmd = "ice";
        else if (c == "dizgiler" || c == "strings" || c == "str")
            args.cmd = "dizgiler";
        else if (c == "vftable" || c == "vftables" || c == "siniflar" || c == "classes")
            args.cmd = "vftable";
        else if (c == "enyakin" || c == "nearest" || c == "yakin")
            args.cmd = "enyakin";
        else if (c == "yardim" || c == "help")
            args.cmd = "yardim";
        else {
            // dosya olarak yorumla: varsayılan komut semboller
            args.files.push_back(first);
            args.cmd = "semboller";
        }
        raw.erase(raw.begin());
    }

    for (size_t i = 0; i < raw.size(); i++) {
        const std::string &a = raw[i];
        auto next = [&](const char *what) -> std::string {
            if (i + 1 >= raw.size()) {
                std::fprintf(stderr, "HATA: %s bir değer ister\n", what);
                exit(2);
            }
            return raw[++i];
        };
        if (a == "--help" || a == "-h" || a == "yardim") args.cmd = "yardim";
        else if (a == "--versiyon" || a == "--version" || a == "-v") {
            std::printf("%s\n", VERSION);
            return 0;
        } else if (a == "--pdb" || a == "-p") args.pdbPath = next("--pdb");
        else if (a == "--exe" || a == "-e") args.exePath = next("--exe");
        else if (a == "--format" || a == "-f") args.format = toLower(next("--format"));
        else if (a == "--tur" || a == "--type" || a == "-t")
            args.types = toLower(next("--tur"));
        else if (a == "--filtre" || a == "--filter") args.filter = next("--filtre");
        else if (a == "--regex") args.regex = next("--regex");
        else if (a == "--sirala" || a == "--sort") args.sortBy = toLower(next("--sirala"));
        else if (a == "--limit" || a == "-l")
            args.limit = (int)strtol(next("--limit").c_str(), nullptr, 0);
        else if (a == "--modul" || a == "--module") args.moduleFilter = next("--modul");
        else if (a == "--cozumleme" || a == "--no-demangle") args.demangle = false;
        else if (a == "--ham" || a == "--raw") args.showMangled = true;
        else if (a == "--ayrik" || a == "--no-merge") args.noMerge = true;
        else if (a == "--cikti" || a == "--out" || a == "-o") args.outFile = next("--cikti");
        else if (a == "--json-guzel" || a == "--json-pretty") args.jsonPretty = true;
        else if (a == "--istatistik" || a == "--stats") args.stats = true;
        // v2
        else if (a == "--imza" || a == "--sigs" || a == "--signatures") args.showSig = true;
        else if (a == "--satirlar" || a == "--satır" || a == "--lines") args.showLines = true;
        else if (a == "--fpo") args.showFpo = true;
        else if (a == "--inline") args.includeInline = true;
        else if (a == "--min-guven" || a == "--min-confidence")
            args.minConf = (int)strtol(next("--min-guven").c_str(), nullptr, 0);
        else if (a == "--sinif" || a == "--class") args.plClasses = toLower(next("--sinif"));
        else if (a == "--vftable" || a == "--vftables") args.plVftables = true;
        else if (a == "--tum" || a == "--all") args.plAll = true;
        else if (a == "--no-rtti") args.plNoRtti = true;
        else if (a == "--no-cagri" || a == "--no-calls") args.plNoCalls = true;
        else if (a == "--no-prolog" || a == "--no-prologues") args.plNoProlog = true;
        else if (a == "--min" || a == "--min-len")
            args.strMin = (int)strtol(next("--min").c_str(), nullptr, 0);
        else if (isOpt(a)) {
            std::fprintf(stderr, "HATA: bilinmeyen seçenek: %s\n", a.c_str());
            printHelp();
            return 2;
        } else {
            args.files.push_back(a);
        }
    }

    if (args.cmd == "yardim") {
        printHelp();
        return 0;
    }
    if (args.cmd == "semboller") return cmdSymbols(args);
    if (args.cmd == "pdbless") return cmdPdbless(args);
    if (args.cmd == "bilgi") return cmdInfo(args);
    if (args.cmd == "satir") return cmdLine(args);
    if (args.cmd == "kaynaklar") return cmdSources(args);
    if (args.cmd == "turler") return cmdTypes(args);
    if (args.cmd == "bolum") return cmdSections(args);
    if (args.cmd == "disa") return cmdExports(args);
    if (args.cmd == "ice") return cmdImports(args);
    if (args.cmd == "dizgiler") return cmdStrings(args);
    if (args.cmd == "vftable") return cmdPdbless(args, true);
    if (args.cmd == "enyakin") return cmdNearest(args);
    printHelp();
    return 2;
}

int main(int argc, char **argv) {
    try {
        return mainImpl(argc, argv);
    } catch (const std::exception &e) {
        std::fprintf(stderr, "HATA: beklenmeyen durum: %s\n", e.what());
        return 1;
    }
}
