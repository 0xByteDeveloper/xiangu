// ============================================================================
//  PDBScope — mapfile.h
//  Bağlayıcı .map dosyası ayrıştırıcı (MSVC link /MAP ve GNU ld biçimleri).
// ============================================================================
#pragma once

#include <cstdint>
#include <string>
#include <vector>

#include "pdb.h" // Symbol

namespace pdbscope {

class PeFile;

enum class MapFormat { Unknown, Msvc, Gnu };

// Metin dosyayı tarayıp biçimi belirler (ilk 64 satır yeterli).
MapFormat detectMapFormat(const std::vector<uint8_t> &data);

struct MapParseResult {
    MapFormat format = MapFormat::Unknown;
    uint64_t imageBase = 0;      // "Preferred load address" / hesaplanan taban
    bool imageBaseKnown = false;
    std::vector<Symbol> symbols; // rva dolu; size çoğunlukla 0 (map'te yok)
    std::vector<SectionHdr> sections; // ad + VA (boyutlu, MSVC'de)
    uint32_t parseErrors = 0;
};

// .map içeriğini ayrıştırır. pe biliniyorsa (opsiyonel) imageBase/segment
// doğrulaması ve düzeltmesi için kullanılır.
bool parseMapFile(const std::string &path, const PeFile *pe, MapParseResult &out,
                  std::string *err);

} // namespace pdbscope
