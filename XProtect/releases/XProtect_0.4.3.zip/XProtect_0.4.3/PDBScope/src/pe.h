// ============================================================================
//  PDBScope — pe.h
//  PE (exe/dll) ayrıştırıcı: bölümler, hata ayıklama dizini (PDB bulma),
//  export/import tabloları.
// ============================================================================
#pragma once

#include <cstdint>
#include <string>
#include <vector>

#include "pdb.h" // SectionHdr

namespace pdbscope {

struct CvDebugInfo {
    bool found = false;
    bool isRsds = true;        // true: RSDS (PDB70), false: NB10 (eski)
    uint8_t guid[16] = {0};    // RSDS GUID
    uint32_t age = 0;
    std::string pdbPath;       // derleme zamanındaki PDB yolu
    uint32_t debugRva = 0;     // hata ayıklama dizininin RVA'sı
};

struct ExportEntry {
    uint32_t rva = 0;
    uint32_t ordinal = 0;
    std::string name;         // ad yoksa boş
    std::string forwarder;    // iletici (forwarded) export ise dolu
};

struct ImportEntry {
    std::string dll;
    std::string name;         // ad içe aktarımı (ordinal ise boş)
    uint16_t ordinal = 0;
    uint32_t iatRva = 0;      // IAT yuvasının RVA'sı
};

struct DelayImportDll {
    std::string dll;
    std::vector<ImportEntry> entries;
};

class PeFile {
public:
    bool open(const std::string &path, std::string *err);

    const std::string &path() const { return path_; }
    bool valid() const { return valid_; }
    uint16_t machine() const { return machine_; }
    uint16_t characteristics() const { return characteristics_; }
    uint16_t dllCharacteristics() const { return dllChars_; }
    bool isDll() const { return (characteristics_ & 0x2000) != 0; }
    bool is64() const { return optionalMagic_ == 0x20b; }
    uint32_t timestamp() const { return timestamp_; }
    uint64_t imageBase() const { return imageBase_; }
    uint32_t sizeOfImage() const { return sizeOfImage_; }
    uint32_t entryPointRva() const { return entryRva_; }
    uint32_t numberOfSections() const { return (uint32_t)sections_.size(); }
    const std::vector<SectionHdr> &sections() const { return sections_; }
    const CvDebugInfo &cvDebug() const { return cv_; }

    // v2: pdbless/analiz için ek erişimciler
    uint32_t dataDirRva(int i) const { return (i >= 0 && i < 16) ? dirRva_[i] : 0; }
    uint32_t dataDirSize(int i) const { return (i >= 0 && i < 16) ? dirSize_[i] : 0; }
    uint32_t coffSymTabOff() const { return coffSymOff_; }  // 0 = tablo yok
    uint32_t coffSymCount() const { return coffSymCount_; }
    // zengin başlık (Rich): ürün kimlikleri listesi (boş = yok)
    const std::vector<uint16_t> &richProductIds() const { return richIds_; }

    // RVA'nın ait olduğu bölüm adı (yoksa "?")
    std::string sectionOfRva(uint32_t rva) const;

    bool readExports(std::vector<ExportEntry> &out, std::string *err) const;
    bool readImports(std::vector<ImportEntry> &out, std::string *err) const;

    // Dosya içindeki bir RVA'dan dosya ofsetine (null-sonlandırmalı dizge okuma için)
    bool rvaToOffset(uint32_t rva, uint32_t &fileOff) const;

    const std::vector<uint8_t> &raw() const { return data_; }

private:
    bool parseHeaders(std::string *err);
    void parseRichHeader();

    std::string path_;
    std::vector<uint8_t> data_;
    bool valid_ = false;
    uint16_t machine_ = 0;
    uint16_t characteristics_ = 0;
    uint16_t dllChars_ = 0;
    uint16_t optionalMagic_ = 0;
    uint32_t timestamp_ = 0;
    uint64_t imageBase_ = 0;
    uint32_t sizeOfImage_ = 0;
    uint32_t entryRva_ = 0;
    uint32_t numberOfRvaAndSizes_ = 0;
    uint32_t coffSymOff_ = 0, coffSymCount_ = 0;
    std::vector<uint16_t> richIds_;
    std::vector<SectionHdr> sections_;
    CvDebugInfo cv_;
    // veri dizinleri
    uint32_t dirRva_[16] = {0};
    uint32_t dirSize_[16] = {0};
};

// ---- PDB keşfi -------------------------------------------------------------
// Bir exe/dll'nin hata ayıklama dizininden CodeView bilgisi çıkarır.
bool peFindCvDebug(const std::string &pePath, CvDebugInfo &out, std::string *err);

// Hedef için PDB adaylarını sırayla dener; GUID+yaş eşleşeni döndürür.
// Sıra: --pdb açık yolu, PE yanındaki aynı adlı dosya, RSDS yolundaki dosya,
// sembol sunucusu alt dizin düzeni (<ad>.pdb/<GUID><yaş>/<ad>.pdb)
std::string locatePdbFor(const std::string &pePath, const std::string &explicitPdb,
                         bool verify, std::string *note, std::string *err);

} // namespace pdbscope
