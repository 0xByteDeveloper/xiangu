// ============================================================================
//  PDBScope — msf.cpp
// ============================================================================
#include "msf.h"
#include "util.h"

namespace pdbscope {

static const char MSF7_MAGIC[24] = {
    'M', 'i', 'c', 'r', 'o', 's', 'o', 'f', 't', ' ', 'C', '/', 'C', '+', '+', ' ',
    'M', 'S', 'F', ' ', '7', '.', '0', '0'
};
// tam sihir baytları: "Microsoft C/C++ MSF 7.00\r\n\x1ADS\0\0\0"
static const uint8_t MSF7_FULL[32] = {
    'M', 'i', 'c', 'r', 'o', 's', 'o', 'f', 't', ' ', 'C', '/', 'C', '+', '+', ' ',
    'M', 'S', 'F', ' ', '7', '.', '0', '0', 0x0d, 0x0a, 0x1a, 'D', 'S', 0, 0, 0
};

bool MsfFile::open(const std::string &path, std::string *err) {
    data_ = readFile(path, err);
    if (data_.empty()) {
        if (err && err->empty()) *err = "dosya okunamadı";
        return false;
    }
    return parseHeaders(err);
}

bool MsfFile::openBuffer(std::vector<uint8_t> data, std::string *err) {
    data_ = std::move(data);
    return parseHeaders(err);
}

bool MsfFile::parseHeaders(std::string *err) {
    auto fail = [&](const std::string &msg) {
        if (err) *err = msg;
        return false;
    };

    if (data_.size() < 64) return fail("dosya çok küçük (MSF değil?)");

    // Sihrin tamamı (32 bayt) eşleşmeli.
    if (std::memcmp(data_.data(), MSF7_FULL, sizeof MSF7_FULL) != 0) {
        // Eski / farklı biçimler için ipucu
        if (std::memcmp(data_.data(), MSF7_MAGIC, 24) == 0)
            return fail("MSF 7.00 sihri bozuk");
        if (std::memcmp(data_.data(), "Microsoft C/C++ program database 2.00", 37) == 0)
            return fail("eski PDB 2.00 (VC6) biçimi desteklenmiyor");
        if (std::memcmp(data_.data(), "BSJB", 4) == 0)
            return fail("bu bir Portable PDB (yönetilen/.NET) — yerel PDB değil");
        return fail("MSF sihri bulunamadı (PDB değil)");
    }

    Cursor c(data_.data(), data_.size(), 32); // sihir 32 bayt: alanlar ofset 32'den başlar
    uint32_t freeBlockMapBlock = 0, numDirectoryBytes = 0, unknown1 = 0, blockMapAddr = 0;
    if (!c.u32(blockSize_) || !c.u32(freeBlockMapBlock) || !c.u32(blockCount_) ||
        !c.u32(numDirectoryBytes) || !c.u32(unknown1) || !c.u32(blockMapAddr))
        return fail("MSF süperbloğu okunamadı");

    if (blockSize_ != 512 && blockSize_ != 1024 && blockSize_ != 4096 && blockSize_ != 8192 &&
        blockSize_ != 16384)
        return fail("geçersiz blok boyutu: " + std::to_string(blockSize_));
    if (blockCount_ == 0 || (uint64_t)blockCount_ * blockSize_ > data_.size() + blockSize_)
        return fail("geçersiz blok sayısı");
    if (numDirectoryBytes == 0 || numDirectoryBytes > 100u * 1024 * 1024)
        return fail("geçersiz dizin boyutu");
    if (freeBlockMapBlock != 1 && freeBlockMapBlock != 2)
        return fail("geçersiz serbest blok haritası konumu");

    // Blok haritasını oku: dizinin blok numaraları
    uint32_t numDirBlocks = (numDirectoryBytes + blockSize_ - 1) / blockSize_;
    uint64_t blockMapOff = (uint64_t)blockMapAddr * blockSize_;
    if (blockMapOff + (uint64_t)numDirBlocks * 4 > data_.size())
        return fail("blok haritası dosya dışında");

    std::vector<uint8_t> dir(numDirBlocks * blockSize_);
    for (uint32_t i = 0; i < numDirBlocks; i++) {
        uint32_t b;
        std::memcpy(&b, data_.data() + blockMapOff + (uint64_t)i * 4, 4);
        if ((uint64_t)(b + 1) * blockSize_ > data_.size())
            return fail("dizin bloğu dosya dışında");
        std::memcpy(dir.data() + (size_t)i * blockSize_,
                    data_.data() + (uint64_t)b * blockSize_, blockSize_);
    }

    Cursor d(dir.data(), numDirectoryBytes);
    uint32_t numStreams = 0;
    if (!d.u32(numStreams)) return fail("akış sayısı okunamadı");
    if (numStreams > 0x10000) return fail("aşırı akış sayısı");

    streamSizes_.resize(numStreams);
    for (uint32_t i = 0; i < numStreams; i++)
        if (!d.u32(streamSizes_[i])) return fail("akış boyutu okunamadı");

    streamMaps_.resize(numStreams);
    for (uint32_t i = 0; i < numStreams; i++) {
        uint32_t sz = streamSizes_[i];
        // 0xFFFFFFFF = akış yok/ölü
        uint32_t n = (sz == 0xFFFFFFFFu) ? 0 : (sz + blockSize_ - 1) / blockSize_;
        streamMaps_[i].resize(n);
        for (uint32_t j = 0; j < n; j++) {
            if (!d.u32(streamMaps_[i][j])) return fail("akış blok listesi okunamadı");
            if ((uint64_t)(streamMaps_[i][j] + 1) * blockSize_ > data_.size())
                return fail("akış bloğu dosya dışında");
        }
    }
    return true;
}

bool MsfFile::materialize(uint32_t idx, std::vector<uint8_t> &out, std::string *err) const {
    if (idx >= streamSizes_.size()) {
        if (err) *err = "akış indeksi geçersiz: " + std::to_string(idx);
        return false;
    }
    uint32_t sz = streamSizes_[idx];
    if (sz == 0xFFFFFFFFu) {
        out.clear();
        return true;
    }
    out.resize(sz);
    const auto &blocks = streamMaps_[idx];
    uint32_t done = 0;
    for (uint32_t b : blocks) {
        if (done >= sz) break;
        uint32_t chunk = std::min(blockSize_, sz - done);
        std::memcpy(out.data() + done, data_.data() + (uint64_t)b * blockSize_, chunk);
        done += chunk;
    }
    return true;
}

} // namespace pdbscope
