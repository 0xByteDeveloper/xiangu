// ============================================================================
//  PDBScope — PDB/MAP/PE sembol ve RVA analiz aracı
//  util.h — bayt okuma, dosya IO, dizge yardımcıları
//
//  Taşınabilir C++17: MSVC 2019 (v142) ve MinGW-w64 / GCC / Clang uyumlu.
// ============================================================================
#pragma once

#include <cstdint>
#include <cstddef>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <optional>

namespace pdbscope {

// ---------------------------------------------------------------------------
//Dosya IO
// ---------------------------------------------------------------------------

// Dosyanın tamamını belleğe okur. Windows'ta UTF-8 yol -> geniş karakter.
std::vector<uint8_t> readFile(const std::string &path, std::string *errOut = nullptr);
bool fileExists(const std::string &path);
uint64_t fileSizeOf(const std::string &path);

// ---------------------------------------------------------------------------
// Küçük endian okuyucu
// ---------------------------------------------------------------------------
class Cursor {
public:
    Cursor() = default;
    Cursor(const uint8_t *data, size_t size, size_t pos = 0)
        : data_(data), size_(size), pos_(pos) {}

    size_t pos() const { return pos_; }
    size_t size() const { return size_; }
    size_t remaining() const { return pos_ < size_ ? size_ - pos_ : 0; }
    void seek(size_t p) { pos_ = p; }
    bool skip(size_t n) {
        if (n > remaining()) return false;
        pos_ += n;
        return true;
    }

    bool u8(uint8_t &v) {
        if (remaining() < 1) return false;
        v = data_[pos_++];
        return true;
    }
    bool u16(uint16_t &v) {
        if (remaining() < 2) return false;
        v = (uint16_t)(data_[pos_] | (data_[pos_ + 1] << 8));
        pos_ += 2;
        return true;
    }
    bool u32(uint32_t &v) {
        if (remaining() < 4) return false;
        v = (uint32_t)data_[pos_] | ((uint32_t)data_[pos_ + 1] << 8) |
            ((uint32_t)data_[pos_ + 2] << 16) | ((uint32_t)data_[pos_ + 3] << 24);
        pos_ += 4;
        return true;
    }
    bool i32(int32_t &v) {
        uint32_t u;
        if (!u32(u)) return false;
        v = (int32_t)u;
        return true;
    }
    bool u64(uint64_t &v) {
        uint32_t lo, hi;
        if (!u32(lo) || !u32(hi)) return false;
        v = ((uint64_t)hi << 32) | lo;
        return true;
    }

    // Kalan veriden sabit uzunluklu dilim döndürür (kopyalamaz).
    bool bytes(const uint8_t *&p, size_t n) {
        if (n > remaining()) return false;
        p = data_ + pos_;
        pos_ += n;
        return true;
    }

    // NULL sonlandırmalı dizge okur (CodeView kayıt isimleri).
    bool cstr(std::string &out) {
        size_t start = pos_;
        while (pos_ < size_ && data_[pos_] != 0) pos_++;
        if (pos_ >= size_) return false; // sonlandırıcı yok
        out.assign((const char *)data_ + start, pos_ - start);
        pos_++; // '\0'
        return true;
    }

    // 1 bayt uzunluk önekli dizge (eski "_ST" CodeView kayıt varyantları).
    bool pstr(std::string &out) {
        uint8_t len;
        if (!u8(len)) return false;
        if (len > remaining()) return false;
        out.assign((const char *)data_ + pos_, len);
        pos_ += len;
        return true;
    }

private:
    const uint8_t *data_ = nullptr;
    size_t size_ = 0;
    size_t pos_ = 0;
};

// ---------------------------------------------------------------------------
// Dizge yardımcıları
// ---------------------------------------------------------------------------
std::string toLower(std::string s);
std::string trim(const std::string &s);
bool containsCI(const std::string &hay, const std::string &needle); // küçük harf duyarsız içerir
std::string hexU32(uint32_t v, int width = 8);
std::string hexU64(uint64_t v, int width = 16);
std::string guidToString(const uint8_t guid[16]);
// "guid+age" MS sembol sunucusu alt dizin biçimi: 32 haneli BÜYÜK hex + ondalık yaş
std::string guidAgeSymbolPath(const uint8_t guid[16], uint32_t age);

// Onaltılık / ondalık sayı ayrıştırma ("0x1A2B", "140001234", "00401000"...)
std::optional<uint64_t> parseNumber(const std::string &s);

// Dosya adı yardımcıları
std::string dirName(const std::string &path);
std::string baseName(const std::string &path);
std::string replaceExt(const std::string &path, const std::string &newExt);
std::string joinPath(const std::string &a, const std::string &b);

// CSV/JSON alan kaçışları
std::string csvEscape(const std::string &s);
std::string jsonEscape(const std::string &s);

// Dosyaya yazma (UTF-8, CSV için BOM seçeneği)
bool writeFileText(const std::string &path, const std::string &content, bool bom, std::string *err);

} // namespace pdbscope
