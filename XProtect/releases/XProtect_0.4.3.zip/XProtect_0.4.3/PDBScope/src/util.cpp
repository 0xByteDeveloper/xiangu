// ============================================================================
//  PDBScope — util.cpp
// ============================================================================
#include "util.h"

#include <algorithm>
#include <cctype>
#include <fstream>
#include <sstream>

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif

namespace pdbscope {

// ---------------------------------------------------------------------------
//Dosya IO
// ---------------------------------------------------------------------------

std::vector<uint8_t> readFile(const std::string &path, std::string *errOut) {
    std::vector<uint8_t> out;
    auto fail = [&](const std::string &msg) {
        if (errOut) *errOut = msg + ": " + path;
        return out;
    };

#ifdef _WIN32
    // UTF-8 -> UTF-16 (dosya adlarında Türkçe/Unicode destek)
    int wlen = MultiByteToWideChar(CP_UTF8, 0, path.c_str(), -1, nullptr, 0);
    if (wlen <= 0) return fail("geçersiz dosya yolu");
    std::vector<wchar_t> wpath((size_t)wlen);
    MultiByteToWideChar(CP_UTF8, 0, path.c_str(), -1, wpath.data(), wlen);

    HANDLE h = CreateFileW(wpath.data(), GENERIC_READ, FILE_SHARE_READ, nullptr,
                           OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) return fail("dosya açılamadı");

    LARGE_INTEGER sz;
    if (!GetFileSizeEx(h, &sz) || sz.QuadPart < 0) {
        CloseHandle(h);
        return fail("dosya boyutu alınamadı");
    }
    out.resize((size_t)sz.QuadPart);
    DWORD got = 0;
    size_t off = 0;
    while (off < out.size()) {
        DWORD chunk = (DWORD)std::min<size_t>(out.size() - off, 1u << 30);
        if (!ReadFile(h, out.data() + off, chunk, &got, nullptr) || got != chunk) {
            CloseHandle(h);
            out.clear();
            return fail("dosya okunamadı");
        }
        off += got;
    }
    CloseHandle(h);
    return out;
#else
    std::ifstream f(path, std::ios::binary);
    if (!f) return fail("dosya açılamadı");
    f.seekg(0, std::ios::end);
    std::streamoff sz = f.tellg();
    if (sz < 0) return fail("dosya boyutu alınamadı");
    f.seekg(0, std::ios::beg);
    out.resize((size_t)sz);
    if (sz > 0) f.read((char *)out.data(), sz);
    if (!f && !f.eof()) {
        out.clear();
        return fail("dosya okunamadı");
    }
    return out;
#endif
}

bool fileExists(const std::string &path) {
#ifdef _WIN32
    int wlen = MultiByteToWideChar(CP_UTF8, 0, path.c_str(), -1, nullptr, 0);
    if (wlen <= 0) return false;
    std::vector<wchar_t> wpath((size_t)wlen);
    MultiByteToWideChar(CP_UTF8, 0, path.c_str(), -1, wpath.data(), wlen);
    DWORD attr = GetFileAttributesW(wpath.data());
    return attr != INVALID_FILE_ATTRIBUTES && !(attr & FILE_ATTRIBUTE_DIRECTORY);
#else
    std::ifstream f(path, std::ios::binary);
    return f.good();
#endif
}

uint64_t fileSizeOf(const std::string &path) {
#ifdef _WIN32
    int wlen = MultiByteToWideChar(CP_UTF8, 0, path.c_str(), -1, nullptr, 0);
    if (wlen <= 0) return 0;
    std::vector<wchar_t> wpath((size_t)wlen);
    MultiByteToWideChar(CP_UTF8, 0, path.c_str(), -1, wpath.data(), wlen);
    HANDLE h = CreateFileW(wpath.data(), GENERIC_READ, FILE_SHARE_READ, nullptr,
                           OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) return 0;
    LARGE_INTEGER sz;
    uint64_t r = 0;
    if (GetFileSizeEx(h, &sz)) r = (uint64_t)sz.QuadPart;
    CloseHandle(h);
    return r;
#else
    std::ifstream f(path, std::ios::binary);
    if (!f) return 0;
    f.seekg(0, std::ios::end);
    std::streamoff sz = f.tellg();
    return sz < 0 ? 0 : (uint64_t)sz;
#endif
}

// ---------------------------------------------------------------------------
// Dizge yardımcıları
// ---------------------------------------------------------------------------

std::string toLower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(),
                   [](unsigned char c) { return (char)std::tolower(c); });
    return s;
}

std::string trim(const std::string &s) {
    size_t a = 0, b = s.size();
    while (a < b && std::isspace((unsigned char)s[a])) a++;
    while (b > a && std::isspace((unsigned char)s[b - 1])) b--;
    return s.substr(a, b - a);
}

bool containsCI(const std::string &hay, const std::string &needle) {
    if (needle.empty()) return true;
    if (needle.size() > hay.size()) return false;
    auto it = std::search(hay.begin(), hay.end(), needle.begin(), needle.end(),
                          [](unsigned char a, unsigned char b) {
                              return std::tolower(a) == std::tolower(b);
                          });
    return it != hay.end();
}

static const char *HEX = "0123456789abcdef";

std::string hexU32(uint32_t v, int width) {
    char buf[16];
    int n = 0;
    if (v == 0) {
        buf[n++] = '0';
    } else {
        while (v && n < 16) {
            buf[n++] = HEX[v & 0xF];
            v >>= 4;
        }
    }
    std::string out;
    for (int i = n; i < width; i++) out += '0';
    for (int i = n - 1; i >= 0; i--) out += buf[i];
    return out;
}

std::string hexU64(uint64_t v, int width) {
    if (v <= 0xFFFFFFFFull) return hexU32((uint32_t)v, width);
    char buf[24];
    int n = 0;
    while (v && n < 24) {
        buf[n++] = HEX[(size_t)v & 0xF];
        v >>= 4;
    }
    std::string out;
    for (int i = n; i < width; i++) out += '0';
    for (int i = n - 1; i >= 0; i--) out += buf[i];
    return out;
}

std::string guidToString(const uint8_t g[16]) {
    char buf[48];
    std::snprintf(buf, sizeof buf,
                  "%08X-%04X-%04X-%02X%02X-%02X%02X%02X%02X%02X%02X",
                  (unsigned)(g[3] << 24 | g[2] << 16 | g[1] << 8 | g[0]),
                  (unsigned)(g[5] << 8 | g[4]),
                  (unsigned)(g[7] << 8 | g[6]),
                  g[8], g[9], g[10], g[11], g[12], g[13], g[14], g[15]);
    return buf;
}

std::string guidAgeSymbolPath(const uint8_t g[16], uint32_t age) {
    char buf[33];
    for (int i = 0; i < 16; i++)
        std::snprintf(buf + i * 2, 3, "%02X", g[i]);
    return std::string(buf) + std::to_string(age);
}

std::optional<uint64_t> parseNumber(const std::string &s0) {
    std::string s = trim(s0);
    if (s.empty()) return std::nullopt;
    // "h" / "H" son eki (MSVC map biçimi: 01400000H)
    bool hexSuffix = false;
    if (s.back() == 'h' || s.back() == 'H') {
        hexSuffix = true;
        s.pop_back();
    }
    if (s.empty()) return std::nullopt;
    try {
        size_t idx = 0;
        uint64_t v;
        if (s.size() > 2 && s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) {
            v = std::stoull(s, &idx, 16);
        } else if (s.size() > 2 && s[0] == '0' && (s[1] == 'o' || s[1] == 'O')) {
            v = std::stoull(s, &idx, 8);
        } else if (hexSuffix) {
            v = std::stoull(s, &idx, 16);
        } else {
            v = std::stoull(s, &idx, 10);
        }
        if (idx != s.size()) return std::nullopt;
        return v;
    } catch (...) {
        return std::nullopt;
    }
}

std::string dirName(const std::string &path) {
    size_t p = path.find_last_of("/\\");
    if (p == std::string::npos) return std::string();
    return path.substr(0, p);
}

std::string baseName(const std::string &path) {
    size_t p = path.find_last_of("/\\");
    return p == std::string::npos ? path : path.substr(p + 1);
}

std::string replaceExt(const std::string &path, const std::string &newExt) {
    std::string b = baseName(path);
    size_t dot = b.find_last_of('.');
    if (dot == std::string::npos) return path + newExt;
    std::string stem = b.substr(0, dot);
    std::string d = dirName(path);
    return d.empty() ? stem + newExt : d + "/" + stem + newExt;
}

std::string joinPath(const std::string &a, const std::string &b) {
    if (a.empty()) return b;
    if (b.empty()) return a;
    char last = a.back();
    if (last == '/' || last == '\\') return a + b;
    return a + "/" + b;
}

std::string csvEscape(const std::string &s) {
    bool need = s.find_first_of(",\"\n\r") != std::string::npos;
    if (!need) return s;
    std::string out = "\"";
    for (char c : s) {
        if (c == '"') out += "\"\"";
        else out += c;
    }
    out += "\"";
    return out;
}

std::string jsonEscape(const std::string &s) {
    std::string out;
    out.reserve(s.size() + 8);
    for (unsigned char c : s) {
        switch (c) {
        case '"': out += "\\\""; break;
        case '\\': out += "\\\\"; break;
        case '\b': out += "\\b"; break;
        case '\f': out += "\\f"; break;
        case '\n': out += "\\n"; break;
        case '\r': out += "\\r"; break;
        case '\t': out += "\\t"; break;
        default:
            if (c < 0x20) {
                char buf[8];
                std::snprintf(buf, sizeof buf, "\\u%04x", c);
                out += buf;
            } else {
                out += (char)c;
            }
        }
    }
    return out;
}

bool writeFileText(const std::string &path, const std::string &content, bool bom,
                   std::string *err) {
#ifdef _WIN32
    int wlen = MultiByteToWideChar(CP_UTF8, 0, path.c_str(), -1, nullptr, 0);
    if (wlen <= 0) {
        if (err) *err = "geçersiz yol";
        return false;
    }
    std::vector<wchar_t> wpath((size_t)wlen);
    MultiByteToWideChar(CP_UTF8, 0, path.c_str(), -1, wpath.data(), wlen);
    FILE *f = nullptr;
    if (_wfopen_s(&f, wpath.data(), L"wb") != 0 || !f) {
        if (err) *err = "dosya yazılamadı: " + path;
        return false;
    }
#else
    FILE *f = std::fopen(path.c_str(), "wb");
    if (!f) {
        if (err) *err = "dosya yazılamadı: " + path;
        return false;
    }
#endif
    if (bom) std::fwrite("\xEF\xBB\xBF", 1, 3, f);
    if (!content.empty()) std::fwrite(content.data(), 1, content.size(), f);
    std::fclose(f);
    return true;
}

} // namespace pdbscope
