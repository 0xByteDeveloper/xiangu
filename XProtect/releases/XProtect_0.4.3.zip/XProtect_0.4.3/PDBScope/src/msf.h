// ============================================================================
//  PDBScope — msf.h
//  MSF (Multi-Stream File) konteyneri: PDB dosyalarının dosya sistemi.
//
//  Biçim (Microsoft PDB / LLVM DebugInfo/MSF referansı):
//    SuperBlock (ofset 0):
//      char  Magic[24]      "Microsoft C/C++ MSF 7.00\r\n\x1ADS\0\0\0"
//      u32   BlockSize      (512 / 1024 / 4096)
//      u32   FreeBlockMapBlock
//      u32   NumBlocks
//      u32   NumDirectoryBytes
//      u32   Unknown1
//      u32   BlockMapAddr   (blok haritasının bulunduğu blok no)
//    Blok haritası = BlockMapAddr*BlockSize konumundaki u32 blok listesi
//    Dizin (directory) = [u32 streamSayısı][u32 boyutlar...][u32 blokNo listeleri...]
// ============================================================================
#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace pdbscope {

class MsfFile {
public:
    // Dosyayı belleğe okuyup MSF başlıklarını ayrıştırır.
    bool open(const std::string &path, std::string *err);
    bool openBuffer(std::vector<uint8_t> data, std::string *err);

    uint32_t blockSize() const { return blockSize_; }
    uint32_t blockCount() const { return blockCount_; }
    uint32_t streamCount() const { return (uint32_t)streamSizes_.size(); }
    uint32_t streamSize(uint32_t idx) const {
        return idx < streamSizes_.size() ? streamSizes_[idx] : 0;
    }
    const std::vector<uint32_t> &streamBlocks(uint32_t idx) const {
        return streamMaps_[idx];
    }
    uint64_t fileSize() const { return data_.size(); }

    // Akışı ardışık belleğe kopyalar. (MVP yaklaşımı: her istenen akış için
    // bir kez kopya; sembol listesi için gereken toplam bellek ~2x PDB boyutu)
    bool materialize(uint32_t idx, std::vector<uint8_t> &out, std::string *err) const;

    // Dosyadan bölüm doğrulaması için ham veri erişimi
    const uint8_t *raw() const { return data_.data(); }

private:
    bool parseHeaders(std::string *err);

    std::vector<uint8_t> data_;
    uint32_t blockSize_ = 0;
    uint32_t blockCount_ = 0;
    std::vector<uint32_t> streamSizes_;
    std::vector<std::vector<uint32_t>> streamMaps_;
};

} // namespace pdbscope
