// ============================================================================
//  PDBScope — demangle.cpp
// ============================================================================
#include "demangle.h"

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif

namespace pdbscope {

#ifdef _WIN32

// dbghelp.dll API prototipi (LEAN_AND_MEAN altında windows.h bunu getirmez)
using UndecorateFn = unsigned long(__stdcall *)(const char *, char *, unsigned long,
                                                unsigned long);
static UndecorateFn g_undname = nullptr;
static bool g_tried = false;

void demangleInit() {
    if (g_tried) return;
    g_tried = true;
    HMODULE h = LoadLibraryA("dbghelp.dll");
    if (!h) return;
    g_undname = reinterpret_cast<UndecorateFn>((void *)GetProcAddress(
        h, "UnDecorateSymbolNameA"));
}

bool demangleAvailable() {
    demangleInit();
    return g_undname != nullptr;
}

std::string demangle(const std::string &mangled) {
    demangleInit();
    if (!g_undname || mangled.empty()) return std::string();
    // yalnız MSVC mangled adları dene
    if (mangled[0] != '?' && mangled.find('@') == std::string::npos) return std::string();
    char buf[4096];
    // UNDNAME_COMPLETE = 0
    unsigned long r = g_undname(mangled.c_str(), buf, (unsigned long)sizeof buf, 0);
    if (r == 0) return std::string();
    return std::string(buf, r);
}

#else // !_WIN32 — test derlemeleri için çözümleme yok

void demangleInit() {}
bool demangleAvailable() { return false; }
std::string demangle(const std::string &) { return std::string(); }

#endif

} // namespace pdbscope
