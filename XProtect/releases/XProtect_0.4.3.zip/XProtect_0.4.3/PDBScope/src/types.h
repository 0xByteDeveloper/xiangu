// ============================================================================
//  PDBScope — types.h
//  TPI / IPI tip kayıtlarını yükleyip tip indekslerinden okunabilir tip
//  adları ve fonksiyon imzaları üretir.
//
//  TPI (akış 2) ve IPI (akış 4) düzeni:
//    başlık 56 bayt: {u32 sürüm, u32 hdrBoyut, u32 ilkIndeks, u32 sonIndeks,
//                     u32 kayıtBayt, u16 hashAkışı, u16 hashAux,
//                     u32 hashAnahtarBoyut, u32 kovaSayısı}
//    kayıtlar: [u16 uzunluk (pad dahil)][u16 yaprak][yük]... 4 bayt hizalı.
//    İlk tip indeksi firstIndex (genelde 0x1000).
// ============================================================================
#pragma once

#include <cstdint>
#include <map>
#include <string>
#include <vector>

#include "msf.h"
#include "util.h"

namespace pdbscope {

// Çözümlenmiş bir fonksiyon imzasının parçaları
struct FuncSignature {
    bool valid = false;
    std::string returnType;   // "int", "CPythonNetworkStream *", ...
    std::string callingConv;  // "__cdecl", "__thiscall", ...
    std::vector<std::string> argTypes;
    bool isMember = false;    // __thiscall (üye fonksiyon)
    std::string className;    // üye fonksiyonun sınıfı (biliniyorsa)
    // "int __cdecl Foo(int, char *)" biçiminde dize (ad hariç)
    std::string signatureStr(const std::string &funcName, bool withName = true) const;
};

// Kullanıcı tanımlı tip listesi elemanı (turler komutu)
struct UdtEntry {
    std::string name;
    std::string kind;    // class/struct/union/enum/interface
    uint64_t size = 0;
    bool fwdRef = false; // ileri bildirim (tam tanım değil)
    uint32_t typeIndex = 0;
};

class TypeStore {
public:
    // TPI veya IPI akışını yükler (idx: 2 veya 4).
    bool load(const MsfFile &msf, uint32_t idx, bool isIpi, std::string *err);

    uint32_t firstIndex() const { return firstIndex_; }
    uint32_t lastIndex() const { return lastIndex_; }
    bool empty() const { return records_.empty(); }

    // Tip indeksi -> okunabilir ad ("int", "const char *", "MyClass"...)
    std::string typeName(uint32_t typeIndex, int depth = 0) const;

    // LF_PROCEDURE / LF_MFUNCTION / LF_FUNC_ID / LF_MFUNC_ID -> imza.
    // (PDB'lerde S_GPROC32_ID kayıtlarının tip indeksi IPI'ye bakar.)
    FuncSignature signatureOfType(uint32_t typeIndex, int depth = 0) const;

    // IPI kimlik kaydı: LF_FUNC_ID / LF_MFUNC_ID adı
    std::string idName(uint32_t idIndex) const;
    bool isIdIndex(uint32_t idx) const {
        return idFirst_ != 0 && idx >= idFirst_ && idx < idLast_;
    }

    // Kullanıcı tipleri (class/struct/union/enum) listeler
    void collectUdts(std::vector<UdtEntry> &out) const;

    // IPI deposu için: ID kayıtlarının `type` alanları TPI'ye işaret eder;
    // kardeş depoyu bağla (PdbFile çağırır).
    void setSibling(const TypeStore *s) { sibling_ = s; }

private:
    struct Rec {
        uint16_t leaf = 0;
        const uint8_t *payload = nullptr; // yaprak sonrası yük
        size_t payloadSize = 0;
    };

    void buildIndex(const std::vector<uint8_t> &buf, uint32_t recordBytes,
                    uint32_t firstIdx);
    const Rec *find(uint32_t idx) const;

    // sayısal yaprak çözümleyici (dizi/sınıf boyutları)
    static bool readNumeric(Cursor &c, uint64_t &value);
    std::string joinArgs(const std::vector<std::string> &args) const;

    const TypeStore *sibling_ = nullptr; // ID -> tip çözümlemesi için TPI

    uint32_t firstIndex_ = 0, lastIndex_ = 0;
    uint32_t idFirst_ = 0, idLast_ = 0; // IPI aralığı (kendisi için)
    std::vector<uint8_t> buf_;          // akışın serileştirilmiş hali
    std::vector<Rec> records_;          // firstIndex_'ten itibaren ardışık
    mutable std::map<uint32_t, std::string> nameCache_;
};

} // namespace pdbscope
