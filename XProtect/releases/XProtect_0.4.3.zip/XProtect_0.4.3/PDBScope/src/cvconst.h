// ============================================================================
//  PDBScope — cvconst.h
//  CodeView sembol kayıt sabitleri.
//  Kaynak: microsoft/microsoft-pdb (cvinfo.h) — Apache gereksinimleriyle
//  uyumlu, yalnızca sabit değerleri referans alınarak yazılmış alt küme.
// ============================================================================
#pragma once

#include <cstdint>

namespace pdbscope {
namespace cv {

// ---- Sembol kayıt türleri (rectyp) ---------------------------------------
enum SymType : uint16_t {
    S_END          = 0x0006, // blok / yordam / thunk sonu
    S_LDATA32_ST   = 0x1007, // eski biçim: 1 bayt uzunluk önekli isim
    S_GDATA32_ST   = 0x1008,
    S_PUB32_ST     = 0x1009,
    S_LPROC32_ST   = 0x100A,
    S_GPROC32_ST   = 0x100B,
    S_VFTABLE32    = 0x100C, // sanal fonksiyon tablosu (adres sembolü değil)
    S_OBJNAME      = 0x1101, // "* Linker *" modül kimliği
    S_THUNK32      = 0x1102, // thunk başlangıcı
    S_BLOCK32      = 0x1103, // blok başlangıcı
    S_WITH32       = 0x1104,
    S_LABEL32      = 0x1105, // kod etiketi
    S_REGISTER     = 0x1106,
    S_CONSTANT     = 0x1107,
    S_UDT          = 0x1108, // kullanıcı tipi (adresi yok)
    S_LDATA32      = 0x110C, // modül-yerel veri
    S_GDATA32      = 0x110D, // global veri
    S_PUB32        = 0x110E, // genel (public) sembol
    S_LPROC32      = 0x110F, // yerel yordam (static fonksiyon)
    S_GPROC32      = 0x1110, // global yordam
    S_REGREL32     = 0x1111,
    S_LTHREAD32    = 0x1112,
    S_GTHREAD32    = 0x1113,
    S_COMPILE2     = 0x1116,
    S_COMPILE3     = 0x113C,
    S_PROCREF      = 0x1125, // yordam referansı (harici)
    S_DATAREF      = 0x1126,
    S_LPROCREF     = 0x1127,
    S_TRAMPOLINE   = 0x112C, // trampoline thunk
    S_SEPCODE      = 0x112A,
    S_LPROC32_ID   = 0x1146, // tip indeksi yerine ID taşıyan varyantlar
    S_GPROC32_ID   = 0x1147,
    S_INLINESITE   = 0x114D,
};

// PUBSYM32.pubsymflags bayrakları
enum PubSymFlags : uint32_t {
    cvpsfCode     = 0x1,
    cvpsfFunction = 0x2,
    cvpsfManaged  = 0x4,
    cvpsfMSIL     = 0x8,
};

// PROCSYM32.flags (CV_PROCFLAGS)
enum ProcFlags : uint8_t {
    cvpfFramePtrMask = 0xE0,
};

// TRAMPOLINESYM.trampType
enum TrampType : uint16_t {
    trampIncremental = 0,
    trampBranchIsland = 1,
};

// ---- Akış sürümleri -------------------------------------------------------
enum : uint32_t {
    PdbImplVC70 = 20000404,
    PdbImplVC80 = 20030901,
    PdbImplVC110 = 20091201,
    PdbImplVC140 = 20140508,
};
enum : uint32_t {
    DbiV60 = 19970606,
    DbiV70 = 19990903,
    DbiV110 = 20091201,
};
enum : uint32_t { TpiV70 = 19990903, TpiV80 = 20040203 };

// GSI hash başlık sabitleri
enum : uint32_t {
    GsiHdrSignature = 0xFFFFFFFFu,
    GsiHdrVersion = 0xeffe0000u + 19990810u,
};
constexpr uint32_t IPHR_HASH = 4096;

// ---- Bölüm katkısı sürümleri ----------------------------------------------
enum : uint32_t {
    SecContribVer60 = 0xeffe0000u + 19970605u,
    SecContribV2 = 0xeffe0000u + 20140516u,
};

// ---- Çağrı konvansiyonları (CV_call_t) -------------------------------------
enum CallConv : uint8_t {
    CV_CALL_NEAR_C = 0x00,     // __cdecl
    CV_CALL_FAR_C = 0x01,
    CV_CALL_NEAR_PASCAL = 0x02, // __pascal
    CV_CALL_FAR_PASCAL = 0x03,
    CV_CALL_NEAR_FAST = 0x04,   // __fastcall
    CV_CALL_FAR_FAST = 0x05,
    CV_CALL_SKIPPED = 0x06,
    CV_CALL_NEAR_STD = 0x07,    // __stdcall
    CV_CALL_FAR_STD = 0x08,
    CV_CALL_NEAR_SYS = 0x09,    // __syscall
    CV_CALL_FAR_SYS = 0x0A,
    CV_CALL_THISCALL = 0x0B,    // __thiscall
    CV_CALL_MIPSCALL = 0x0C,
    CV_CALL_GENERIC = 0x0D,
    CV_CALL_ALPHACALL = 0x0E,
    CV_CALL_PPCCALL = 0x0F,
    CV_CALL_SHCALL = 0x10,
    CV_CALL_ARMCALL = 0x11,
    CV_CALL_CLRCALL = 0x12,     // __clrcall
    CV_CALL_INLINE = 0x13,
    CV_CALL_NEAR_VECTOR = 0x14, // __vectorcall
};
const char *callConvName(uint8_t cc);

// ---- TPI/IPI yaprak türleri (leaf) ------------------------------------------
enum LeafType : uint16_t {
    LF_MODIFIER = 0x1001, // const/volatile sarmalayıcı
    LF_POINTER = 0x1002,
    LF_PROCEDURE = 0x1008,   // bağımsız fonksiyon tipi
    LF_MFUNCTION = 0x1009,   // üye (metot) fonksiyon tipi
    LF_ARGLIST = 0x1201,     // argüman tip listesi
    LF_BITFIELD = 0x1205,
    LF_FIELDLIST = 0x1203,
    LF_ARRAY = 0x1503,
    LF_CLASS = 0x1504,
    LF_STRUCTURE = 0x1505,
    LF_UNION = 0x1506,
    LF_ENUM = 0x1507,
    LF_ALIAS = 0x150A, // typedef takma adı
    LF_INTERFACE = 0x1519,
    LF_FUNC_ID = 0x1601,      // IPI: genel fonksiyon kimliği (ad + tip)
    LF_MFUNC_ID = 0x1602,     // IPI: metot kimliği
    LF_BUILDINFO = 0x1603,
    LF_SUBSTR_LIST = 0x1604,
    LF_STRING_ID = 0x1605,
};

// LF_MODIFIER öznitelikleri (CV_modifier_t)
enum ModifierAttr : uint16_t {
    MOD_const = 0x0001,
    MOD_volatile = 0x0002,
    MOD_unaligned = 0x0004,
};

// Sayısal yaprak (LF_NUMERIC): boyut alanları bu kodlama ile gelir.
// 0x8000 altı değerler doğrudan u16 sayıdır.
enum NumericLeaf : uint16_t {
    LF_CHAR_ = 0x8000,
    LF_SHORT_ = 0x8001,
    LF_USHORT_ = 0x8002,
    LF_LONG_ = 0x8003,
    LF_ULONG_ = 0x8004,
    LF_QUADWORD_ = 0x8009,
    LF_UQUADWORD_ = 0x800A,
};

// ---- C13 (modül satır bilgisi) altbölüm türleri -----------------------------
enum DebugSubsectionKind : uint32_t {
    DEBUG_S_SYMBOLS = 0xF1,
    DEBUG_S_LINES = 0xF2,
    DEBUG_S_STRINGTABLE = 0xF3, // ham, null ayraçlı adlar (başlıksız)
    DEBUG_S_FILECHKSMS = 0xF4,  // girişler: {u32 adOfseti, u8 tür, karma...}
    DEBUG_S_FRAMEDATA = 0xF5,
    DEBUG_S_INLINEELINES = 0xF6,
    DEBUG_S_CROSSSCOPEIMPORTS = 0xF7,
    DEBUG_S_CROSSSCOPEEXPORTS = 0xF8,
    DEBUG_S_IL_LINES = 0xF9,
    DEBUG_S_FUNC_MDTOKEN_MAP = 0xFA,
    DEBUG_S_TYPE_MDTOKEN_MAP = 0xFB,
    DEBUG_S_MERGED_ASSEMBLYINPUT = 0xFC,
    DEBUG_S_COFF_SYMBOL_RVA = 0xFD,
};
enum : uint16_t { CV_LINES_HAVE_COLUMNS = 0x0001 };

// ---- FPO (frame pointer omission) --------------------------------------------
// Eski FPO akışı (dbg[0], yalnız x86): 16 baytlık kayıtlar.
//   u32 ulOffStart, u32 cbProcSize, u32 cdwLocals,
//   u16 cdwParams, u16 bitler{cbProlog:8, cbRegs:3, fHasSEH:1, fUseBP:1,
//   ayrılmış:1, cbFrame:2}
// Yeni FPO akışı (dbg[9], FRAMEDATA): 32 baytlık kayıtlar.

// Ek sembol türleri (v2)
enum : uint16_t {
    S_FRAMEPROC = 0x1012,
    S_INLINESITE2 = 0x115D,
};

// Çerçeve türleri (winnt.h FRAME_* makrolarıyla ÇAKIŞMAMASI için CV_ önekli)
enum FrameKind : uint8_t {
    CV_FRAME_FPO = 0,   // FPO çerçevesi (ebp kullanılmıyor)
    CV_FRAME_TRAP = 1,
    CV_FRAME_TSS = 2,
    CV_FRAME_NONFPO = 3, // ebp çerçevesi (standart)
};

} // namespace cv
} // namespace pdbscope
