// ============================================================================
//  PDBScope — pe.cpp
// ============================================================================
#include "pe.h"

#include <cstring>
#include <cstdlib>

#include "util.h"

namespace pdbscope {

// ---------------------------------------------------------------------------
// Başlık ayrıştırma
// ---------------------------------------------------------------------------
bool PeFile::open(const std::string &path, std::string *err) {
    path_ = path;
    data_ = readFile(path, err);
    if (data_.empty()) return false;
    valid_ = parseHeaders(err);
    return valid_;
}

// küçük yardımcı: iki u16 oku
static inline bool u16lo(Cursor &c, uint32_t &a, uint32_t &b) {
    uint16_t x = 0, y = 0;
    if (!c.u16(x) || !c.u16(y)) return false;
    a = x;
    b = y;
    return true;
}

bool PeFile::parseHeaders(std::string *err) {
    auto fail = [&](const std::string &m) {
        if (err) *err = m;
        return false;
    };
    if (data_.size() < 0x100) return fail("dosya çok küçük (PE değil?)");
    if (std::memcmp(data_.data(), "MZ", 2) != 0) return fail("MZ imzası yok (PE değil)");
    if (data_.size() < 0x40) return fail("dosya çok küçük");

    uint32_t eLfanew = (uint32_t)data_[0x3c] | ((uint32_t)data_[0x3d] << 8) |
                       ((uint32_t)data_[0x3e] << 16) | ((uint32_t)data_[0x3f] << 24);
    if (eLfanew == 0 || (size_t)eLfanew + 24 > data_.size())
        return fail("e_lfanew geçersiz");
    const uint8_t *pe = data_.data() + eLfanew;
    if (std::memcmp(pe, "PE\0\0", 4) != 0) return fail("PE imzası yok");

    Cursor c(pe + 4, data_.size() - (size_t)(pe - data_.data()) - 4);
    uint16_t numSections = 0, optSize = 0;
    uint32_t ptrSymTab = 0, numSyms = 0;
    if (!c.u16(machine_) || !c.u16(numSections) || !c.u32(timestamp_) ||
        !c.u32(ptrSymTab) || !c.u32(numSyms) || !c.u16(optSize) ||
        !c.u16(characteristics_))
        return fail("dosya başlığı okunamadı");
    coffSymOff_ = ptrSymTab;
    coffSymCount_ = numSyms;
    if (numSections == 0 || numSections > 96) return fail("bölüm sayısı geçersiz");

    if (optSize == 0) return fail("opsiyonel başlık yok (saf kernel modu?)");
    size_t optStart = c.pos();
    if (!c.u16(optionalMagic_)) return fail("opsiyonel başlık okunamadı");
    if (optionalMagic_ != 0x10b && optionalMagic_ != 0x20b)
        return fail("bilinmeyen opsiyonel başlık sihri: " + hexU32(optionalMagic_, 4));
    bool plus = (optionalMagic_ == 0x20b);

    // PE32:  ... PE32+: aynı ofsetlerde 8 bayt imageBase
    if (!c.skip(2)) return fail("bağlayıcı sürümü okunamadı"); // MajorLinkerVersion+Minor
    uint32_t sizeOfCode = 0, initSize = 0, uninitSize = 0;
    if (!c.u32(sizeOfCode) || !c.u32(initSize) || !c.u32(uninitSize) ||
        !c.u32(entryRva_) || !c.skip(plus ? 4 : 8)) // BaseOfCode (+PE32: BaseOfData)
        return fail("opsiyonel başlık alanları okunamadı");
    if (plus) {
        uint64_t lo = 0, hi = 0;
        if (!c.u64(imageBase_)) return fail("görüntü tabanı okunamadı");
        (void)lo;
        (void)hi;
    } else {
        uint32_t base = 0;
        if (!c.u32(base)) return fail("görüntü tabanı okunamadı");
        imageBase_ = base;
    }
    uint32_t sectAlign = 0, fileAlign = 0;
    if (!c.u32(sectAlign) || !c.u32(fileAlign)) return fail("hizalama okunamadı");
    if (!c.skip(16)) return fail("sürüm alanları okunamadı"); // OS/Image/SubSys/Win32Vers
    if (!c.u32(sizeOfImage_) || !c.skip(4)) return fail("SizeOfImage okunamadı"); // SizeOfHeaders
    if (!c.skip(4)) return fail("checksum okunamadı");
    uint16_t subsystem = 0;
    if (!c.u16(subsystem) || !c.u16(dllChars_)) return fail("alt sistem okunamadı");
    if (!c.skip(plus ? 32 : 16))
        return fail("yığın/yığın boyutları okunamadı"); // PE32+: u64×4, PE32: u32×4
    if (!c.skip(4)) return fail("LoaderFlags okunamadı");
    if (!c.u32(numberOfRvaAndSizes_)) return fail("NumberOfRvaAndSizes okunamadı");
    if (numberOfRvaAndSizes_ > 16) numberOfRvaAndSizes_ = 16;
    for (uint32_t i = 0; i < numberOfRvaAndSizes_; i++)
        if (!c.u32(dirRva_[i]) || !c.u32(dirSize_[i]))
            return fail("veri dizini okunamadı");

    // bölüm tablosu (opsiyonel başlığın hemen ardından)
    c.seek(optStart + optSize);
    sections_.resize(numSections);
    for (uint32_t i = 0; i < numSections; i++) {
        const uint8_t *p = nullptr;
        if (!c.bytes(p, 40)) return fail("bölüm tablosu okunamadı");
        SectionHdr &s = sections_[i];
        std::memcpy(s.name, p, 8);
        s.name[8] = 0;
        auto rd32 = [&](size_t o) {
            return (uint32_t)p[o] | ((uint32_t)p[o + 1] << 8) |
                   ((uint32_t)p[o + 2] << 16) | ((uint32_t)p[o + 3] << 24);
        };
        s.virtualSize = rd32(8);
        s.virtualAddress = rd32(12);
        s.sizeOfRawData = rd32(16);
        s.characteristics = rd32(36);
    }

    // hata ayıklama dizini (dizin 6) -> CodeView kaydı
    if (dirRva_[6] != 0 && dirSize_[6] >= 28) {
        uint32_t off = 0;
        if (rvaToOffset(dirRva_[6], off) && off + dirSize_[6] <= data_.size()) {
            Cursor d(data_.data() + off, dirSize_[6]);
            while (d.remaining() >= 28) {
                uint32_t chars = 0, ts = 0, majVer = 0, minVer = 0, dType = 0,
                         dataSize = 0, dRva = 0, dRaw = 0;
                if (!d.u32(chars) || !d.u32(ts) || !u16lo(d, majVer, minVer) ||
                    !d.u32(dType) || !d.u32(dataSize) || !d.u32(dRva) || !d.u32(dRaw))
                    break;
                if (dType == 2 && dataSize >= 24) { // IMAGE_DEBUG_TYPE_CODEVIEW
                    // PointerToRawData = dosya ofseti; AddressOfRawData = RVA
                    uint32_t fo = 0;
                    bool ok = false;
                    if (dRaw != 0 && (size_t)dRaw + dataSize <= data_.size()) {
                        fo = dRaw;
                        ok = true;
                    } else if (dRva != 0) {
                        ok = rvaToOffset(dRva, fo) && (size_t)fo + dataSize <= data_.size();
                    }
                    if (ok) {
                        const uint8_t *r = data_.data() + fo;
                        if (std::memcmp(r, "RSDS", 4) == 0 && dataSize >= 25) {
                            cv_.found = true;
                            cv_.isRsds = true;
                            std::memcpy(cv_.guid, r + 4, 16);
                            cv_.age = (uint32_t)r[20] | ((uint32_t)r[21] << 8) |
                                      ((uint32_t)r[22] << 16) | ((uint32_t)r[23] << 24);
                            cv_.pdbPath.assign((const char *)r + 24,
                                               strnlen((const char *)r + 24,
                                                       dataSize - 24));
                            cv_.debugRva = dRva;
                            break;
                        } else if (std::memcmp(r, "NB10", 4) == 0) {
                            cv_.found = true;
                            cv_.isRsds = false;
                            cv_.pdbPath.assign((const char *)r + 16,
                                               strnlen((const char *)r + 16,
                                                       dataSize - 16));
                            break;
                        }
                    }
                }
            }
        }
    }
    parseRichHeader();
    return true;
}

// ---------------------------------------------------------------------------
// Zengin başlık (Rich): DOS başlığı ile PE imzası arasında, DanS işaretiyle
// başlar; Rich imzası + XOR maskesiyle biter. Maskeli (ürünKimliği, sayı)
// çiftleri araç zinciri hakkında bilgi verir.
// ---------------------------------------------------------------------------
void PeFile::parseRichHeader() {
    richIds_.clear();
    const uint32_t eLfanew =
        (uint32_t)data_[0x3c] | ((uint32_t)data_[0x3d] << 8) |
        ((uint32_t)data_[0x3e] << 16) | ((uint32_t)data_[0x3f] << 24);
    if (eLfanew < 0x80 || eLfanew > data_.size()) return;

    // "Rich" + maske (son 8 bayt, imzadan hemen önce değil; geriye doğru ara)
    uint32_t mask = 0, richEnd = 0;
    for (uint32_t off = 0x40; off + 8 <= eLfanew; off += 4) {
        uint32_t v = (uint32_t)data_[off] | ((uint32_t)data_[off + 1] << 8) |
                     ((uint32_t)data_[off + 2] << 16) | ((uint32_t)data_[off + 3] << 24);
        if (v == 0x68636952) { // "Rich" little-endian
            mask = (uint32_t)data_[off + 4] | ((uint32_t)data_[off + 5] << 8) |
                   ((uint32_t)data_[off + 6] << 16) | ((uint32_t)data_[off + 7] << 24);
            richEnd = off; // Rich imzasının ofseti
            break;
        }
    }
    if (mask == 0 || richEnd == 0) return;

    // DanS (0x536E6144 ^ mask) konumunu bul; ondan Rich'e dek maskeli çiftler
    uint32_t dans = 0;
    for (uint32_t off = 0x40; off + 4 <= richEnd; off += 4) {
        uint32_t v = (uint32_t)data_[off] | ((uint32_t)data_[off + 1] << 8) |
                     ((uint32_t)data_[off + 2] << 16) | ((uint32_t)data_[off + 3] << 24);
        if ((v ^ mask) == 0x536E6144) { // "DanS"
            dans = off + 16; // DanS + 16 bayt sürüm/checksum
            break;
        }
    }
    if (dans == 0) return;

    for (uint32_t off = dans; off + 8 <= richEnd; off += 8) {
        uint32_t id = ((uint32_t)data_[off] | ((uint32_t)data_[off + 1] << 8) |
                       ((uint32_t)data_[off + 2] << 16) | ((uint32_t)data_[off + 3] << 24)) ^
                      mask;
        uint32_t cnt = ((uint32_t)data_[off + 4] | ((uint32_t)data_[off + 5] << 8) |
                        ((uint32_t)data_[off + 6] << 16) | ((uint32_t)data_[off + 7] << 24)) ^
                       mask;
        uint16_t prod = (uint16_t)(id >> 16);
        if (prod == 0 || cnt == 0 || cnt > 100000) continue;
        richIds_.push_back(prod);
    }
}

// RVA -> dosya ofseti (bölüm tablosu ham dosyadan taranır; bu hem RVA hem
// dosya-ofseti tabanlı hata ayıklama dizinleri için çalışır)
static bool rvaToOffsetIn(const std::vector<uint8_t> &data, uint32_t rva,
                          uint32_t &fileOff) {
    if (data.size() < 0x40) return false;
    uint32_t eLfanew = (uint32_t)data[0x3c] | ((uint32_t)data[0x3d] << 8) |
                       ((uint32_t)data[0x3e] << 16) | ((uint32_t)data[0x3f] << 24);
    if ((size_t)eLfanew + 24 > data.size()) return false;
    const uint8_t *pe = data.data() + eLfanew;
    uint16_t numSections = (uint16_t)(pe[6] | (pe[7] << 8));
    uint16_t optSize = (uint16_t)(pe[20] | (pe[21] << 8));
    const uint8_t *st = pe + 24 + optSize;
    if ((size_t)(st - data.data()) + (size_t)numSections * 40 > data.size()) return false;
    for (uint16_t i = 0; i < numSections; i++) {
        const uint8_t *p = st + (size_t)i * 40;
        auto rd32 = [&](size_t o) {
            return (uint32_t)p[o] | ((uint32_t)p[o + 1] << 8) |
                   ((uint32_t)p[o + 2] << 16) | ((uint32_t)p[o + 3] << 24);
        };
        uint32_t va = rd32(12), vsize = rd32(8), rawSize = rd32(16), rawPtr = rd32(20);
        uint32_t span = vsize ? vsize : rawSize;
        if (rva >= va && rva < va + std::max(span, rawSize)) {
            uint32_t delta = rva - va;
            if (delta < rawSize) {
                fileOff = rawPtr + delta;
                return true;
            }
            return false;
        }
    }
    // başlık bölgesi (SizeOfHeaders altı) RVA==dosya ofseti
    if (rva < 0x1000) {
        fileOff = rva;
        return true;
    }
    return false;
}

bool PeFile::rvaToOffset(uint32_t rva, uint32_t &fileOff) const {
    return rvaToOffsetIn(data_, rva, fileOff);
}

std::string PeFile::sectionOfRva(uint32_t rva) const {
    for (const SectionHdr &s : sections_) {
        uint32_t span = s.virtualSize ? s.virtualSize : s.sizeOfRawData;
        if (rva >= s.virtualAddress && rva < s.virtualAddress + span) return s.name;
    }
    return "?";
}

// ---------------------------------------------------------------------------
// Exports
// ---------------------------------------------------------------------------
bool PeFile::readExports(std::vector<ExportEntry> &out, std::string *err) const {
    out.clear();
    if (!valid_) {
        if (err) *err = "geçerli PE değil";
        return false;
    }
    uint32_t dirRva = dirRva_[0], dirSize = dirSize_[0];
    if (dirRva == 0 || dirSize < 40) return true; // export yok

    uint32_t off = 0;
    if (!rvaToOffset(dirRva, off) || (size_t)off + 40 > data_.size()) {
        if (err) *err = "export dizini erişilemiyor";
        return false;
    }
    const uint8_t *d = data_.data() + off;
    auto rd32 = [&](size_t o) {
        size_t abs = off + o;
        if (abs + 4 > data_.size()) return 0u;
        return (uint32_t)d[o] | ((uint32_t)d[o + 1] << 8) | ((uint32_t)d[o + 2] << 16) |
               ((uint32_t)d[o + 3] << 24);
    };
    uint32_t ordinalBase = rd32(16);
    uint32_t addrTableRva = rd32(28);
    uint32_t namePtrRva = rd32(32);
    uint32_t ordinalTableRva = rd32(36);

    uint32_t nNames = rd32(24);
    uint32_t nFuncs = rd32(20);

    auto readCstrAtRva = [&](uint32_t rva, std::string &s) {
        uint32_t o = 0;
        if (rva == 0 || !rvaToOffset(rva, o) || o >= data_.size()) return false;
        s.assign((const char *)data_.data() + o,
                 strnlen((const char *)data_.data() + o, data_.size() - o));
        return true;
    };

    out.reserve(nFuncs ? nFuncs : nNames);
    for (uint32_t i = 0; i < nFuncs; i++) {
        ExportEntry e;
        e.ordinal = ordinalBase + i;
        uint32_t fnRva = 0;
        uint32_t ao = 0;
        if (addrTableRva && rvaToOffset(addrTableRva + i * 4, ao) && ao + 4 <= data_.size())
            fnRva = (uint32_t)data_[ao] | ((uint32_t)data_[ao + 1] << 8) |
                    ((uint32_t)data_[ao + 2] << 16) | ((uint32_t)data_[ao + 3] << 24);
        e.rva = fnRva;
        // iletici mi? (RVA export dizini içine düşüyor)
        if (fnRva >= dirRva && fnRva < dirRva + dirSize) readCstrAtRva(fnRva, e.forwarder);
        out.push_back(std::move(e));
    }
    for (uint32_t i = 0; i < nNames; i++) {
        uint32_t no = 0;
        if (!rvaToOffset(namePtrRva + i * 4, no) || no + 4 > data_.size()) continue;
        uint32_t nameRva = (uint32_t)data_[no] | ((uint32_t)data_[no + 1] << 8) |
                           ((uint32_t)data_[no + 2] << 16) | ((uint32_t)data_[no + 3] << 24);
        uint32_t oo = 0;
        if (!rvaToOffset(ordinalTableRva + i * 2, oo) || oo + 2 > data_.size()) continue;
        uint32_t ordIdx = (uint32_t)data_[oo] | ((uint32_t)data_[oo + 1] << 8);
        if (ordIdx >= out.size()) continue;
        readCstrAtRva(nameRva, out[ordIdx].name);
    }
    return true;
}

// ---------------------------------------------------------------------------
// Imports
// ---------------------------------------------------------------------------
bool PeFile::readImports(std::vector<ImportEntry> &out, std::string *err) const {
    out.clear();
    if (!valid_) {
        if (err) *err = "geçerli PE değil";
        return false;
    }
    uint32_t dirRva = dirRva_[1];
    if (dirRva == 0) return true;
    (void)dirSize_[1];

    auto readCstrAtRva = [&](uint32_t rva, std::string &s) {
        uint32_t o = 0;
        if (rva == 0 || !rvaToOffset(rva, o) || o >= data_.size()) return false;
        s.assign((const char *)data_.data() + o,
                 strnlen((const char *)data_.data() + o, data_.size() - o));
        return true;
    };
    auto readU32AtRva = [&](uint32_t rva, uint32_t &v) {
        uint32_t o = 0;
        if (rva == 0 || !rvaToOffset(rva, o) || o + 4 > data_.size()) return false;
        v = (uint32_t)data_[o] | ((uint32_t)data_[o + 1] << 8) |
            ((uint32_t)data_[o + 2] << 16) | ((uint32_t)data_[o + 3] << 24);
        return true;
    };

    for (uint32_t descIdx = 0;; descIdx++) {
        uint32_t descOff = 0;
        if (!rvaToOffset(dirRva + descIdx * 20, descOff) ||
            (size_t)descOff + 20 > data_.size())
            break;
        const uint8_t *desc = data_.data() + descOff;
        auto rd32 = [&](size_t o) {
            return (uint32_t)desc[o] | ((uint32_t)desc[o + 1] << 8) |
                   ((uint32_t)desc[o + 2] << 16) | ((uint32_t)desc[o + 3] << 24);
        };
        uint32_t iltRva = rd32(0), ts = rd32(4), fwd = rd32(8), nameRva = rd32(12),
                 iatRva = rd32(16);
        (void)ts;
        (void)fwd;
        if (iltRva == 0 && iatRva == 0 && nameRva == 0) break; // sonlandırıcı
        if (nameRva == 0) break;

        std::string dll;
        readCstrAtRva(nameRva, dll);
        uint32_t thunkRva = iltRva ? iltRva : iatRva;
        for (uint32_t t = 0;; t++) {
            uint64_t th = 0;
            uint32_t lo = 0;
            if (!readU32AtRva(thunkRva + t * 8, lo)) break;
            uint32_t hi = 0;
            readU32AtRva(thunkRva + t * 8 + 4, hi); // PE32+ üst baytlar (ordinal bit)
            th = ((uint64_t)hi << 32) | lo;
            if (th == 0) break; // sonlandırıcı
            ImportEntry e;
            e.dll = dll;
            if (is64() ? (th & 0x8000000000000000ull) : (th & 0x80000000u)) {
                e.ordinal = (uint16_t)(th & 0xFFFF);
            } else {
                readCstrAtRva((uint32_t)(th & 0x7FFFFFFF) + 2, e.name);
            }
            e.iatRva = iatRva ? iatRva + t * 8 : 0;
            if (e.name.empty() && e.ordinal == 0) continue;
            out.push_back(std::move(e));
        }
    }
    return true;
}

// ---------------------------------------------------------------------------
// PDB keşfi
// ---------------------------------------------------------------------------
bool peFindCvDebug(const std::string &pePath, CvDebugInfo &out, std::string *err) {
    PeFile pe;
    if (!pe.open(pePath, err)) return false;
    out = pe.cvDebug();
    return out.found;
}

std::string locatePdbFor(const std::string &pePath, const std::string &explicitPdb,
                         bool verify, std::string *note, std::string *err) {
    *note = "";
    *err = "";

    PeFile pe;
    if (!pe.open(pePath, err)) return std::string();

    std::string dir = dirName(pePath);
    std::string pdbBasename;

    // adaylar (öncelik sırasıyla)
    std::vector<std::string> candidates;
    if (!explicitPdb.empty()) candidates.push_back(explicitPdb);

    if (pe.cvDebug().found && pe.cvDebug().isRsds) {
        std::string cvPath = pe.cvDebug().pdbPath;
        std::string cvBase = baseName(cvPath);
        if (!cvBase.empty()) {
            candidates.push_back(joinPath(dir, cvBase));
            // sembol sunucusu düzeni
            candidates.push_back(joinPath(dir, cvBase + "/" +
                                                    guidAgeSymbolPath(pe.cvDebug().guid,
                                                                      pe.cvDebug().age) +
                                                    "/" + cvBase));
            // _NT_SYMBOL_PATH ortam değişkeni (';' ile ayrılmış dizinler;
            // srvmaskeli yollar *talimat* dizinlerini gösterir)
            const char *ntSymPath = std::getenv("_NT_SYMBOL_PATH");
            if (ntSymPath) {
                std::string sp(ntSymPath);
                size_t pos = 0;
                while (pos <= sp.size()) {
                    size_t semi = sp.find(';', pos);
                    std::string comp = sp.substr(pos, semi == std::string::npos
                                                          ? std::string::npos
                                                          : semi - pos);
                    if (!comp.empty() && comp.find('*') == std::string::npos &&
                        comp.find("http") != 0) {
                        candidates.push_back(joinPath(comp, cvBase));
                        candidates.push_back(joinPath(comp, cvBase + "/" +
                                                        guidAgeSymbolPath(pe.cvDebug().guid,
                                                                          pe.cvDebug().age) +
                                                        "/" + cvBase));
                    }
                    if (semi == std::string::npos) break;
                    pos = semi + 1;
                }
            }
        }
    }
    // klasik: exe.pdb
    pdbBasename = replaceExt(baseName(pePath), ".pdb");
    candidates.push_back(joinPath(dir, pdbBasename));
    if (!explicitPdb.empty() && explicitPdb != candidates[0])
        candidates.push_back(explicitPdb);

    for (const std::string &cand : candidates) {
        if (cand.empty() || !fileExists(cand)) continue;
        if (verify && pe.cvDebug().found && pe.cvDebug().isRsds) {
            // GUID + yaş doğrulaması
            PdbFile pdb;
            std::string perr;
            if (pdb.open(cand, &perr)) {
                if (std::memcmp(pdb.guid(), pe.cvDebug().guid, 16) == 0 &&
                    pdb.age() == pe.cvDebug().age) {
                    *note = "PDB doğrulandı (GUID+yaş eşleşti): " + cand;
                    return cand;
                }
                *note = "UYARI: GUID/yaş uyuşmadı, yine de kullanılıyor: " + cand;
                return cand;
            }
            *note = "UYARI: aday PDB açılamadı (" + perr + "): " + cand;
            continue;
        }
        return cand;
    }

    *err = "PDB bulunamadı. Denenenler:";
    for (auto &c : candidates) *err += "\n  - " + c;
    if (!pe.cvDebug().found)
        *err += "\n(PE hata ayıklama dizininde CodeView kaydı yok — sembolsüz derlenmiş olabilir)";
    else if (!pe.cvDebug().isRsds)
        *err += "\n(NB10 eski biçimi; PDB70 gerekli)";
    return std::string();
}

} // namespace pdbscope
