// ============================================================================
//  PDBScope — pdb.cpp
//  Yerel PDB ayrıştırma: MSF -> bilgi akışı -> DBI -> semboller.
//
//  Biçim referansları: microsoft/microsoft-pdb (cvinfo.h, gsi.h, dbi.h) ve
//  LLVM llvm-pdbutil (DebugInfo/PDB/Native) — bu dosya onların belgelediği
//  ikili düzenin bağımsız uygulamasıdır.
// ============================================================================
#include "pdb.h"

#include <algorithm>
#include <cstring>
#include <unordered_map>
#include <unordered_set>

#include "cvconst.h"
#include "types.h"
#include "util.h"

namespace pdbscope {

using cv::SymType;

const char *symKindName(SymKind k) {
    switch (k) {
    case SymKind::Function: return "FUNC";
    case SymKind::Public: return "PUB";
    case SymKind::Thunk: return "Thunk";
    case SymKind::Trampoline: return "TRAMP";
    case SymKind::Data: return "DATA";
    case SymKind::Label: return "LABEL";
    case SymKind::Inline: return "INLINE";
    }
    return "?";
}

const char *machineName(uint16_t m) {
    switch (m) {
    case 0x014c: return "i386 (x86)";
    case 0x8664: return "amd64 (x64)";
    case 0x01c0: return "ARM";
    case 0x01c4: return "ARMNT (Thumb-2)";
    case 0xaa64: return "ARM64";
    case 0x5064: return "RISCV64";
    case 0x6264: return "LOONGARCH64";
    case 0x01f0: return "POWERPC";
    case 0x0166: return "R4000 (MIPS)";
    case 0x0000: return "bilinmiyor";
    default: return "diğer";
    }
}

// ---------------------------------------------------------------------------
// open
// ---------------------------------------------------------------------------
bool PdbFile::open(const std::string &path, std::string *err) {
    path_ = path;
    if (!msf_.open(path, err)) return false;
    if (!parseInfoStream(err)) return false;
    if (!parseDbiStream(err)) return false;
    parseStringTable(nullptr); // başarısızlık ölümcül değil

    // Bölüm başlıkları: güncel (dbg[5]) ve orijinal (dbg[10])
    parseSectionHdrStream(dbi_.dbgStreams[5], sections_);
    parseSectionHdrStream(dbi_.dbgStreams[10], sectionsOrig_);
    parseOmapStream(dbi_.dbgStreams[4], omapFrom_); // OmapFromSrc: kaynak -> yeni
    parseOmapStream(dbi_.dbgStreams[3], omapTo_);   // OmapToSrc:   yeni -> kaynak

    parseTpiStream(2, tpi_);
    parseTpiStream(4, ipi_);
    parseFpoStreams();
    return true;
}

// ---------------------------------------------------------------------------
// FPO akışları (dbg[0] eski 16 bayt, dbg[9] yeni 32 bayt FRAMEDATA)
// ---------------------------------------------------------------------------
void PdbFile::parseFpoStreams() {
    fpo_.clear();

    // Eski FPO (x86): {u32 ulOffStart, u32 cbProcSize, u32 cdwLocals,
    // u16 cdwParams, u16 bitler{prolog:8, regs:3, seh:1, bp:1, rsv:1, frame:2}}
    if (dbi_.dbgStreams[0] != 0xFFFF && dbi_.dbgStreams[0] < msf_.streamCount()) {
        std::vector<uint8_t> buf;
        if (msf_.materialize(dbi_.dbgStreams[0], buf, nullptr) && buf.size() >= 16) {
            size_t n = buf.size() / 16;
            for (size_t i = 0; i < n; i++) {
                const uint8_t *p = buf.data() + i * 16;
                auto rd32 = [&](size_t o) {
                    return (uint32_t)p[o] | ((uint32_t)p[o + 1] << 8) |
                           ((uint32_t)p[o + 2] << 16) | ((uint32_t)p[o + 3] << 24);
                };
                uint16_t bits = (uint16_t)(p[14] | (p[15] << 8));
                FpoEntry e;
                e.origRva = rd32(0);
                e.size = rd32(4);
                e.localsBytes = rd32(8) * 4; // dword sayısı -> bayt
                e.paramsBytes = (uint32_t)(p[12] | (p[13] << 8)) * 4;
                e.prologBytes = bits & 0xFF;
                e.savedRegs = (bits >> 8) & 0x7;
                e.hasSEH = ((bits >> 11) & 1) != 0;
                e.usesBP = ((bits >> 12) & 1) != 0;
                e.frameType = (bits >> 14) & 0x3;
                e.isNew = false;
                if (e.size > 0 && e.size < 0x800000) fpo_.push_back(e);
            }
        }
    }

    // Yeni FPO (FRAMEDATA): {u32 rva, u32 cbBlock, u32 cbLocals, u32 cbParams,
    // u32 cbStkMax, u32 frameFuncOfset, u16 cbProlog, u16 cbSavedRegs,
    // u32 bitler{seh:1, eh:1, funcStart:1, rsv:29}}
    if (dbi_.dbgStreams[9] != 0xFFFF && dbi_.dbgStreams[9] < msf_.streamCount()) {
        std::vector<uint8_t> buf;
        if (msf_.materialize(dbi_.dbgStreams[9], buf, nullptr) && buf.size() >= 32) {
            size_t n = buf.size() / 32;
            for (size_t i = 0; i < n; i++) {
                const uint8_t *p = buf.data() + i * 32;
                auto rd32 = [&](size_t o) {
                    return (uint32_t)p[o] | ((uint32_t)p[o + 1] << 8) |
                           ((uint32_t)p[o + 2] << 16) | ((uint32_t)p[o + 3] << 24);
                };
                uint32_t flags = rd32(28);
                FpoEntry e;
                e.origRva = rd32(0);
                e.size = rd32(1 * 4);
                e.localsBytes = rd32(2 * 4);
                e.paramsBytes = rd32(3 * 4);
                e.prologBytes = (uint16_t)(p[24] | (p[25] << 8));
                e.savedRegs = (uint16_t)(p[26] | (p[27] << 8));
                e.hasSEH = (flags & 0x1) != 0;
                e.hasEH = (flags & 0x2) != 0;
                e.isFuncStart = (flags & 0x4) != 0;
                e.frameType = cv::CV_FRAME_NONFPO;
                e.isNew = true;
                if (e.size > 0 && e.size < 0x800000) fpo_.push_back(e);
            }
        }
    }

    std::sort(fpo_.begin(), fpo_.end(),
              [](const FpoEntry &a, const FpoEntry &b) { return a.origRva < b.origRva; });
    // çakışan eski/yeni kayıtlar: aynı başlangıçlıysa yenisini tut
    std::vector<FpoEntry> uniq;
    uniq.reserve(fpo_.size());
    for (FpoEntry &e : fpo_) {
        if (!uniq.empty() && uniq.back().origRva == e.origRva) {
            if (e.isNew) uniq.back() = e; // yeni bilgi daha zengin
            continue;
        }
        uniq.push_back(e);
    }
    fpo_.swap(uniq);
    remapFpoEntries();
}

void PdbFile::remapFpoEntries() {
    if (!hasOmap()) {
        for (FpoEntry &e : fpo_) e.rva = e.origRva;
        return;
    }
    for (FpoEntry &e : fpo_) e.rva = omapRemap(omapFrom_, e.origRva);
}

const FpoEntry *PdbFile::fpoFor(uint32_t rva) const {
    if (fpo_.empty()) return nullptr;
    // NOT: sorgulanan rva OMAP SONRASI; girişler origRva'ya göre sıralı.
    // OMAP yoksa aynı şey. OMAP varsa aramayı rva alanından yap.
    size_t lo = 0, hi = fpo_.size();
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        if (fpo_[mid].rva <= rva) lo = mid + 1;
        else hi = mid;
    }
    if (lo == 0) return nullptr;
    const FpoEntry &e = fpo_[lo - 1];
    if (rva < e.rva + e.size) return &e; // kapsam içinde
    return nullptr;
}

// ---------------------------------------------------------------------------
// TPI/IPI tip depoları (ilk kullanımda yüklenir)
// ---------------------------------------------------------------------------
const TypeStore &PdbFile::tpiStore() const {
    ensureTypes();
    return *tpiStore_;
}

const TypeStore &PdbFile::ipiStore() const {
    ensureTypes();
    return *ipiStore_;
}

void PdbFile::ensureTypes() const {
    if (typesLoaded_) return;
    typesLoaded_ = true;
    tpiStore_.reset(new TypeStore());
    ipiStore_.reset(new TypeStore());
    tpiStore_->load(msf_, 2, false, nullptr);
    ipiStore_->load(msf_, 4, true, nullptr);
    // ID kayıtlarının `type` alanları TPI'ye işaret eder
    ipiStore_->setSibling(tpiStore_.get());
}

std::string PdbFile::idNameOf(uint32_t idIndex) const {
    if (idIndex == 0) return std::string();
    ensureTypes();
    return ipiStore_->idName(idIndex);
}

// ---------------------------------------------------------------------------
// S_COMPILE3 derleyici kayıtları
// ---------------------------------------------------------------------------
bool PdbFile::collectCompilers(std::vector<CompilerInfo> &out) const {
    out.clear();
    for (const ModuleInfo &mi : modules_) {
        if (mi.stream == 0xFFFF || mi.stream >= msf_.streamCount() || mi.symBytes == 0)
            continue;
        std::vector<uint8_t> buf;
        if (!msf_.materialize(mi.stream, buf, nullptr)) continue;
        size_t recLen = std::min<size_t>(buf.size(), mi.symBytes);
        if (recLen < 8) continue;
        const uint8_t *rec = buf.data();
        if (recLen >= 4) {
            uint32_t sig = (uint32_t)rec[0] | ((uint32_t)rec[1] << 8) |
                           ((uint32_t)rec[2] << 16) | ((uint32_t)rec[3] << 24);
            if (sig == 4) {
                rec += 4;
                recLen -= 4;
            }
        }
        // kayıtları tara; S_COMPILE3 (0x113C) ve S_COMPILE2 (0x1116)
        size_t pos = 0;
        while (pos + 4 <= recLen) {
            uint16_t len = (uint16_t)(rec[pos] | (rec[pos + 1] << 8));
            uint16_t typ = (uint16_t)(rec[pos + 2] | (rec[pos + 3] << 8));
            if (len < 2 || pos + 2 + (size_t)len > recLen) break;
            if (typ == cv::S_COMPILE3 || typ == cv::S_COMPILE2) {
                const uint8_t *pl = rec + pos + 4;
                size_t plSz = (size_t)len - 2;
                Cursor c(pl, plSz);
                CompilerInfo ci;
                uint32_t flags = 0;
                bool ok = false;
                if (typ == cv::S_COMPILE3) {
                    // {u32 bayraklar, u16 makine, FE/BE sürümleri (8 u16), ad}
                    ok = c.u32(flags) && c.u16(ci.machine) && c.u16(ci.feMajor) &&
                         c.u16(ci.feMinor) && c.u16(ci.feBuild) && c.u16(ci.feQfe) &&
                         c.u16(ci.beMajor) && c.u16(ci.beMinor) && c.u16(ci.beBuild) &&
                         c.u16(ci.beQfe);
                } else {
                    // COMPILESYM2: {u32 bayraklar, u16 makine, 4 FE sürüm u16, ad}
                    ok = c.u32(flags) && c.u16(ci.machine) && c.u16(ci.feMajor) &&
                         c.u16(ci.feMinor) && c.u16(ci.feBuild) && c.u16(ci.feQfe);
                }
                if (ok) {
                    ci.language = flags & 0xFF;
                    ci.gs = (flags & 0x40) != 0;
                    ci.hotpatch = (flags & 0x80) != 0;
                    ci.ltcg = (flags & 0x08) != 0;
                    ci.sdl = (flags & 0x800) != 0;
                    ci.pgo = (flags & 0x1000) != 0;
                    c.cstr(ci.versionStr);
                    ci.found = !ci.versionStr.empty();
                    ci.module = mi.index;
                    if (ci.found) out.push_back(ci);
                }
            }
            size_t adv = 2 + (size_t)len;
            pos += (adv + 3) & ~(size_t)3; // kayıtlar 4 hizalı (imza sonrası)
        }
    }
    // benzersiz derleyici dizeleri (sürüm + makine + BE sürümü anahtarı)
    std::sort(out.begin(), out.end(), [](const CompilerInfo &a, const CompilerInfo &b) {
        if (a.versionStr != b.versionStr) return a.versionStr < b.versionStr;
        if (a.machine != b.machine) return a.machine < b.machine;
        if (a.beMajor != b.beMajor) return a.beMajor < b.beMajor;
        return a.beMinor < b.beMinor;
    });
    out.erase(std::unique(out.begin(), out.end(),
                          [](const CompilerInfo &a, const CompilerInfo &b) {
                              return a.versionStr == b.versionStr &&
                                     a.machine == b.machine && a.beMajor == b.beMajor &&
                                     a.beMinor == b.beMinor && a.beBuild == b.beBuild;
                          }),
              out.end());
    return !out.empty();
}

// ---------------------------------------------------------------------------
// Bilgi akışı (stream 1)
// ---------------------------------------------------------------------------
bool PdbFile::parseInfoStream(std::string *err) {
    auto fail = [&](const std::string &m) {
        if (err) *err = m;
        return false;
    };
    if (msf_.streamCount() < 5) return fail("akış sayısı yetersiz — bozuk PDB");

    std::vector<uint8_t> buf;
    if (!msf_.materialize(1, buf, err)) return fail("bilgi akışı okunamadı");
    if (buf.size() < 28) return fail("bilgi akışı çok küçük");

    Cursor c(buf.data(), buf.size());
    uint32_t ver = 0, sig = 0;
    if (!c.u32(ver) || !c.u32(sig) || !c.u32(age_)) return fail("bilgi akışı başlığı okunamadı");
    const uint8_t *g = nullptr;
    if (!c.bytes(g, 16)) return fail("GUID okunamadı");
    std::memcpy(guid_, g, 16);
    infoVersion_ = ver;
    // Not: Signature alanı VC70+ PDB'larda sabit değildir (LLVM de doğrulamaz);
    // kimlik doğrulaması GUID + yaş ile yapılır.
    if (ver < cv::PdbImplVC70) return fail("bilgi akışı sürümü çok eski (VC6 öncesi PDB?)");

    // --- adlandırılmış akış haritası ---
    uint32_t namesSize = 0;
    if (!c.u32(namesSize)) return fail("adlandırılmış akış haritası okunamadı");
    std::string namesBuf;
    {
        const uint8_t *nb = nullptr;
        if (!c.bytes(nb, namesSize)) return fail("ad arabelleği okunamadı");
        namesBuf.assign((const char *)nb, namesSize);
    }

    // PDB hash tablosu: {u32 boyut, u32 kapasite, sparse present, sparse deleted, girişler}
    auto readSparse = [&](std::vector<uint64_t> &wordsOut) -> bool {
        uint32_t numWords = 0;
        if (!c.u32(numWords)) return false;
        if ((size_t)numWords * 32 > c.remaining() + 16) return false;
        wordsOut.reserve(numWords);
        for (uint32_t w = 0; w < numWords; w++) {
            uint32_t word = 0;
            if (!c.u32(word)) return false;
            wordsOut.push_back(word);
        }
        return true;
    };

    uint32_t htSize = 0, htCap = 0;
    if (!c.u32(htSize) || !c.u32(htCap)) return fail("ad haritası hash başlığı okunamadı");
    if (htCap == 0 || htCap > 0x100000 || htSize > htCap)
        return fail("ad haritası hash boyutları geçersiz");

    std::vector<uint64_t> present, deleted;
    if (!readSparse(present)) return fail("present bit vektörü okunamadı");
    if (!readSparse(deleted)) return fail("deleted bit vektörü okunamadı");

    uint32_t seen = 0;
    for (uint32_t w : present) {
        for (uint32_t b = 0; b < 32 && seen < htSize; b++) {
            if (!(w & (1u << b))) continue;
            seen++;
            uint32_t nameOff = 0, streamIdx = 0;
            if (!c.u32(nameOff) || !c.u32(streamIdx)) return fail("hash girişi okunamadı");
            if (nameOff >= namesBuf.size()) continue;
            std::string name(namesBuf.c_str() + nameOff);
            if (streamIdx < msf_.streamCount()) namedStreams_[name] = streamIdx;
        }
    }
    if (seen != htSize) return fail("hash tablosu boyut uyumsuz");

    // kuyruk: niMac (yok sayılır) + özellik imzaları
    c.skip(4);
    while (c.remaining() >= 4) {
        uint32_t s = 0;
        if (!c.u32(s)) break;
        switch (s) {
        case 20091201u: // VC110
        case 20140508u: // VC140
            features_ |= 0x1; break; // ID akışı içerir
        case 0x4D544F4Eu: features_ |= 0x4; break; // tip birleştirme yok
        case 0x494E494Du: features_ |= 0x2; break; // /Zi minimal debug
        default: break;
        }
    }
    return true;
}

// ---------------------------------------------------------------------------
// /names dizge tablosu
// ---------------------------------------------------------------------------
bool PdbFile::parseStringTable(std::string *err) {
    auto it = namedStreams_.find("/names");
    if (it == namedStreams_.end()) return true; // yoksa sorun değil
    std::vector<uint8_t> buf;
    if (!msf_.materialize(it->second, buf, nullptr)) return false;
    if (buf.size() < 12) return false;
    Cursor c(buf.data(), buf.size());
    uint32_t sig = 0, hashVer = 0, byteSize = 0;
    if (!c.u32(sig) || !c.u32(hashVer) || !c.u32(byteSize)) return false;
    if (sig != 0xEFFEEFFEu || byteSize > buf.size()) {
        if (err) *err = "/names tablosu bozuk";
        return false;
    }
    const uint8_t *nb = nullptr;
    if (!c.bytes(nb, byteSize)) return false;
    namesBuf_.assign(nb, nb + byteSize);
    return true;
}

const std::string &PdbFile::ecName(uint32_t ni) const {
    static const std::string empty;
    static thread_local std::string tmp;
    tmp.clear();
    if (ni == 0 || ni >= namesBuf_.size()) return empty;
    tmp.assign((const char *)namesBuf_.data() + ni);
    return tmp;
}

// ---------------------------------------------------------------------------
// DBI akışı (stream 3)
// ---------------------------------------------------------------------------
bool PdbFile::parseDbiStream(std::string *err) {
    auto fail = [&](const std::string &m) {
        if (err) *err = m;
        return false;
    };

    std::vector<uint8_t> buf;
    if (!msf_.materialize(3, buf, err)) return fail("DBI akışı okunamadı");
    if (buf.size() < 64) return fail("DBI akışı çok küçük");

    Cursor c(buf.data(), buf.size());
    int32_t sig = 0;
    uint32_t ver = 0;
    if (!c.i32(sig) || !c.u32(ver) || !c.u32(dbi_.age))
        return fail("DBI başlığı okunamadı");
    if (sig != -1) return fail("DBI imzası geçersiz");
    if (ver < cv::DbiV70) return fail("DBI sürümü çok eski (VC6 öncesi desteklenmiyor)");
    dbi_.version = ver;

    uint16_t pdbDllRbld = 0;
    int32_t modiSize = 0, secconSize = 0, secmapSize = 0, filinfoSize = 0, tsSize = 0;
    uint32_t mfcIdx = 0;
    int32_t dbghdrSize = 0, ecSize = 0;
    uint32_t reserved = 0;

    if (!c.u16(dbi_.gsiStream) || !c.u16(dbi_.buildNumber) || !c.u16(dbi_.publicStream) ||
        !c.u16(dbi_.pdbDllVersion) || !c.u16(dbi_.symrecStream) || !c.u16(pdbDllRbld) ||
        !c.i32(modiSize) || !c.i32(secconSize) || !c.i32(secmapSize) ||
        !c.i32(filinfoSize) || !c.i32(tsSize) || !c.u32(mfcIdx) || !c.i32(dbghdrSize) ||
        !c.i32(ecSize) || !c.u16(dbi_.flags) || !c.u16(dbi_.machine) || !c.u32(reserved))
        return fail("DBI başlık alanları okunamadı");

    if (modiSize < 0 || (size_t)modiSize > c.remaining())
        return fail("modül alt akışı boyutu geçersiz");

    // --- modül tanımlayıcıları (MODI) ---
    const uint8_t *modi = nullptr;
    if (!c.bytes(modi, (size_t)modiSize)) return fail("modül alt akışı okunamadı");
    Cursor m(modi, (size_t)modiSize);
    int32_t idx = 0;
    while (m.remaining() >= 64) {
        ModuleInfo mi;
        mi.index = idx++;
        uint32_t opened = 0;
        uint16_t pad = 0, scPad = 0, flags = 0, numFiles = 0, pad2 = 0, scImod = 0;
        uint32_t scChars = 0, scDataCrc = 0, scRelocCrc = 0, fileNameOffs = 0,
                 srcFileNameNI = 0, pdbFilePathNI = 0;
        int32_t scOff = 0, scSize = 0;

        // MODI başlığı: u32 mod, SectionContrib(28), u16 flags, u16 stream,
        // u32 symBytes, u32 c11Bytes, u32 c13Bytes, u16 numFiles, u16 pad,
        // u32 fileNameOffs, u32 srcFileNameNI, u32 pdbFilePathNI
        // SectionContrib(28): u16 isect, pad2, i32 off, i32 size, u32 chars,
        //                     u16 imod, pad2, u32 dataCrc, u32 relocCrc
        if (!m.u32(opened) || !m.u16(mi.scSect) || !m.u16(scPad) || !m.i32(scOff) ||
            !m.i32(scSize) || !m.u32(scChars) || !m.u16(scImod) || !m.u16(pad) ||
            !m.u32(scDataCrc) || !m.u32(scRelocCrc) || !m.u16(flags) ||
            !m.u16(mi.stream) || !m.u32(mi.symBytes) || !m.u32(mi.c11Bytes) ||
            !m.u32(mi.c13Bytes) || !m.u16(numFiles) || !m.u16(pad2) ||
            !m.u32(fileNameOffs) || !m.u32(srcFileNameNI) || !m.u32(pdbFilePathNI))
            return fail("modül tanımlayıcısı okunamadı");
        mi.scOff = (uint32_t)scOff;
        mi.scSize = (uint32_t)scSize;
        mi.numFiles = numFiles;
        if (!m.cstr(mi.moduleName) || !m.cstr(mi.objName))
            return fail("modül adları okunamadı");
        mi.hasSymbols = (mi.stream != 0xFFFF && mi.symBytes > 0);
        modules_.push_back(std::move(mi));

        // 4 bayt hizalama
        size_t adv = (m.pos() + 3) & ~(size_t)3;
        m.seek(std::min(adv, m.size()));
    }

    // --- ara alt akışları atla (bölüm katkısı, bölüm haritası, dosya bilgisi,
    //     tip sunucusu, EC) ---
    if (!c.skip((size_t)secconSize + (size_t)secmapSize + (size_t)filinfoSize +
                (size_t)tsSize + (size_t)ecSize))
        return fail("DBI alt akış sınırları geçersiz");

    // --- dbg başlığı: u16[11] {FPO,Exception,Fixup,OmapToSrc,OmapFromSrc,
    //     SectionHdr,TokenRidMap,Xdata,Pdata,NewFPO,SectionHdrOrig} ---
    size_t n = (size_t)dbghdrSize / 2;
    if (n > 11) n = 11;
    for (size_t i = 0; i < n; i++)
        if (!c.u16(dbi_.dbgStreams[i])) return fail("dbg başlığı okunamadı");
    return true;
}

// ---------------------------------------------------------------------------
// Bölüm başlıkları / OMAP / TPI
// ---------------------------------------------------------------------------
bool PdbFile::parseSectionHdrStream(uint16_t idx, std::vector<SectionHdr> &out) {
    out.clear();
    if (idx == 0xFFFF || idx >= msf_.streamCount()) return false;
    std::vector<uint8_t> buf;
    if (!msf_.materialize(idx, buf, nullptr)) return false;
    size_t n = buf.size() / 40;
    if (n == 0 || n > 96) return false; // PE üst sınırı
    out.resize(n);
    for (size_t i = 0; i < n; i++) {
        const uint8_t *p = buf.data() + i * 40;
        SectionHdr &s = out[i];
        std::memcpy(s.name, p, 8);
        s.name[8] = 0;
        auto rd32 = [&](size_t o) {
            return (uint32_t)p[o] | ((uint32_t)p[o + 1] << 8) |
                   ((uint32_t)p[o + 2] << 16) | ((uint32_t)p[o + 3] << 24);
        };
        s.virtualSize = rd32(8);
        s.virtualAddress = rd32(12);
        s.sizeOfRawData = rd32(16);
        s.characteristics = rd32(36);
    }
    return true;
}

bool PdbFile::parseOmapStream(uint16_t idx, std::vector<OmapEntry> &out) {
    out.clear();
    if (idx == 0xFFFF || idx >= msf_.streamCount()) return false;
    std::vector<uint8_t> buf;
    if (!msf_.materialize(idx, buf, nullptr)) return false;
    size_t n = buf.size() / 8;
    if (n == 0) return false;
    out.resize(n);
    for (size_t i = 0; i < n; i++) {
        const uint8_t *p = buf.data() + i * 8;
        out[i].from = (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) |
                      ((uint32_t)p[3] << 24);
        out[i].to = (uint32_t)p[4] | ((uint32_t)p[5] << 8) | ((uint32_t)p[6] << 16) |
                    ((uint32_t)p[7] << 24);
    }
    std::sort(out.begin(), out.end(),
              [](const OmapEntry &a, const OmapEntry &b) { return a.from < b.from; });
    return true;
}

bool PdbFile::parseTpiStream(uint32_t idx, TpiInfo &out) {
    out = TpiInfo{};
    if (idx >= msf_.streamCount()) return false;
    std::vector<uint8_t> buf;
    if (!msf_.materialize(idx, buf, nullptr)) return false;
    if (buf.size() < 56) return false;
    Cursor c(buf.data(), buf.size());
    uint32_t hdrSize = 0, hashKeySize = 0, numBuckets = 0;
    uint16_t hashAux = 0;
    if (!c.u32(out.version) || !c.u32(hdrSize) || !c.u32(out.firstIndex) ||
        !c.u32(out.lastIndex) || !c.u32(out.recordBytes) || !c.u16(out.hashStream) ||
        !c.u16(hashAux) || !c.u32(hashKeySize) || !c.u32(numBuckets))
        return false;
    return true;
}

// ---------------------------------------------------------------------------
// OMAP çevirisi
// ---------------------------------------------------------------------------
uint32_t PdbFile::omapRemap(const std::vector<OmapEntry> &e, uint32_t addr) {
    if (e.empty()) return addr;
    // ikili arama: from <= addr olan son giriş
    size_t lo = 0, hi = e.size();
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        if (e[mid].from <= addr) lo = mid + 1;
        else hi = mid;
    }
    if (lo == 0) return addr; // ilk girişten önce: aynen geçir
    const OmapEntry &en = e[lo - 1];
    if (en.to == 0) return 0; // bu aralık atılmış
    return en.to + (addr - en.from);
}

bool PdbFile::segOffToRva(uint16_t seg, uint32_t off, uint32_t &origRva,
                          uint32_t &rva) const {
    const std::vector<SectionHdr> *base = &sections_;
    if (hasOmap() && !sectionsOrig_.empty()) base = &sectionsOrig_;
    if (base->empty()) return false;
    if (seg == 0 || (size_t)seg > base->size()) return false;
    const SectionHdr &s = (*base)[seg - 1];
    origRva = s.virtualAddress + off;
    rva = hasOmap() ? omapRemap(omapFrom_, origRva) : origRva;
    return true;
}

// ---------------------------------------------------------------------------
// Sembol kayıtlarını gez
// ---------------------------------------------------------------------------
void PdbFile::walkSymbolRecords(const uint8_t *data, size_t size, int32_t moduleIdx,
                                const CollectOpts &opts, std::vector<Symbol> &out,
                                CollectStats *stats) {
    Cursor c(data, size);
    // kapsam yığını: PROC/THUNK/INLINE/BLOCK açılışı itilir, S_END çeker.
    // Satır içi genişletmelerin üst yordamını bulmak için.
    struct Scope {
        uint16_t seg;
        uint32_t off;
        bool isProc;
    };
    std::vector<Scope> scopes;

    while (c.remaining() >= 4) {
        uint16_t reclen = 0, rectyp = 0;
        size_t recStart = c.pos();
        if (!c.u16(reclen) || !c.u16(rectyp)) break;
        if (reclen < 2 || recStart + 2 + (size_t)reclen > c.size()) {
            if (stats) stats->skippedBad++;
            break;
        }
        size_t payloadStart = c.pos();
        size_t payloadSize = (size_t)reclen - 2;

        switch (rectyp) {
        case cv::S_END:
            if (!scopes.empty()) scopes.pop_back();
            break;
        case cv::S_BLOCK32:
        case cv::S_WITH32:
        case cv::S_SEPCODE: {
            // {u32 pParent,pEnd, u32 len, u32 off, u16 seg, u8 bayrak, ad}
            Cursor p(data + payloadStart, payloadSize);
            uint32_t a = 0, b = 0, len32 = 0, off32 = 0;
            uint16_t seg = 0;
            if (p.u32(a) && p.u32(b) && p.u32(len32) && p.u32(off32) && p.u16(seg))
                scopes.push_back({seg, off32, false});
            break;
        }
        case cv::S_PUB32:
        case cv::S_PUB32_ST: {
            // {u32 pubflags, u32 off, u16 seg, ad}
            Cursor p(data + payloadStart, payloadSize);
            Symbol s;
            uint32_t pubflags = 0;
            if (p.u32(pubflags) && p.u32(s.off) && p.u16(s.seg)) {
                bool ok = (rectyp == cv::S_PUB32) ? p.cstr(s.name) : p.pstr(s.name);
                if (ok && !s.name.empty()) {
                    s.kind = SymKind::Public;
                    s.isCode = (pubflags & cv::cvpsfCode) != 0;
                    s.isFunction = (pubflags & cv::cvpsfFunction) != 0;
                    s.module = moduleIdx;
                    out.push_back(std::move(s));
                }
            }
            break;
        }
        case cv::S_GDATA32:
        case cv::S_LDATA32:
        case cv::S_GDATA32_ST:
        case cv::S_LDATA32_ST: {
            if (!opts.includeData) break;
            // {u32 tipIndeksi, u32 off, u16 seg, ad}
            Cursor p(data + payloadStart, payloadSize);
            Symbol s;
            if (p.u32(s.typeIndex) && p.u32(s.off) && p.u16(s.seg)) {
                bool ok = (rectyp == cv::S_GDATA32 || rectyp == cv::S_LDATA32)
                              ? p.cstr(s.name)
                              : p.pstr(s.name);
                if (ok && !s.name.empty()) {
                    s.kind = SymKind::Data;
                    s.module = moduleIdx;
                    out.push_back(std::move(s));
                }
            }
            break;
        }
        case cv::S_GPROC32:
        case cv::S_LPROC32:
        case cv::S_GPROC32_ID:
        case cv::S_LPROC32_ID: {
            // {u32 pParent,pEnd,pNext,len,dbgStart,dbgEnd, u32 tip, u32 off,
            //  u16 seg, u8 flags, ad} — _ID varyantlarında tip alanı IPI kimliğidir
            Cursor p(data + payloadStart, payloadSize);
            Symbol s;
            s.typeIdIsId = (rectyp == cv::S_GPROC32_ID || rectyp == cv::S_LPROC32_ID);
            uint32_t parent = 0, endp = 0, next = 0, dbgStart = 0, dbgEnd = 0;
            if (p.u32(parent) && p.u32(endp) && p.u32(next) && p.u32(s.size) &&
                p.u32(dbgStart) && p.u32(dbgEnd) && p.u32(s.typeIndex) &&
                p.u32(s.off) && p.u16(s.seg) && p.skip(1)) {
                if (p.cstr(s.name) && !s.name.empty()) {
                    s.kind = SymKind::Function;
                    s.isCode = true;
                    s.isFunction = true;
                    s.module = moduleIdx;
                    scopes.push_back({s.seg, s.off, true});
                    out.push_back(std::move(s));
                }
            }
            break;
        }
        case cv::S_GPROC32_ST:
        case cv::S_LPROC32_ST: {
            // eski: {..., off u32, seg u16, tip u16, flags u8, önekli ad}
            Cursor p(data + payloadStart, payloadSize);
            Symbol s;
            uint32_t parent = 0, endp = 0, next = 0, dbgStart = 0, dbgEnd = 0;
            uint16_t type16 = 0;
            if (p.u32(parent) && p.u32(endp) && p.u32(next) && p.u32(s.size) &&
                p.u32(dbgStart) && p.u32(dbgEnd) && p.u32(s.off) && p.u16(s.seg) &&
                p.u16(type16) && p.skip(1)) {
                s.typeIndex = type16;
                if (p.pstr(s.name) && !s.name.empty()) {
                    s.kind = SymKind::Function;
                    s.isCode = true;
                    s.isFunction = true;
                    s.module = moduleIdx;
                    scopes.push_back({s.seg, s.off, true});
                    out.push_back(std::move(s));
                }
            }
            break;
        }
        case cv::S_INLINESITE:
        case cv::S_INLINESITE2: {
            if (!opts.includeInline) break;
            // {u32 pParent, u32 pEnd, u32 inlineeKimliği, [u32 invocations],
            //  ikili ek açıklamalar...}
            Cursor p(data + payloadStart, payloadSize);
            Symbol s;
            uint32_t parent = 0, endp = 0, inlinee = 0;
            if (p.u32(parent) && p.u32(endp) && p.u32(inlinee)) {
                s.inlineeId = inlinee;
                // tekilleştirme anahtarını benzersizleştir (ad sonra IPI'den gelir)
                s.name = "inline:" + std::to_string(inlinee) + "@" +
                         std::to_string(out.size());
                s.kind = SymKind::Inline;
                s.isCode = true;
                s.isFunction = true;
                s.module = moduleIdx;
                // en yakın kapsayan PROC
                for (auto it = scopes.rbegin(); it != scopes.rend(); ++it) {
                    if (it->isProc) {
                        s.seg = it->seg;
                        s.off = it->off;
                        break;
                    }
                }
                out.push_back(std::move(s));
            }
            scopes.push_back({0, 0, false}); // kapsam olarak say (S_END uyumu)
            break;
        }
        case cv::S_THUNK32: {
            if (!opts.includeThunks) break;
            // {u32 pParent,pEnd,pNext, u32 off, u16 seg, u16 len, u8 ord, ad}
            Cursor p(data + payloadStart, payloadSize);
            Symbol s;
            uint32_t parent = 0, endp = 0, next = 0;
            uint16_t len16 = 0;
            uint8_t ord = 0;
            if (p.u32(parent) && p.u32(endp) && p.u32(next) && p.u32(s.off) &&
                p.u16(s.seg) && p.u16(len16) && p.u8(ord)) {
                s.size = len16;
                std::string nm;
                if (p.cstr(nm)) {
                    s.name = nm.empty() ? "thunk" : nm;
                    s.kind = SymKind::Thunk;
                    s.isCode = true;
                    s.module = moduleIdx;
                    scopes.push_back({s.seg, s.off, true});
                    out.push_back(std::move(s));
                }
            }
            break;
        }
        case cv::S_TRAMPOLINE: {
            if (!opts.includeThunks) break;
            // {u16 tip, u16 boyut, u32 offThunk, u32 offTarget,
            //  u16 sectThunk, u16 sectTarget}
            Cursor p(data + payloadStart, payloadSize);
            Symbol s;
            uint16_t ttype = 0, cbThunk = 0, sectTarget = 0;
            uint32_t offTarget = 0;
            if (p.u16(ttype) && p.u16(cbThunk) && p.u32(s.off) && p.u32(offTarget) &&
                p.u16(s.seg) && p.u16(sectTarget)) {
                s.size = cbThunk;
                s.name = ttype == cv::trampBranchIsland ? "trampoline_branch_island"
                                                        : "trampoline_incremental";
                s.kind = SymKind::Trampoline;
                s.isCode = true;
                s.module = moduleIdx;
                out.push_back(std::move(s));
            }
            break;
        }
        case cv::S_LABEL32: {
            if (!opts.includeLabels) break;
            // {u32 off, u16 seg, u8 flags, ad}
            Cursor p(data + payloadStart, payloadSize);
            Symbol s;
            uint8_t flags = 0;
            if (p.u32(s.off) && p.u16(s.seg) && p.u8(flags)) {
                if (p.cstr(s.name) && !s.name.empty()) {
                    s.kind = SymKind::Label;
                    s.isCode = true;
                    s.module = moduleIdx;
                    out.push_back(std::move(s));
                }
            }
            break;
        }
        default:
            break; // S_END, S_OBJNAME, S_BLOCK32, S_REGREL32, ... liste dışı
        }

        // sonraki kayıt: reclen, reclen alanının kendisi hariç uzunluk
        c.seek(recStart + 2 + (size_t)reclen);
    }
}

// ---------------------------------------------------------------------------
// Tüm sembol kaynaklarını topla + tekilleştir + RVA hesapla
// ---------------------------------------------------------------------------
bool PdbFile::collectSymbols(const CollectOpts &opts, std::vector<Symbol> &out,
                             CollectStats *stats, std::string *err) {
    (void)err;
    out.clear();

    // 1) Genel sembol kayıt akışı (publics + globals kayıtları burada yatar)
    if (opts.walkGlobals && dbi_.symrecStream != 0xFFFF &&
        dbi_.symrecStream < msf_.streamCount()) {
        std::vector<uint8_t> buf;
        if (msf_.materialize(dbi_.symrecStream, buf, nullptr)) {
            size_t before = out.size();
            walkSymbolRecords(buf.data(), buf.size(), -1, opts, out, stats);
            if (stats) stats->globalRecords = (uint32_t)(out.size() - before);
        }
    }

    // 2) Modül akışları (yordamlar, thunk'lar, modül-yerel veriler)
    if (opts.walkModules) {
        for (const ModuleInfo &mi : modules_) {
            if (mi.stream == 0xFFFF || mi.stream >= msf_.streamCount() || mi.symBytes == 0)
                continue;
            std::vector<uint8_t> buf;
            if (!msf_.materialize(mi.stream, buf, nullptr)) continue;

            // Modül akışı düzeni: [u32 imza (=4, C13)][sembol kayıtları]
            // [C11 satır bilgisi][C13 altbölümleri][global referanslar].
            // Sembol kayıtları imzadan sonra başlar ve symBytes sınırına dek sürer.
            const uint8_t *rec = buf.data();
            size_t recLen = std::min<size_t>(buf.size(), mi.symBytes);
            if (recLen >= 4) {
                uint32_t sig = (uint32_t)rec[0] | ((uint32_t)rec[1] << 8) |
                               ((uint32_t)rec[2] << 16) | ((uint32_t)rec[3] << 24);
                if (sig == 4) { // standart C13 modül akışı
                    rec += 4;
                    recLen -= 4;
                }
                // imza 4 değilse kayıtlar doğrudan 0'dan başlıyor olabilir (eski biçim)
            }

            size_t before = out.size();
            walkSymbolRecords(rec, recLen, mi.index, opts, out, stats);
            if (stats) stats->moduleRecords += (uint32_t)(out.size() - before);

            for (size_t i = before; i < out.size(); i++)
                if (out[i].module == mi.index && (size_t)mi.index < modules_.size())
                    modules_[mi.index].symbolCount++;
        }
    }

    // 3) RVA hesabı ve bölüm eşlemesi
    uint32_t noSect = 0;
    for (Symbol &s : out) {
        uint32_t origRva = 0, rva = 0;
        if (segOffToRva(s.seg, s.off, origRva, rva)) {
            s.origRva = origRva;
            s.rva = rva;
            if (s.kind == SymKind::Inline) s.parentRva = rva; // üst yordam RVA'sı
        } else {
            noSect++;
        }
    }
    if (stats) stats->noSection = noSect;

    // 4) Tekilleştirme (hash tabanlı, O(n)):
    //    a) birebir aynı (seg,off,ad) — FUNC kaydı tercih edilir
    //    b) PUB + aynı adresli aynı adlı FUNC -> PUB düşür
    if (opts.merge) {
        std::unordered_map<std::string, size_t> firstByKey; // key -> index
        firstByKey.reserve(out.size() * 2);
        std::vector<Symbol> uniq;
        uniq.reserve(out.size());

        auto keyOf = [](const Symbol &s) {
            char buf[64];
            std::snprintf(buf, sizeof buf, "%u:%u:", (unsigned)s.seg, (unsigned)s.off);
            return std::string(buf) + s.name;
        };

        for (Symbol &s : out) {
            std::string key = keyOf(s);
            auto it = firstByKey.find(key);
            if (it == firstByKey.end()) {
                firstByKey.emplace(std::move(key), uniq.size());
                uniq.push_back(std::move(s));
            } else {
                Symbol &keep = uniq[it->second];
                // FUNC kaydı bilgi açısından zengin (boyut + tip): yer değiştir
                if (s.kind == SymKind::Function && keep.kind != SymKind::Function)
                    keep = std::move(s);
                if (stats) stats->mergedAway++;
            }
        }

        // (b): (seg,off) -> FUNC adları
        std::unordered_map<uint64_t, std::unordered_set<std::string>> funcsAt;
        funcsAt.reserve(uniq.size());
        for (const Symbol &s : uniq) {
            if (s.kind != SymKind::Function) continue;
            funcsAt[((uint64_t)s.seg << 32) | s.off].insert(s.name);
        }
        std::vector<Symbol> merged;
        merged.reserve(uniq.size());
        for (Symbol &s : uniq) {
            if (s.kind == SymKind::Public) {
                auto it = funcsAt.find(((uint64_t)s.seg << 32) | s.off);
                if (it != funcsAt.end() && it->second.count(s.name)) {
                    if (stats) stats->mergedAway++;
                    continue;
                }
            }
            merged.push_back(std::move(s));
        }
        out.swap(merged);
    }
    return true;
}

} // namespace pdbscope
