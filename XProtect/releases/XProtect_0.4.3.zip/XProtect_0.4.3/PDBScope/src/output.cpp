// ============================================================================
//  PDBScope — output.cpp
// ============================================================================
#include "output.h"

#include <algorithm>
#include <regex>
#include <sstream>

#include "demangle.h"
#include "util.h"

namespace pdbscope {

// ---------------------------------------------------------------------------
// Filtreleme + sıralama
// ---------------------------------------------------------------------------
std::vector<Symbol> prepareSymbols(const std::vector<Symbol> &symbols,
                                   const OutOpts &opts) {
    std::vector<Symbol> out;
    out.reserve(symbols.size());

    std::regex re;
    bool hasRegex = false;
    if (!opts.regex.empty()) {
        try {
            re.assign(opts.regex, std::regex::icase | std::regex::optimize);
            hasRegex = true;
        } catch (const std::regex_error &) {
            // geçersiz regex: alt dizge filtresine düş
        }
    }

    for (const Symbol &s : symbols) {
        if (!opts.filter.empty() || hasRegex) {
            std::string dm = opts.demangle ? demangle(s.name) : std::string();
            bool ok = true;
            if (!opts.filter.empty())
                ok = ok && (containsCI(s.name, opts.filter) || containsCI(dm, opts.filter));
            if (hasRegex)
                ok = ok && (std::regex_search(s.name, re) ||
                            (!dm.empty() && std::regex_search(dm, re)));
            if (!ok) continue;
        }
        out.push_back(s);
    }

    if (opts.sortBy == "name") {
        std::sort(out.begin(), out.end(), [](const Symbol &a, const Symbol &b) {
            std::string la = toLower(a.name), lb = toLower(b.name);
            if (la != lb) return la < lb;
            return a.rva < b.rva;
        });
    } else if (opts.sortBy == "size") {
        std::sort(out.begin(), out.end(), [](const Symbol &a, const Symbol &b) {
            if (a.size != b.size) return a.size > b.size;
            return a.rva < b.rva;
        });
    } else { // rva
        std::sort(out.begin(), out.end(), [](const Symbol &a, const Symbol &b) {
            if (a.hasRva() != b.hasRva()) return a.hasRva(); // RVA'sız en sonda
            if (a.rva != b.rva) return a.rva < b.rva;
            return a.name < b.name;
        });
    }

    if (opts.limit > 0 && out.size() > (size_t)opts.limit)
        out.resize((size_t)opts.limit);
    return out;
}

// ---------------------------------------------------------------------------
// En yakın sembol
// ---------------------------------------------------------------------------
NearestResult findNearest(const std::vector<Symbol> &sorted, uint32_t rva) {
    NearestResult r;
    if (sorted.empty()) return r;
    size_t lo = 0, hi = sorted.size();
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        if (sorted[mid].rva <= rva) lo = mid + 1;
        else hi = mid;
    }
    r.found = true;
    if (lo == 0) {
        // hedef ilk sembolden önce
        r.index = 0;
        r.delta = (int64_t)rva - (int64_t)sorted[0].rva;
        r.exact = r.delta == 0;
        return r;
    }
    size_t i = lo - 1;
    r.index = i;
    r.delta = (int64_t)rva - (int64_t)sorted[i].rva;
    r.exact = (r.delta == 0) || (sorted[i].size > 0 && (uint64_t)r.delta < sorted[i].size);
    // tam içeride mi (boyut biliniyorsa)
    return r;
}

// ---------------------------------------------------------------------------
// Tablo
// ---------------------------------------------------------------------------
static std::string fmtSize(uint32_t sz) {
    if (sz == 0) return "-";
    return hexU32(sz, 1);
}

static std::string sectionNameOf(const OutOpts &opts, uint32_t rva) {
    if (!opts.sections) return "-";
    for (const SectionHdr &s : *opts.sections) {
        uint32_t span = s.virtualSize ? s.virtualSize : s.sizeOfRawData;
        if (rva >= s.virtualAddress && rva < s.virtualAddress + span) return s.name;
    }
    return "-";
}

static std::string renderTable(const std::vector<Symbol> &syms,
                               const std::vector<std::string> &moduleNames,
                               const OutOpts &opts) {
    struct Row {
        std::string rva, va, sec, size, type, name, dm, mod, sig, line;
    };
    std::vector<Row> rows;
    rows.reserve(syms.size());
    bool anyDm = false, anyMod = moduleNames.size() > 1;
    bool anySig = (bool)opts.signatureOf, anyLine = (bool)opts.lineOf;

    // tabloda modül adı: yalnız dosya adı (tam yol CSV/JSON'da)
    auto shortMod = [](const std::string &m) {
        size_t p = m.find_last_of("/\\");
        return p == std::string::npos ? m : m.substr(p + 1);
    };

    for (const Symbol &s : syms) {
        Row r;
        if (s.hasRva()) r.rva = "0x" + hexU32(s.rva, 1);
        else r.rva = "-" + std::to_string(s.seg) + ":" + hexU32(s.off, 8);
        if (opts.imageBaseKnown && s.hasRva())
            r.va = "0x" + hexU64(opts.imageBase + s.rva, 1);
        else r.va = "-";
        r.sec = s.hasRva() ? sectionNameOf(opts, s.rva) : "-";
        r.size = fmtSize(s.size);
        r.type = symKindName(s.kind);
        if (s.kind == SymKind::Public && s.isFunction) r.type = "PUB*"; // fonksiyon public'i
        r.dm = opts.demangle ? demangle(s.name) : std::string();
        if (!r.dm.empty() && r.dm != s.name) anyDm = true;
        r.name = s.name;
        if (anyMod && s.module >= 0 && (size_t)s.module < moduleNames.size())
            r.mod = shortMod(moduleNames[s.module]);
        else
            r.mod = "-";
        if (anySig) {
            std::string v = opts.signatureOf(s);
            r.sig = v.empty() ? "-" : v;
            if (r.sig == "-") anySig = anySig; // sütun hep görünür (bayrak)
        }
        if (anyLine) {
            std::string v = opts.lineOf(s);
            size_t cut = v.size() > 46 ? v.size() - 46 : 0; // tablo genişliği için
            r.line = v.empty() ? "-" : (cut ? "..." : "") + v.substr(cut);
        }
        rows.push_back(std::move(r));
    }

    auto w = [&](std::string Row::*f, const char *title) {
        size_t wd = std::strlen(title);
        for (const Row &r : rows) wd = std::max(wd, (r.*f).size());
        return wd;
    };
    // sütun genişlikleri
    size_t wRva = w(&Row::rva, "RVA"), wVa = w(&Row::va, "VA");
    size_t wSec = w(&Row::sec, "Bölüm"), wSize = w(&Row::size, "Boyut");
    size_t wType = w(&Row::type, "Tip");
    size_t wMod = anyMod ? w(&Row::mod, "Modül") : 0;
    size_t wSig = opts.signatureOf ? w(&Row::sig, "İmza") : 0;
    size_t wLine = opts.lineOf ? w(&Row::line, "Kaynak") : 0;

    std::ostringstream o;
    if (!opts.noHeader) {
        auto pad = [](const std::string &s, size_t w2, bool left) {
            std::string r2 = s;
            while (r2.size() < w2) r2 += left ? ' ' : ' ';
            return left ? r2 : r2; // hep sola hizalı doldur
        };
        std::string h;
        h += pad("RVA", wRva, false) + "  ";
        h += pad("VA", wVa, false) + "  ";
        h += pad("Bölüm", wSec, false) + "  ";
        h += pad("Boyut", wSize, false) + "  ";
        h += pad("Tip", wType, false) + "  ";
        if (anyMod) h += pad("Modül", wMod, false) + "  ";
        if (wSig) h += pad("İmza", wSig, false) + "  ";
        if (wLine) h += pad("Kaynak", wLine, false) + "  ";
        h += opts.showMangled || !anyDm ? std::string("Sembol") : "Sembol (çözümlü)";
        o << h << "\n";
        std::string sep(h.size(), '-');
        o << sep << "\n";
    }

    for (const Row &r : rows) {
        o << r.rva;
        for (size_t i = r.rva.size(); i < wRva; i++) o << ' ';
        o << "  " << r.va;
        for (size_t i = r.va.size(); i < wVa; i++) o << ' ';
        o << "  " << r.sec;
        for (size_t i = r.sec.size(); i < wSec; i++) o << ' ';
        o << "  " << r.size;
        for (size_t i = r.size.size(); i < wSize; i++) o << ' ';
        o << "  " << r.type;
        for (size_t i = r.type.size(); i < wType; i++) o << ' ';
        if (anyMod) {
            o << "  " << r.mod;
            for (size_t i = r.mod.size(); i < wMod; i++) o << ' ';
        }
        if (wSig) {
            o << "  " << r.sig;
            for (size_t i = r.sig.size(); i < wSig; i++) o << ' ';
        }
        if (wLine) {
            o << "  " << r.line;
            for (size_t i = r.line.size(); i < wLine; i++) o << ' ';
        }
        o << "  ";
        if (anyDm && !r.dm.empty()) {
            o << r.dm;
            if (opts.showMangled) o << "    [" << r.name << "]";
        } else {
            o << r.name;
        }
        o << "\n";
    }
    return o.str();
}

// ---------------------------------------------------------------------------
// CSV
// ---------------------------------------------------------------------------
static std::string renderCsv(const std::vector<Symbol> &syms,
                             const std::vector<std::string> &moduleNames,
                             const OutOpts &opts) {
    std::ostringstream o;
    if (!opts.noHeader) {
        o << "rva,va,seg,off,orig_rva,size,type,is_code,is_function,module,name,demangled";
        if (opts.signatureOf) o << ",signature";
        if (opts.lineOf) o << ",source_line";
        o << "\n";
    }
    for (const Symbol &s : syms) {
        std::string va = opts.imageBaseKnown && s.hasRva()
                             ? std::to_string(opts.imageBase + s.rva)
                             : "";
        std::string mod = (s.module >= 0 && (size_t)s.module < moduleNames.size())
                              ? moduleNames[s.module]
                              : "";
        std::string dm = opts.demangle ? demangle(s.name) : "";
        o << (s.hasRva() ? std::to_string(s.rva) : "") << ',' << va << ','
          << std::to_string(s.seg) << ',' << std::to_string(s.off) << ','
          << (s.hasRva() ? std::to_string(s.origRva) : "") << ','
          << std::to_string(s.size) << ',' << symKindName(s.kind) << ','
          << (s.isCode ? "1" : "0") << ',' << (s.isFunction ? "1" : "0") << ','
          << csvEscape(mod) << ',' << csvEscape(s.name) << ',' << csvEscape(dm);
        if (opts.signatureOf) o << ',' << csvEscape(opts.signatureOf(s));
        if (opts.lineOf) o << ',' << csvEscape(opts.lineOf(s));
        o << '\n';
    }
    return o.str();
}

// ---------------------------------------------------------------------------
// JSON
// ---------------------------------------------------------------------------
static void jsonSym(std::ostringstream &o, const Symbol &s,
                    const std::vector<std::string> &moduleNames, const OutOpts &opts,
                    bool pretty, int depth) {
    std::string ind = pretty ? std::string((size_t)depth * 2, ' ') : "";
    std::string ind2 = pretty ? std::string((size_t)(depth + 1) * 2, ' ') : "";
    std::string nl = pretty ? "\n" : "";
    std::string sp = pretty ? " " : "";
    std::string mod = (s.module >= 0 && (size_t)s.module < moduleNames.size())
                          ? moduleNames[s.module]
                          : "";
    std::string dm = opts.demangle ? demangle(s.name) : "";

    std::string rva = s.hasRva() ? std::to_string(s.rva) : "null";
    std::string va = opts.imageBaseKnown && s.hasRva()
                         ? std::to_string(opts.imageBase + s.rva)
                         : "null";

    std::vector<std::string> fields;
    fields.push_back(std::string("\"rva\":") + sp + rva);
    fields.push_back(std::string("\"va\":") + sp + va);
    fields.push_back(std::string("\"seg\":") + sp + std::to_string(s.seg));
    fields.push_back(std::string("\"off\":") + sp + std::to_string(s.off));
    fields.push_back(std::string("\"size\":") + sp + std::to_string(s.size));
    fields.push_back(std::string("\"type\":\"") + jsonEscape(symKindName(s.kind)) + "\"");
    fields.push_back(std::string("\"is_code\":") + sp + (s.isCode ? "true" : "false"));
    fields.push_back(std::string("\"is_function\":") + sp +
                     (s.isFunction ? "true" : "false"));
    fields.push_back(std::string("\"module\":\"") + jsonEscape(mod) + "\"");
    fields.push_back(std::string("\"name\":\"") + jsonEscape(s.name) + "\"");
    fields.push_back(std::string("\"demangled\":\"") + jsonEscape(dm.empty() ? s.name : dm) +
                     "\"");
    if (opts.signatureOf) {
        std::string sig = opts.signatureOf(s);
        fields.push_back(std::string("\"signature\":\"") + jsonEscape(sig) + "\"");
    }
    if (opts.lineOf) {
        std::string ln = opts.lineOf(s);
        fields.push_back(std::string("\"source_line\":\"") + jsonEscape(ln) + "\"");
    }

    o << ind << "{" << nl;
    for (size_t i = 0; i < fields.size(); i++) {
        o << ind2 << fields[i];
        if (i + 1 < fields.size()) o << ",";
        o << nl;
    }
    o << ind << "}";
}

static std::string renderJson(const std::vector<Symbol> &syms,
                              const std::string &sourcePath,
                              const std::vector<std::string> &moduleNames,
                              const OutOpts &opts) {
    std::ostringstream o;
    std::string nl = opts.jsonPretty ? "\n" : "";
    std::string sp = opts.jsonPretty ? " " : "";
    o << "{" << nl;
    o << (opts.jsonPretty ? "  " : "") << "\"source\":" << sp << "\"" << jsonEscape(sourcePath)
      << "\"," << nl;
    o << (opts.jsonPretty ? "  " : "") << "\"image_base\":" << sp
      << (opts.imageBaseKnown ? std::to_string(opts.imageBase) : "null") << "," << nl;
    o << (opts.jsonPretty ? "  " : "") << "\"symbol_count\":" << sp << syms.size() << ","
      << nl;
    o << (opts.jsonPretty ? "  " : "") << "\"symbols\":" << sp << "[" << nl;
    for (size_t i = 0; i < syms.size(); i++) {
        jsonSym(o, syms[i], moduleNames, opts, opts.jsonPretty,
                opts.jsonPretty ? 2 : 0);
        if (i + 1 < syms.size()) o << ",";
        o << nl;
    }
    o << (opts.jsonPretty ? "  " : "") << "]" << nl << "}" << nl;
    return o.str();
}

// ---------------------------------------------------------------------------
// MAP çıktısı (MSVC link /MAP benzeri)
// ---------------------------------------------------------------------------
static std::string renderMap(const std::vector<Symbol> &syms,
                             const std::vector<std::string> &moduleNames,
                             const OutOpts &opts) {
    std::ostringstream o;
    o << "\n PDBScope tarafından üretilen MAP\n\n";
    if (opts.imageBaseKnown)
        o << " Preferred load address is " << hexU64(opts.imageBase, 8) << "h\n\n";
    if (opts.sections && !opts.sections->empty()) {
        o << " Start         Length     Name                   Class\n\n";
        for (size_t i = 0; i < opts.sections->size(); i++) {
            const SectionHdr &s = (*opts.sections)[i];
            uint32_t len = s.virtualSize ? s.virtualSize : s.sizeOfRawData;
            o << " " << hexU32((uint32_t)(i + 1), 4) << ":"
              << hexU32(s.virtualAddress, 8) << " " << hexU32(len, 8) << "H "
              << s.name << "\n";
        }
        o << "\n";
    }
    o << " Address         Publics by Value              Rva+Base       Modül\n\n";
    for (const Symbol &s : syms) {
        std::string mod = (s.module >= 0 && (size_t)s.module < moduleNames.size())
                              ? moduleNames[s.module]
                              : "global";
        uint64_t va = (opts.imageBaseKnown && s.hasRva()) ? opts.imageBase + s.rva : 0;
        o << " " << hexU32(s.seg, 4) << ":" << hexU32(s.off, 8) << "  "
          << s.name;
        // hizalama
        size_t pad = s.name.size() < 32 ? 32 - s.name.size() : 1;
        o << std::string(pad, ' ') << hexU32((uint32_t)va, 8) << " "
          << (s.isCode ? "f " : "  ") << mod << "\n";
    }
    o << "\n";
    return o.str();
}

// ---------------------------------------------------------------------------
std::string renderSymbols(const std::vector<Symbol> &symbols,
                          const std::string &sourcePath,
                          const std::vector<std::string> &moduleNames,
                          const OutOpts &opts, size_t *shownCount) {
    if (opts.moduleFilter.empty() && opts.format != "csv" && opts.format != "json") {
        // moduleNames boşsa dert yok
    }
    // modül filtresi
    std::vector<Symbol> filtered;
    const std::vector<Symbol> *use = &symbols;
    if (!opts.moduleFilter.empty()) {
        for (const Symbol &s : symbols) {
            if (s.module < 0 || (size_t)s.module >= moduleNames.size()) continue;
            if (containsCI(moduleNames[s.module], opts.moduleFilter))
                filtered.push_back(s);
        }
        use = &filtered;
    }

    if (shownCount) *shownCount = use->size();
    if (opts.format == "csv") return renderCsv(*use, moduleNames, opts);
    if (opts.format == "json")
        return renderJson(*use, sourcePath, moduleNames, opts);
    if (opts.format == "map") return renderMap(*use, moduleNames, opts);
    return renderTable(*use, moduleNames, opts);
}

} // namespace pdbscope
