// ============================================================================
//  PDBScope — demangle.h
//  MSVC ad çözücü (demangler): Windows'ta dbghelp.dll çalışma anında yüklenir
//  (bağımlılık yok, sistem DLL'i), diğer platformlarda ham ad döner.
// ============================================================================
#pragma once

#include <string>

namespace pdbscope {

// Bir kez başlat: dbghelp.dll'i yüklemeyi dener.
void demangleInit();

// "?..." biçimli MSVC mangled adı okunabilir imzaya çevirir;
// başarısızsa boş dizge döner.
std::string demangle(const std::string &mangled);

// Ad çözümlemesi yapılabiliyor mu? (Windows + dbghelp yüklendi mi?)
bool demangleAvailable();

} // namespace pdbscope
