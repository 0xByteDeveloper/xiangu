// ============================================================================
//  PDBScope — types.cpp
//  TPI/IPI tip çözümleme. Yapı düzenleri microsoft-pdb cvinfo.h'dan:
//    LF_MODIFIER  {u16 yaprak, u32 tip, u16 öznitelik}
//    LF_POINTER   {u16, u32 temelTip, u32 öznitelik(bitler), [pm sınıfı...]}
//    LF_PROCEDURE {u16, u32 dönüşTipi, u8 çağrı, u8 öznitelik, u16 paramSay,
//                  u32 arglist}
//    LF_MFUNCTION {u16, u32 dönüşTipi, u32 sınıfTipi, u32 thisTipi, u8 çağrı,
//                  u8 öznitelik, u16 paramSay, u32 arglist, i32 thisAyarla}
//    LF_ARGLIST   {u16, u32 sayı, u32 tipler[]}
//    LF_ARRAY     {u16, u32 elemanTipi, u32 indeksTipi, sayısal boyut, ad?}
//    LF_CLASS..   {u16, u16 elemanSay, u16 özellik, u32 alanList, u32 türeyen,
//                  u32 vshape, sayısal boyut, null sonlu ad}
//    LF_ENUM      {u16, u16 sayı, u16 özellik, u32 temelTip, u32 alanList, ad}
//    LF_FUNC_ID   {u16, u32 kapsamKimliği, u32 fonkTipi, ad}
//    LF_MFUNC_ID  {u16, u32 üstSınıfTipi, u32 fonkTipi, ad}
//  TPI adları null sonludur; kayıtlar 4 bayta hizalanır (0xF0 pad).
// ============================================================================
#include "types.h"

#include <cstring>

#include "cvconst.h"
#include "util.h"

namespace pdbscope {

using cv::LeafType;

// ---------------------------------------------------------------------------
// Çağrı konvansiyonu adları
// ---------------------------------------------------------------------------
const char *callConvName(uint8_t cc) {
    switch (cc) {
    case cv::CV_CALL_NEAR_C: return "__cdecl";
    case cv::CV_CALL_FAR_C: return "__cdecl (far)";
    case cv::CV_CALL_NEAR_PASCAL: return "__pascal";
    case cv::CV_CALL_FAR_PASCAL: return "__pascal (far)";
    case cv::CV_CALL_NEAR_FAST: return "__fastcall";
    case cv::CV_CALL_FAR_FAST: return "__fastcall (far)";
    case cv::CV_CALL_NEAR_STD: return "__stdcall";
    case cv::CV_CALL_FAR_STD: return "__stdcall (far)";
    case cv::CV_CALL_NEAR_SYS: return "__syscall";
    case cv::CV_CALL_FAR_SYS: return "__syscall (far)";
    case cv::CV_CALL_THISCALL: return "__thiscall";
    case cv::CV_CALL_MIPSCALL: return "__mipscall";
    case cv::CV_CALL_GENERIC: return "__generic";
    case cv::CV_CALL_ALPHACALL: return "__alphacall";
    case cv::CV_CALL_PPCCALL: return "__ppccall";
    case cv::CV_CALL_SHCALL: return "__shcall";
    case cv::CV_CALL_ARMCALL: return "__armcall";
    case cv::CV_CALL_CLRCALL: return "__clrcall";
    case cv::CV_CALL_INLINE: return "__inline";
    case cv::CV_CALL_NEAR_VECTOR: return "__vectorcall";
    default: return "";
    }
}

// ---------------------------------------------------------------------------
// Sayısal yaprak (struct dizi boyutu vb.)
// ---------------------------------------------------------------------------
bool TypeStore::readNumeric(Cursor &c, uint64_t &value) {
    uint16_t v16 = 0;
    if (!c.u16(v16)) return false;
    if (v16 < 0x8000) { // kısa değer doğrudan kodlanır
        value = v16;
        return true;
    }
    switch (v16) {
    case cv::LF_CHAR_: {
        uint8_t v;
        if (!c.u8(v)) return false;
        value = v;
        return true;
    }
    case cv::LF_SHORT_: {
        uint16_t v;
        if (!c.u16(v)) return false;
        value = (int16_t)v;
        return true;
    }
    case cv::LF_USHORT_: {
        uint16_t v;
        if (!c.u16(v)) return false;
        value = v;
        return true;
    }
    case cv::LF_LONG_: {
        uint32_t v;
        if (!c.u32(v)) return false;
        value = v;
        return true;
    }
    case cv::LF_ULONG_: {
        uint32_t v;
        if (!c.u32(v)) return false;
        value = v;
        return true;
    }
    case cv::LF_QUADWORD_:
    case cv::LF_UQUADWORD_: {
        uint64_t v;
        if (!c.u64(v)) return false;
        value = v;
        return true;
    }
    default:
        value = 0;
        return true; // tanınmayan kodlama: 0 kabul, konum ilerledi
    }
}

// ---------------------------------------------------------------------------
// Yükleme + indeksleme
// ---------------------------------------------------------------------------
bool TypeStore::load(const MsfFile &msf, uint32_t idx, bool isIpi, std::string *err) {
    auto fail = [&](const std::string &m) {
        if (err) *err = m;
        return false;
    };
    if (idx >= msf.streamCount()) return fail("tip akışı yok");
    if (!msf.materialize(idx, buf_, err)) return fail("tip akışı okunamadı");
    if (buf_.size() < 56) return fail("tip akışı çok küçük");

    Cursor c(buf_.data(), buf_.size());
    uint32_t ver = 0, hdrSize = 0, recordBytes = 0;
    uint16_t hashStream = 0, hashAux = 0;
    uint32_t hashKeySize = 0, numBuckets = 0;
    if (!c.u32(ver) || !c.u32(hdrSize) || !c.u32(firstIndex_) || !c.u32(lastIndex_) ||
        !c.u32(recordBytes) || !c.u16(hashStream) || !c.u16(hashAux) ||
        !c.u32(hashKeySize) || !c.u32(numBuckets))
        return fail("tip akışı başlığı okunamadı");

    if (lastIndex_ <= firstIndex_ || recordBytes == 0 || 56 + (uint64_t)recordBytes > buf_.size())
        return fail("tip akışı sınırları geçersiz");

    if (isIpi) {
        idFirst_ = firstIndex_;
        idLast_ = lastIndex_;
    }
    buildIndex(buf_, recordBytes, firstIndex_);
    return !records_.empty();
}

void TypeStore::buildIndex(const std::vector<uint8_t> &buf, uint32_t recordBytes,
                           uint32_t firstIdx) {
    records_.clear();
    records_.reserve(lastIndex_ - firstIndex_);
    size_t pos = 56; // başlık
    size_t end = std::min<size_t>(buf.size(), (size_t)56 + recordBytes);
    uint32_t expected = firstIdx;
    while (pos + 4 <= end) {
        uint16_t len = (uint16_t)(buf[pos] | (buf[pos + 1] << 8));
        uint16_t leaf = (uint16_t)(buf[pos + 2] | (buf[pos + 3] << 8));
        if (len < 2 || pos + 2 + (size_t)len > end) break;
        // tip indeksi firstIndex'ten itibaren kayıt sırasıyla artar
        if (expected < lastIndex_) {
            Rec r;
            r.leaf = leaf;
            r.payload = buf.data() + pos + 4; // yaprak sonrası
            r.payloadSize = (size_t)len - 2;
            records_.push_back(r);
            expected++;
        }
        // uzunluk pad dahil: 2+len toplamı 4'ün katına tamamlanır
        size_t advance = 2 + (size_t)len;
        advance = (advance + 3) & ~(size_t)3;
        pos += advance;
    }
}

const TypeStore::Rec *TypeStore::find(uint32_t idx) const {
    if (idx < firstIndex_ || idx >= firstIndex_ + records_.size()) return nullptr;
    return &records_[idx - firstIndex_];
}

// ---------------------------------------------------------------------------
// Basit (ilkel) tipler — T_* tablosu
// ---------------------------------------------------------------------------
static const char *primitiveName(uint32_t idx) {
    // 0x0100/0x0400/0x0600 sınıfları: temel tipe işaretçi
    uint32_t cls = idx & 0xFF00, base = idx & 0x00FF;
    if (cls != 0 && base != 0) {
        // temel tip adına "*" eklenir; çözümleme typeName içinde yapılır
        return nullptr; // aşağıda ele alınır
    }
    (void)cls;
    switch (base) {
    case 0x00: return "<notype>";
    case 0x03: return "void";
    case 0x08: return "HRESULT";
    case 0x10: return "char";
    case 0x12: return "long";
    case 0x13: return "unsigned long";
    case 0x11: return "short";
    case 0x20: return "unsigned char";
    case 0x21: return "unsigned short";
    case 0x22: return "unsigned long";
    case 0x30: return "bool";
    case 0x31: return "bool16";
    case 0x32: return "bool32";
    case 0x33: return "bool64";
    case 0x40: return "float";
    case 0x41: return "double";
    case 0x42: return "long double";
    case 0x43: return "double (128)";
    case 0x68: return "signed char";
    case 0x69: return "unsigned char";
    case 0x6A: return "signed char";
    case 0x6B: return "unsigned char";
    case 0x70: return "char (r)";
    case 0x71: return "wchar_t";
    case 0x72: return "short";
    case 0x73: return "unsigned short";
    case 0x74: return "int";
    case 0x75: return "unsigned int";
    case 0x76: return "__int64";
    case 0x77: return "unsigned __int64";
    case 0x7A: return "char8_t";
    case 0x7B: return "char16_t";
    case 0x7C: return "char32_t";
    case 0x7E: return "??";
    default: return nullptr;
    }
}

// ---------------------------------------------------------------------------
// Tip adı çözümleme
// ---------------------------------------------------------------------------
std::string TypeStore::typeName(uint32_t idx, int depth) const {
    if (depth > 8) return "T_" + hexU32(idx, 4); // döngü koruması

    // 1) ilkel tipler + ilkel işaretçi sınıfları
    if (idx < 0x1000) {
        uint32_t cls = idx & 0xFF00, base = idx & 0x00FF;
        static const uint32_t ptrClasses[] = {0x0100, 0x0200, 0x0300, 0x0400,
                                              0x0500, 0x0600};
        for (uint32_t pc : ptrClasses) {
            if (cls == pc) {
                const char *b = primitiveName(base);
                if (b) return std::string(b) + " *";
                return "T_" + hexU32(idx, 4);
            }
        }
        const char *p = primitiveName(idx);
        if (p) return p;
        return "T_" + hexU32(idx, 4);
    }

    // 2) ad önbelleği (struct/class adları çok tekrarlanır)
    {
        auto it = nameCache_.find(idx);
        if (it != nameCache_.end()) return it->second;
    }

    const Rec *r = find(idx);
    if (!r) return "T_" + hexU32(idx, 4);
    std::string result;

    Cursor c(r->payload, r->payloadSize);
    switch (r->leaf) {
    case cv::LF_MODIFIER: {
        uint32_t utype = 0;
        uint16_t attr = 0;
        if (c.u32(utype) && c.u16(attr)) {
            result = typeName(utype, depth + 1);
            if (attr & cv::MOD_const) result = "const " + result;
            if (attr & cv::MOD_volatile) result = "volatile " + result;
        }
        break;
    }
    case cv::LF_POINTER: {
        uint32_t utype = 0, attr = 0;
        if (c.u32(utype) && c.u32(attr)) {
            std::string inner = typeName(utype, depth + 1);
            // üye işaretçisi (ptrmode != 0): sınıfı belirt
            uint32_t ptrmode = (attr >> 5) & 0x7;
            if (ptrmode != 0) {
                // pbase: {u32 pmclass, u16 pmenum}
                uint32_t pmclass = 0;
                if (c.u32(pmclass))
                    result = typeName(pmclass, depth + 1) + "::*";
                else result = inner + "::*";
                if (ptrmode == 1) result = typeName(utype, depth + 1) + " " + result;
            } else {
                // işlev işaretçisi: temel tip LF_PROCEDURE olabilir
                const Rec *u = find(utype);
                if (u && u->leaf == cv::LF_PROCEDURE) {
                    FuncSignature fs = signatureOfType(utype, depth + 1);
                    if (fs.valid)
                        result = fs.returnType + " (*)(" +
                                 joinArgs(fs.argTypes) + ")";
                    else result = inner + " *";
                } else {
                    result = inner + " *";
                }
            }
        }
        break;
    }
    case cv::LF_ARRAY: {
        uint32_t elemType = 0, idxType = 0;
        if (c.u32(elemType) && c.u32(idxType)) {
            uint64_t size = 0;
            readNumeric(c, size); // toplam bayt (eleman değil)
            (void)idxType;
            result = typeName(elemType, depth + 1) + "[]";
        }
        break;
    }
    case cv::LF_CLASS:
    case cv::LF_STRUCTURE:
    case cv::LF_INTERFACE: {
        // {u16 elemanSay, u16 özellik, u32 alanList, u32 türeyen, u32 vshape,
        //  sayısal boyut, ad}
        uint16_t count = 0, property = 0;
        uint32_t field = 0, derived = 0, vshape = 0;
        if (c.u16(count) && c.u16(property) && c.u32(field) && c.u32(derived) &&
            c.u32(vshape)) {
            uint64_t sz = 0;
            readNumeric(c, sz);
            std::string nm;
            c.cstr(nm); // null sonlu ad
            result = nm.empty() ? "<anon>" : nm;
        }
        break;
    }
    case cv::LF_UNION: {
        uint16_t count = 0, property = 0;
        uint32_t field = 0;
        if (c.u16(count) && c.u16(property) && c.u32(field)) {
            uint64_t sz = 0;
            readNumeric(c, sz);
            std::string nm;
            c.cstr(nm);
            result = nm.empty() ? "<anon-union>" : nm;
        }
        break;
    }
    case cv::LF_ENUM: {
        uint16_t count = 0, property = 0;
        uint32_t utype = 0, field = 0;
        if (c.u16(count) && c.u16(property) && c.u32(utype) && c.u32(field)) {
            std::string nm;
            c.cstr(nm);
            result = nm.empty() ? "<anon-enum>" : nm;
        }
        break;
    }
    case cv::LF_ALIAS: {
        uint32_t utype = 0;
        if (c.u32(utype)) {
            std::string nm;
            c.cstr(nm);
            result = nm.empty() ? typeName(utype, depth + 1) : nm;
        }
        break;
    }
    case cv::LF_BITFIELD: {
        uint32_t type = 0;
        uint8_t length = 0, pos = 0;
        if (c.u32(type) && c.u8(length) && c.u8(pos))
            result = typeName(type, depth + 1) + ":" + std::to_string(length);
        break;
    }
    case cv::LF_PROCEDURE:
    case cv::LF_MFUNCTION: {
        FuncSignature fs = signatureOfType(idx, depth + 1);
        if (fs.valid)
            result = fs.returnType + " (" + (fs.isMember ? std::string("__thiscall")
                                                          : fs.callingConv) +
                      ")(" + joinArgs(fs.argTypes) + ")";
        break;
    }
    default:
        break;
    }

    if (result.empty()) result = "T_" + hexU32(idx, 4);
    nameCache_[idx] = result;
    return result;
}

std::string TypeStore::joinArgs(const std::vector<std::string> &args) const {
    std::string r;
    for (size_t i = 0; i < args.size(); i++) {
        if (i) r += ", ";
        r += args[i];
    }
    return r.empty() ? "void" : r;
}

// ---------------------------------------------------------------------------
// İmza çözümleme
// ---------------------------------------------------------------------------
FuncSignature TypeStore::signatureOfType(uint32_t idx, int depth) const {
    FuncSignature fs;
    if (depth > 8) return fs;
    const Rec *r = find(idx);
    if (!r) return fs;

    // IPI kimlik kayıtları: ad + temel fonksiyon tipi.
    // DİKKAT: `type` alanı TPI'deki LF_PROCEDURE'a işaret eder (kardeş depo).
    if (r->leaf == cv::LF_FUNC_ID) {
        Cursor c(r->payload, r->payloadSize);
        uint32_t scopeId = 0, type = 0;
        if (c.u32(scopeId) && c.u32(type)) {
            const TypeStore *ts = sibling_ ? sibling_ : this;
            if (ts != this || find(type)) {
                FuncSignature base = ts->signatureOfType(type, depth + 1);
                if (base.valid) fs = base;
            }
        }
        return fs;
    }
    if (r->leaf == cv::LF_MFUNC_ID) {
        Cursor c(r->payload, r->payloadSize);
        uint32_t parentType = 0, type = 0;
        if (c.u32(parentType) && c.u32(type)) {
            const TypeStore *ts = sibling_ ? sibling_ : this;
            // sınıf adı TPI'den; üye fonksiyon tipi de TPI'deki LF_MFUNCTION
            fs.className = ts->typeName(parentType, depth + 1);
            FuncSignature base = ts->signatureOfType(type, depth + 1);
            if (base.valid) {
                fs.returnType = base.returnType;
                fs.callingConv = base.callingConv;
                fs.argTypes = base.argTypes;
                fs.isMember = true;
                fs.valid = true;
            }
        }
        return fs;
    }

    if (r->leaf == cv::LF_PROCEDURE) {
        Cursor c(r->payload, r->payloadSize);
        uint32_t rvtype = 0, arglist = 0;
        uint8_t calltype = 0, funcattr = 0;
        uint16_t parmcount = 0;
        if (!c.u32(rvtype) || !c.u8(calltype) || !c.u8(funcattr) ||
            !c.u16(parmcount) || !c.u32(arglist))
            return fs;
        fs.returnType = typeName(rvtype, depth + 1);
        fs.callingConv = callConvName(calltype);
        const Rec *al = find(arglist);
        if (al && al->leaf == cv::LF_ARGLIST) {
            Cursor ca(al->payload, al->payloadSize);
            uint32_t n = 0;
            if (ca.u32(n)) {
                for (uint32_t i = 0; i < n && i < 128; i++) {
                    uint32_t at = 0;
                    if (!ca.u32(at)) break;
                    // 0x00? T_NOTYPE = "..." (varargs) göstergesi
                    fs.argTypes.push_back(at == 0 ? std::string("...")
                                                  : typeName(at, depth + 1));
                }
            }
        }
        fs.valid = true;
        return fs;
    }

    if (r->leaf == cv::LF_MFUNCTION) {
        Cursor c(r->payload, r->payloadSize);
        uint32_t rvtype = 0, classtype = 0, thistype = 0, arglist = 0;
        uint8_t calltype = 0, funcattr = 0;
        uint16_t parmcount = 0;
        int32_t thisadjust = 0;
        if (!c.u32(rvtype) || !c.u32(classtype) || !c.u32(thistype) || !c.u8(calltype) ||
            !c.u8(funcattr) || !c.u16(parmcount) || !c.u32(arglist) ||
            !c.i32(thisadjust))
            return fs;
        fs.returnType = typeName(rvtype, depth + 1);
        fs.callingConv = callConvName(calltype);
        fs.isMember = true;
        fs.className = typeName(classtype, depth + 1);
        const Rec *al = find(arglist);
        if (al && al->leaf == cv::LF_ARGLIST) {
            Cursor ca(al->payload, al->payloadSize);
            uint32_t n = 0;
            if (ca.u32(n)) {
                for (uint32_t i = 0; i < n && i < 128; i++) {
                    uint32_t at = 0;
                    if (!ca.u32(at)) break;
                    fs.argTypes.push_back(at == 0 ? std::string("...")
                                                  : typeName(at, depth + 1));
                }
            }
        }
        fs.valid = true;
        return fs;
    }
    return fs;
}

// ---------------------------------------------------------------------------
// IPI kimlik adı
// ---------------------------------------------------------------------------
std::string TypeStore::idName(uint32_t idx) const {
    const Rec *r = find(idx);
    if (!r) return std::string();
    if (r->leaf == cv::LF_FUNC_ID || r->leaf == cv::LF_MFUNC_ID) {
        Cursor c(r->payload, r->payloadSize);
        uint32_t a = 0, b = 0;
        if (c.u32(a) && c.u32(b)) {
            std::string nm;
            if (c.cstr(nm)) return nm;
        }
    } else if (r->leaf == cv::LF_STRING_ID) {
        Cursor c(r->payload, r->payloadSize);
        uint32_t id = 0;
        if (c.u32(id)) {
            std::string nm;
            if (c.cstr(nm)) return nm;
        }
    }
    return std::string();
}

// ---------------------------------------------------------------------------
// UDT listesi
// ---------------------------------------------------------------------------
void TypeStore::collectUdts(std::vector<UdtEntry> &out) const {
    uint32_t idx = firstIndex_;
    for (const Rec &r : records_) {
        const char *kind = nullptr;
        switch (r.leaf) {
        case cv::LF_CLASS: kind = "class"; break;
        case cv::LF_STRUCTURE: kind = "struct"; break;
        case cv::LF_UNION: kind = "union"; break;
        case cv::LF_ENUM: kind = "enum"; break;
        case cv::LF_INTERFACE: kind = "interface"; break;
        default: break;
        }
        if (kind) {
            UdtEntry e;
            e.kind = kind;
            e.typeIndex = idx;
            Cursor c(r.payload, r.payloadSize);
            if (r.leaf == cv::LF_ENUM) {
                uint16_t count = 0, prop = 0;
                uint32_t utype = 0, field = 0;
                if (c.u16(count) && c.u16(prop) && c.u32(utype) && c.u32(field)) {
                    e.fwdRef = (prop & 0x80) != 0;
                    c.cstr(e.name);
                }
            } else if (r.leaf == cv::LF_UNION) {
                uint16_t count = 0, prop = 0;
                uint32_t field = 0;
                if (c.u16(count) && c.u16(prop) && c.u32(field)) {
                    e.fwdRef = (prop & 0x80) != 0;
                    uint64_t sz = 0;
                    readNumeric(c, sz);
                    e.size = sz;
                    c.cstr(e.name);
                }
            } else {
                uint16_t count = 0, prop = 0;
                uint32_t field = 0, derived = 0, vshape = 0;
                if (c.u16(count) && c.u16(prop) && c.u32(field) && c.u32(derived) &&
                    c.u32(vshape)) {
                    e.fwdRef = (prop & 0x80) != 0; // fwdref biti
                    uint64_t sz = 0;
                    readNumeric(c, sz);
                    e.size = sz;
                    c.cstr(e.name);
                }
            }
            if (!e.name.empty()) out.push_back(std::move(e));
        }
        idx++;
    }
}

// ---------------------------------------------------------------------------
// İmza dizesi
// ---------------------------------------------------------------------------
std::string FuncSignature::signatureStr(const std::string &funcName, bool withName) const {
    if (!valid) return std::string();
    std::string s = returnType;
    if (!s.empty() && s[s.size() - 1] != '*' && s[s.size() - 1] != '&') s += ' ';
    std::string cc = isMember ? "__thiscall" : callingConv;
    if (!cc.empty()) s += std::string(cc) + ' ';
    if (withName) {
        s += funcName;
        s += "(";
    } else {
        s += "(";
    }
    for (size_t i = 0; i < argTypes.size(); i++) {
        if (i) s += ", ";
        s += argTypes[i];
    }
    if (argTypes.empty()) s += "void";
    s += ")";
    if (isMember && !className.empty() && withName) s += " [üye: " + className + "]";
    return s;
}

} // namespace pdbscope
