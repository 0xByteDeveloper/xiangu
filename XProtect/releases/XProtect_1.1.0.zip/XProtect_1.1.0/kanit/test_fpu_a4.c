// ============================================================
// test_fpu_a4.c — 1.1.0-A4-FPU kabul testi (UniversalObfuscator paritesi)
// Derleme: python3 -m ziglang cc -O2 -target x86_64-windows-gnu
// Davranis: tum FPU testleri gecerse "OK fpu_*" satirlari + exit 42.
// KURAL: C seviyesinde HICBIR float islem YOK — tum x87 dizileri
// volatile inline-asm (derleyici SSE'ye tasiyamaz, sirayi bozamaz).
// Bellek-formlari STATIK globallerde (image-relative; lifter MEMF_DISP).
// ============================================================
#include <stdio.h>
#include <string.h>

// ---- XProtect SDK isaretleri ----
#define XP_SDK_BEG(t) \
    __asm__ volatile(".byte 0xB8, 0xB5, 0xE1, 0x37, 0x9C" ::: "eax", "memory"); \
    __asm__ volatile(".byte 0xB8, " #t ", 0x00, 0x00, 0x00" ::: "eax", "memory")
#define XP_SDK_END() \
    __asm__ volatile(".byte 0xB8, 0x8E, 0x2C, 0x7A, 0x3D" ::: "eax", "memory")

static volatile double d_a = 1.5, d_a14 = 1.4, d_b = 2.25, d_c = 3.7, d_16 = 16.0, d_7 = 7.0, d_2 = 2.0;
static volatile double d_out = 0.0;
static volatile float  f_a = 1.5f, f_b = 2.5f, f_out = 0.0f;
static volatile short  s_in = 100;
static volatile int    i_in = 7, i_10 = 10, i_out = 0;
static volatile long long q_in = 123456789LL, q_out = 0;
static volatile unsigned char tb[16] = {0};
static volatile short cw_saved = 0;
static volatile short cw_down = 0x077F;
static volatile int r = 0;

// T1: fld/fadd/fsub/fmul/fdiv m64 zinciri + fstp — 7*3=21 yolu:
// d_a(1.5) fadd d_b(2.25) -> 3.75; fsub d_a(1.5) -> 2.25; fmul d_2 -> 4.5;
// fld d_7 -> 7/4.5 = 1.555...; aslinda net hedef: tamsayi dogrulanabilir akis.
// Yeniden: fld 7, fmul 3 -> 21 (fimul yolu), fstp i_out.
static int t_mem_arith(void) {
    i_out = 0;
    XP_SDK_BEG(1);
    __asm__ volatile("fldl %0"  :: "m"(d_7));        // fld m64
    __asm__ volatile("fimull %0" :: "m"(i_in));      // fimul m32: 7*7=49
    __asm__ volatile("fadds %0"  :: "m"(f_a));       // fadd m32: +1.5 = 50.5
    __asm__ volatile("fsubl %0"  :: "m"(d_b));       // fsub m64: -2.25 = 48.25
    __asm__ volatile("fistpl %0" : "=m"(i_out));     // fistp m32 -> 48
    XP_SDK_END();
    return (i_out == 48) ? 0 : 1;
}

// T2: fsubr/fdivr yonleri — 2.25 - 1.5 = 0.75; 2.25 / 1.5 = 1.5
static int t_subr_divr(void) {
    XP_SDK_BEG(1);
    __asm__ volatile("fldl %0"   :: "m"(d_b));       // ST0=2.25
    __asm__ volatile("fsubrl %0" :: "m"(d_a));       // fsubr m64: ST0 = 1.5-2.25 = -0.75
    __asm__ volatile("fstpl %0"  : "=m"(d_out));     // d_out = -0.75
    XP_SDK_END();
    // -0.75'in IEEE754 bit deseni: 0xBFE8000000000000
    { volatile unsigned long long bits;
      __builtin_memcpy((void*)&bits, (const void*)&d_out, 8);
      if (bits != 0xBFE8000000000000ULL) return 1; }
    XP_SDK_BEG(1);
    __asm__ volatile("fldl %0"   :: "m"(d_b));       // ST0=2.25
    __asm__ volatile("fdivrl %0" :: "m"(d_a));       // fdivr m64: ST0 = 1.5/2.25
    __asm__ volatile("fistpl %0" : "=m"(i_out));     // 0.666 -> 1
    XP_SDK_END();
    return (i_out == 1) ? 0 : 2;
}

// T3: fsqrt + fldpi sinama: fsqrt(16)=4; fldpi ~3.14 (fistp->3)
static int t_sqrt_pi(void) {
    XP_SDK_BEG(1);
    __asm__ volatile("fldl %0"   :: "m"(d_16));
    __asm__ volatile("fsqrt");
    __asm__ volatile("fistpl %0" : "=m"(i_out));     // 4
    XP_SDK_END();
    if (i_out != 4) return 1;
    XP_SDK_BEG(1);
    __asm__ volatile("fldpi");
    __asm__ volatile("fistpl %0" : "=m"(i_out));     // 3
    XP_SDK_END();
    return (i_out == 3) ? 0 : 2;
}

// T4: fstsw ax + sahf + jcc (klasik FPU karsilastirma akisi) +
//     fcom mem-form: 3.7 vs 2.0 -> 3.7 > 2.0 -> CF=0 -> jnb alinir
static int t_fstsw_branch(void) {
    r = 0;
    XP_SDK_BEG(1);
    __asm__ volatile("fldl %0" :: "m"(d_c));         // ST0=3.7
    __asm__ volatile("fcoml %0" :: "m"(d_2));        // fcom m64: 3.7 vs 2.0
    __asm__ volatile("fwait");
    __asm__ volatile(".byte 0xDF, 0xE0" ::: "eax");       // fstsw ax (status)
    __asm__ volatile("sahf");                        // flags <- AH
    __asm__ volatile("jnb 1f\n\t"
                     "movl $1, %0\n"
                     "1:" : "=m"(r) :: "eax", "cc", "memory");
    __asm__ volatile(".byte 0xDD, 0xD8" ::: "memory");   // fstp st(0) — temizle
    XP_SDK_END();
    return (r == 0) ? 0 : 1;   // 3.7>2.0 -> CF=0 -> jnb ALINIR -> r=0 dogru
}

// T5: fcomi + fcmov — yon dogrulamasi (1.4: fistp->1, 2.25: fistp->2)
// A: ST0=2.25, ST1=1.4: fcomi st(1) -> 2.25>1.4 CF=0 -> fcmovb ALINMAZ -> ST0=2.25
// B: ST0=1.4, ST1=2.25: fcomi st(1) -> 1.4<2.25 CF=1 -> fcmovb ALINIR  -> ST0=2.25
static int t_fcomi_fcmov(void) {
    i_out = 0;
    XP_SDK_BEG(1);
    __asm__ volatile("fldl %0" :: "m"(d_a14));       // ST1=1.4 (yer tutucu)
    __asm__ volatile("fldl %0" :: "m"(d_b));         // ST0=2.25, ST1=1.4
    __asm__ volatile(".byte 0xDB, 0xF1" :: : "cc");     // 2.25 vs 1.5 -> CF=0
    __asm__ volatile(".byte 0xDA, 0xC1" :: : "cc"); // alinmaz -> ST0=2.25
    __asm__ volatile("fistpl %0" : "=m"(i_out));     // 2
    __asm__ volatile("fistpl %0" : "=m"(r));         // 1 (ST1)
    XP_SDK_END();
    if (i_out != 2 || r != 1) return 1;
    i_out = 0;
    XP_SDK_BEG(1);
    __asm__ volatile("fldl %0" :: "m"(d_b));         // ST1=2.25
    __asm__ volatile("fldl %0" :: "m"(d_a14));       // ST0=1.4, ST1=2.25
    __asm__ volatile(".byte 0xDB, 0xF1" :: : "cc");     // 1.4 vs 2.25 -> CF=1
    __asm__ volatile(".byte 0xDA, 0xC1" :: : "cc"); // ALINIR -> ST0=2.25
    __asm__ volatile("fistpl %0" : "=m"(i_out));     // 2
    __asm__ volatile("fistpl %0" : "=m"(r));         // 2 (kalan ST1=2.25)
    XP_SDK_END();
    return (i_out == 2 && r == 2) ? 0 : 2;
}

// T6: reg-form aritmetik — DC C1 (fadd st(1),st): ST1 += ST0
static int t_reg_forms(void) {
    i_out = 0;
    XP_SDK_BEG(1);
    __asm__ volatile("fldl %0"   :: "m"(d_a));       // ST0=1.5
    __asm__ volatile("fldl %0"   :: "m"(d_b));       // ST0=2.25, ST1=1.5
    __asm__ volatile(".byte 0xDC, 0xC1" :: : "cc"); // DC C1: ST1=3.75
    __asm__ volatile(".byte 0xD9, 0xC9");                // ST0=3.75, ST1=2.25
    __asm__ volatile("fistpl %0" : "=m"(i_out));     // 4 (3.75 -> nearest)
    __asm__ volatile("fistpl %0" : "=m"(r));         // 2
    XP_SDK_END();
    return (i_out == 4 && r == 2) ? 0 : 1;
}

// T7: pop-formlar — fmul st(1),st + pop: fld1, fld2, fmulp -> ST0=2
static int t_pop_forms(void) {
    i_out = 0;
    XP_SDK_BEG(1);
    __asm__ volatile("fld1");                        // ST0=1
    __asm__ volatile("fldl %0" :: "m"(d_2));         // ST0=2, ST1=1
    __asm__ volatile(".byte 0xDE, 0xC9" :: : "cc"); // ST1=2, pop -> ST0=2
    __asm__ volatile("fistpl %0" : "=m"(i_out));     // 2
    XP_SDK_END();
    if (i_out != 2) return 1;
    XP_SDK_BEG(1);
    __asm__ volatile("fld1");
    __asm__ volatile("fld1");
    __asm__ volatile(".byte 0xDE, 0xC1");                       // DE C1: ST1=2, pop
    __asm__ volatile("fistpl %0" : "=m"(i_out));     // 2
    XP_SDK_END();
    return (i_out == 2) ? 0 : 2;
}

// T8: fistp/fild tamsayi yuvarlama + fisttp (SSE3 truncasyon)
static int t_int_conv(void) {
    XP_SDK_BEG(1);
    __asm__ volatile("filds %0" :: "m"(s_in));       // fild m16: 100
    __asm__ volatile("fistpq %0" : "=m"(q_out));     // fistp m64: 100
    XP_SDK_END();
    if (q_out != 100) return 1;
    XP_SDK_BEG(1);
    __asm__ volatile("fildll %0" :: "m"(q_in));      // fild m64: 123456789
    __asm__ volatile("fistpl %0" : "=m"(i_out));     // fistp m32
    XP_SDK_END();
    if (i_out != 123456789) return 2;
    // fisttp: truncasyon 3.7 -> 3 (yuvarlama-nearest degil)
    XP_SDK_BEG(1);
    __asm__ volatile("fldl %0"   :: "m"(d_c));       // 3.7
    __asm__ volatile("fisttpl %0" : "=m"(i_out));    // 3
    XP_SDK_END();
    if (i_out != 3) return 3;
    return 0;
}

// T9: fldcw/fstcw kontrol kelimesi — yuvarlama modu degisimi
// default CW=0x037F (nearest): 3.7 -> fistp 4; CW=0x077F (down): 3.7 -> 3
static int t_cw_round(void) {
    XP_SDK_BEG(1);
    __asm__ volatile("fwait");
    __asm__ volatile("fnstcw %0" : "=m"(cw_saved));  // fstcw m16 kaydet
    __asm__ volatile("fldl %0"   :: "m"(d_c));
    __asm__ volatile("fistpl %0" : "=m"(i_out));     // 4 (nearest)
    XP_SDK_END();
    if (i_out != 4) return 1;
    XP_SDK_BEG(1);
    __asm__ volatile("fldcw %0"  :: "m"(cw_down));   // RC=down
    __asm__ volatile("fldl %0"   :: "m"(d_c));
    __asm__ volatile("fistpl %0" : "=m"(r));         // 3 (down)
    __asm__ volatile("fldcw %0"  :: "m"(cw_saved));  // geri yukle
    XP_SDK_END();
    if (r != 3) return 2;
    return 0;
}

// T10: tbyte (m80) fld/fstp + fchs/fabs + fprem/fscale/fyl2x/f2xm1
static int t_tbyte_transc(void) {
    XP_SDK_BEG(1);
    __asm__ volatile("fldl %0"   :: "m"(d_b));       // 2.5
    __asm__ volatile("fstpt %0"  : "=m"(tb));        // fstp m80
    __asm__ volatile("fldt %0"   :: "m"(tb));        // fld m80
    __asm__ volatile("fchs");                        // -2.5
    __asm__ volatile("fabs");                        // 2.5
    __asm__ volatile("fistpl %0" : "=m"(i_out));     // 2
    XP_SDK_END();
    if (i_out != 2) return 1;
    XP_SDK_BEG(1);
    __asm__ volatile("fldl %0" :: "m"(d_2));         // ST0=2
    __asm__ volatile("fldl %0" :: "m"(d_7));         // ST0=7, ST1=2
    __asm__ volatile("fprem");                       // 7 mod 2 = 1
    __asm__ volatile("fistpl %0" : "=m"(i_out));     // 1
    __asm__ volatile("fistpl %0" : "=m"(r));         // 2 (kalan ST1)
    XP_SDK_END();
    if (i_out != 1 || r != 2) return 2;
    XP_SDK_BEG(1);
    __asm__ volatile("fld1");                        // ST0=1 (ST1 konumu)
    __asm__ volatile("fldl %0" :: "m"(d_2));         // ST0=2
    __asm__ volatile("fyl2x");                       // 1*log2(2)=1
    __asm__ volatile("fldl %0" :: "m"(d_2));         // ST0=2
    __asm__ volatile("fmulp");                       // 2^1=2
    __asm__ volatile("fistpl %0" : "=m"(i_out));     // 2
    XP_SDK_END();
    if (i_out != 2) return 3;
    XP_SDK_BEG(1);
    __asm__ volatile("fldl %0" :: "m"(d_2));         // ST0=2 (scale ustu: 2^2=4)
    __asm__ volatile("fldl %0" :: "m"(d_a));         // ST0=1.5, ST1=2
    __asm__ volatile("fscale");                      // ST0=1.5*2^2=6
    __asm__ volatile(".byte 0xD9, 0xC9");
    __asm__ volatile(".byte 0xDD, 0xD8" :: : "memory");  // ST1'i at
    __asm__ volatile("fistpl %0" : "=m"(i_out));     // 6
    XP_SDK_END();
    return (i_out == 6) ? 0 : 4;
}

// T11: fcompp + fstsw akisi: 5.0 vs 3.0 -> CF=0,ZF=0 -> jnb
static int t_fcompp(void) {
    r = 0;
    XP_SDK_BEG(1);
    __asm__ volatile("fldl %0" :: "m"(d_a));         // ST1=1.5
    __asm__ volatile("fldl %0" :: "m"(d_b));         // ST0=2.25, ST1=1.5
    __asm__ volatile("fcompp");                      // ikisini de at, flags
    __asm__ volatile("fwait");
    __asm__ volatile(".byte 0xDF, 0xE0" ::: "eax");
    __asm__ volatile("sahf");
    __asm__ volatile("jnb 1f\n\t"
                     "movl $1, %0\n"
                     "1:" : "=m"(r) :: "eax", "cc", "memory");
    XP_SDK_END();
    return (r == 0) ? 0 : 1;   // 2.25>1.5 -> CF=0 -> jnb alinir -> r=0
}

// T12: muhafazakar V/M saglik (mevcut op'lar bozulmadi mi)
static int t_sanity_v(int a, int b) {
    volatile int x = 0;
    XP_SDK_BEG(1);
    x = a + b;
    x = x * 3 + 7;
    if (x > 100) x -= 100;
    XP_SDK_END();
    return x;
}

static int t_sanity_m(int a) {
    volatile int x = 0;
    XP_SDK_BEG(2);
    x = a ^ 0x55;
    x = x + (x >> 2);
    XP_SDK_END();
    return x;
}

static int t_sanity_u(int a) {
    volatile int x = 0;
    XP_SDK_BEG(3);
    x = a * 2;
    x = x ^ 0x58;
    x = (unsigned)x >> 1;
    x = x + 9;
    XP_SDK_END();
    return x;
}

int main(void) {
    int e = 0;
    // x87 durumunu bilinen hale getir (misafir CRT kafasi kalmasin)
    __asm__ volatile("fninit");

    if ((e = t_mem_arith()))     { printf("FAIL fpu_mem_arith %d\n", e);     return 10 + e; }
    printf("OK fpu_mem_arith\n");
    if ((e = t_subr_divr()))     { printf("FAIL fpu_subr_divr %d\n", e);     return 20 + e; }
    printf("OK fpu_subr_divr\n");
    if ((e = t_sqrt_pi()))       { printf("FAIL fpu_sqrt_pi %d\n", e);       return 30 + e; }
    printf("OK fpu_sqrt_pi\n");
    if ((e = t_fstsw_branch()))  { printf("FAIL fpu_fstsw_branch %d\n", e);  return 40 + e; }
    printf("OK fpu_fstsw_branch\n");
    if ((e = t_fcomi_fcmov()))   { printf("FAIL fpu_fcomi_fcmov %d\n", e);   return 50 + e; }
    printf("OK fpu_fcomi_fcmov\n");
    if ((e = t_reg_forms()))     { printf("FAIL fpu_reg_forms %d\n", e);     return 60 + e; }
    printf("OK fpu_reg_forms\n");
    if ((e = t_pop_forms()))     { printf("FAIL fpu_pop_forms %d\n", e);     return 70 + e; }
    printf("OK fpu_pop_forms\n");
    if ((e = t_int_conv()))      { printf("FAIL fpu_int_conv %d\n", e);      return 80 + e; }
    printf("OK fpu_int_conv\n");
    if ((e = t_cw_round()))      { printf("FAIL fpu_cw_round %d\n", e);      return 90 + e; }
    printf("OK fpu_cw_round\n");
    if ((e = t_tbyte_transc()))  { printf("FAIL fpu_tbyte_transc %d\n", e);  return 100 + e; }
    printf("OK fpu_tbyte_transc\n");
    if ((e = t_fcompp()))        { printf("FAIL fpu_fcompp %d\n", e);        return 110 + e; }
    printf("OK fpu_fcompp\n");

    // saglik: 19+38=57; 57*3+7=178; -100=78
    if (t_sanity_v(19, 38) != 78) { printf("FAIL sanity_v\n"); return 120; }
    printf("OK sanity_v\n");
    if (t_sanity_m(0x1234) != ((0x1234 ^ 0x55) + ((0x1234 ^ 0x55) >> 2))) { printf("FAIL sanity_m\n"); return 121; }
    printf("OK sanity_m\n");
    if (t_sanity_u(19) != 72) { printf("FAIL sanity_u\n"); return 122; }
    printf("OK sanity_u\n");
    printf("SELFTEST OK\n");
    return 42;
}
