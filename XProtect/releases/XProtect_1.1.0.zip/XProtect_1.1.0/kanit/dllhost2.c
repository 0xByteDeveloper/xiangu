#include <windows.h>
#include <stdio.h>
typedef int (__cdecl *fn1)(int, int);
typedef int (__cdecl *fn2)(int);
int main(void) {
    HMODULE h = LoadLibraryA("xp_p.dll");
    if (!h) { printf("FAIL load %u\n", (unsigned)GetLastError()); return 1; }
    fn1 fa = (fn1)GetProcAddress(h, "xp_add2");
    fn2 fm = (fn2)GetProcAddress(h, "xp_mul2");
    if (!fa || !fm) { printf("FAIL gpaddr\n"); return 2; }
    int a = fa(19, 38);   /* 57*3+7=178 -> 78 */
    int b = fm(6);        /* 43 */
    printf("dllhost2 a=%d b=%d\n", a, b);
    if (a != 78) { printf("FAIL add2\n"); return 3; }
    if (b != 43) { printf("FAIL mul2\n"); return 4; }
    printf("SELFTEST OK\n");
    return 42;
}
