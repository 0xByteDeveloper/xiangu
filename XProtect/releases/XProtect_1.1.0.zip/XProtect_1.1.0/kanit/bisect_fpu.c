// bisect_fpu.c — A4: hangi x87 op VM'de yanlis? tek-tek bolge.
#include <stdio.h>
#include <string.h>

#define XP_SDK_BEG(t) \
    __asm__ volatile(".byte 0xB8, 0xB5, 0xE1, 0x37, 0x9C" ::: "eax", "memory"); \
    __asm__ volatile(".byte 0xB8, " #t ", 0x00, 0x00, 0x00" ::: "eax", "memory")
#define XP_SDK_END() \
    __asm__ volatile(".byte 0xB8, 0x8E, 0x2C, 0x7A, 0x3D" ::: "eax", "memory")

static volatile double d_7 = 7.0;
static volatile int    i_in = 7, i_out = 0;
static volatile float  f_a = 1.5f;
static volatile double d_b = 2.25;
static volatile double d_out = 0.0;

// B1: fldl + fistpl  -> 7
static void b1(void) {
    XP_SDK_BEG(1);
    __asm__ volatile("fldl %0" :: "m"(d_7));
    __asm__ volatile("fistpl %0" : "=m"(i_out));
    XP_SDK_END();
}
// B2: fldl + fimull + fistpl -> 49
static void b2(void) {
    XP_SDK_BEG(1);
    __asm__ volatile("fldl %0" :: "m"(d_7));
    __asm__ volatile("fimull %0" :: "m"(i_in));
    __asm__ volatile("fistpl %0" : "=m"(i_out));
    XP_SDK_END();
}
// B3: fldl + fimull + fadds + fistpl -> 50
static void b3(void) {
    XP_SDK_BEG(1);
    __asm__ volatile("fldl %0" :: "m"(d_7));
    __asm__ volatile("fimull %0" :: "m"(i_in));
    __asm__ volatile("fadds %0" :: "m"(f_a));
    __asm__ volatile("fistpl %0" : "=m"(i_out));
    XP_SDK_END();
}
// B4: fldl + fimull + fadds + fsubl + fistpl -> 48
static void b4(void) {
    XP_SDK_BEG(1);
    __asm__ volatile("fldl %0" :: "m"(d_7));
    __asm__ volatile("fimull %0" :: "m"(i_in));
    __asm__ volatile("fadds %0" :: "m"(f_a));
    __asm__ volatile("fsubl %0" :: "m"(d_b));
    __asm__ volatile("fistpl %0" : "=m"(i_out));
    XP_SDK_END();
}
// B5: fstp m64 yolu: fldl + fstpl
static void b5(void) {
    XP_SDK_BEG(1);
    __asm__ volatile("fldl %0" :: "m"(d_7));
    __asm__ volatile("fstpl %0" : "=m"(d_out));
    XP_SDK_END();
}

int main(void) {
    __asm__ volatile("fninit");
    b1(); printf("B1=%d (7)\n", i_out);
    b2(); printf("B2=%d (49)\n", i_out);
    b3(); printf("B3=%d (50)\n", i_out);
    b4(); printf("B4=%d (48)\n", i_out);
    b5(); { volatile unsigned long long bits; __builtin_memcpy((void*)&bits,(const void*)&d_out,8);
            printf("B5=%llx (%llx)\n", (unsigned long long)bits, 0x401C000000000000ULL); }
    return 42;
}
