// ============================================================
// tlstest.c — 1.1.0 TLS-callback kabul testi (zig cc uyumlu, saf C)
// TLS callback DLL_PROCESS_ATTACH'da isaret koyar. Korunan fonksiyon
// lazy XRT init ile ilk cagride kurulur (pack KAPALI yol).
// rc=42: tls_seen=1 + korunan fn dogru.
// ============================================================
#include <windows.h>
#include <stdio.h>

static volatile LONG g_tls_seen = 0;

#define XP_SDK_BEG(t) \
    __asm__ volatile(".byte 0xB8, 0xB5, 0xE1, 0x37, 0x9C" ::: "eax", "memory"); \
    __asm__ volatile(".byte 0xB8, " #t ", 0x00, 0x00, 0x00" ::: "eax", "memory")
#define XP_SDK_END() \
    __asm__ volatile(".byte 0xB8, 0x8E, 0x2C, 0x7A, 0x3D" ::: "eax", "memory")

static int prot_fn(int a) {
    volatile int r = 0;
    XP_SDK_BEG(1);
    r = a * 5 + 2;
    if (r > 50) r -= 50;
    XP_SDK_END();
    return r;             /* 12*5+2=62 -> 12 */
}

static void NTAPI tls_cb(PVOID h, DWORD reason, PVOID rsv) {
    (void)h; (void)rsv;
    if (reason == DLL_PROCESS_ATTACH) InterlockedExchange(&g_tls_seen, 1);
}

/* zig/ld: .CRT$XLB'yi TLS callback dizisine yerlestirmek icin
   section(attribute) + kullanilan referans (linker eleme) */
__attribute__((section(".CRT$XLB"), used))
static const PIMAGE_TLS_CALLBACK p_tls_cb = tls_cb;
__attribute__((used)) static const void* tls_anchor = (const void*)&p_tls_cb;

int main(void) {
    int v = prot_fn(12);
    printf("tls_seen=%ld v=%d\n", (long)g_tls_seen, v);
    if (!g_tls_seen) { printf("FAIL tls callback calismadi\n"); return 1; }
    if (v != 12)     { printf("FAIL prot_fn\n"); return 2; }
    printf("SELFTEST OK\n");
    return 42;
}
