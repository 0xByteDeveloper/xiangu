// ============================================================
// testdll2.c — 1.1.0-A4/DLL temiz test (SDK marker YOK, kesin sinirlar)
// xp_add2 / xp_mul2: her fonksiyonun sonu objdump ile dogrulanir.
// ============================================================
#include <windows.h>

__declspec(dllexport) __declspec(noinline) int __cdecl xp_add2(int a, int b) {
    volatile int r = 0;
    r = a + b;
    r = r * 3 + 7;
    if (r > 100) r -= 100;
    return r;
}

__declspec(dllexport) __declspec(noinline) int __cdecl xp_mul2(int a) {
    volatile int r = 0;
    r = a * 7 + 1;
    return r;
}

int __cdecl xp_add2_proto(int, int);

BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID rsv) {
    (void)h; (void)rsv;
    if (reason == DLL_PROCESS_ATTACH) {
        /* Loader-lock testi: xp_mul2 KORUNUR (stub->VM->xrt lazy init)
           ve DllMain icinden cagrilir. XRT PEB-gezinmeli (LoadLibrary
           YOK) -> kilitlenme olmamali. */
        volatile int q = xp_mul2(6);   /* 43 */
        (void)q;
    }
    return TRUE;
}
