// iattest.c — A6: IAT mov-form + call-form koruma testi
#include <windows.h>
#include <stdio.h>
#define XP_SDK_BEG(t) \
    __asm__ volatile(".byte 0xB8, 0xB5, 0xE1, 0x37, 0x9C" ::: "eax", "memory"); \
    __asm__ volatile(".byte 0xB8, " #t ", 0x00, 0x00, 0x00" ::: "eax", "memory")
#define XP_SDK_END() \
    __asm__ volatile(".byte 0xB8, 0x8E, 0x2C, 0x7A, 0x3D" ::: "eax", "memory")
static int msg_wrap(void) {
    volatile int r = 0;
    XP_SDK_BEG(1);
    r = (int)MessageBoxA(0, "x", "y", 0);   /* FF15 yolu (x64 mov+call olabilir) */
    XP_SDK_END();
    return r ? 7 : 7;
}
static int gtc_wrap(void) {
    volatile int r = 0;
    XP_SDK_BEG(1);
    char b[16]; b[0] = 0;
    r = (int)lstrlenA(b);                    /* FF15/kisa yolu */
    XP_SDK_END();
    return r;
}
int main(void) {
    int a = msg_wrap();
    int c = gtc_wrap();
    printf("a=%d c=%d\n", a, c);
    if (a != 7 || c != 0) { printf("FAIL\n"); return 1; }
    printf("SELFTEST OK\n");
    return 42;
}
