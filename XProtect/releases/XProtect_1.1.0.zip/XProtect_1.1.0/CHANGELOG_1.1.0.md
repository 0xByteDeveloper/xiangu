# XProtect 1.1.0 — A4-FPU + DLL/TLS + Check Debugger/VM + Import/Watermark

## Faz A4 — UniversalObfuscator FPU paritesi (en buyuk parite blogu KAPANDI)
- 72 UO FPU tipinin TAMAMI sanallastiriliyor (UO ust-kume: UO'nun native-ada
  biraktigi bellek-formlari dahil). x87 yigini gercek birimde (VMP semantigi).
- OP_FPU_ST/OP_FPU_MEM (VM_OPN 0x40); FCOMI/FCMOV EFLAGS senkronu tek-asm.
- Kanit: test_fpu_a4 14/14 rc=42 (korumali), bisect B1-B5, R5, metin2.

## DLL / TLS
- file-CRC DLL hedefi duzeltildi (PEB FullDllName; GetModuleFileNameA(NULL)
  yerine modul-kendisi) — DLL'de file-CRC artik dogru dosyayi dogrular.
- DllMain loader-lock guvenli (XRT PEB-gezinmeli; korunan cagri
  DLL_PROCESS_ATTACH icinde test edildi).
- TLS callback (pack KAPALI) rc=42; pack ile duru-RED (belgelenmis).
- DLL tamper -> rc=115 (file-CRC yakaladi).

## Check Debugger genisletmesi (~%25 -> ~%55 UO paritesi)
- K4 ThreadHideFromDebugger, K5 Kernel Debugger (SystemKernelDebugger
  Information), K6 surucu taramasi (sice/siwvid/ntice/iceext/syser).
- 'Check Kernel Debugger' ozelliginin motoru artik VAR.

## Check VM (cpCheckVirtualMachine) motor baglanti
- K7 CPUID hypervisor-present; --checkvm / UI secenegi; KVM'de
  true-positive dogrulandi.

## Import Protection (deneysel %60 -> tam)
- mov r,[IAT] formlari (lea/imm32 thunk yamasi) + VMProtect kapsam kurali
  (yalniz sanallastirilan fonksiyonlarin import'lari).
- IAT-only modun base+0 DEP cokmesi kok-nedeniyle kapandi.

## Watermark (kismen %40 -> tam)
- UO cpIncludeWatermark 1:1: metin dosyaya gomulu (LSD 0x130) + hash.

## Diger duzeltmeler
- x64 SIB base=5 mod=0 yanlis-siniflandirma (lea eax,[rcx*8] bozuk).
- jcc->bolge-sonu (SDK bolge) artik gecerli (son OP_RET'e yonlendirme).
- freestanding blob'da .rodata yasağı (surucu adlari u64 sabiti).

Kanal: regress_110.sh — R5 ULTIMATE rc=42, tamper rc=117, FPU 14/14,
DLL 42, metin2 ANTIDBG 0x1E. Commitler: eef21ec, 133b380, 6b25376, f4f5f0a.
