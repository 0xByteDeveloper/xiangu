XProtect 1.1.0 — UniversalObfuscator parite fazlari A4-A7
=========================================================
XProtectUI.exe  (x64)  — koruma arayuzu + CLI (--cli IN OUT [secenekler])
XProtectUI32.exe (x86)
xprotect_sdk.h  — SDK isaret makrolari (XP_SDK_BEG/END)
source/         — tam motor kaynaklari (C/C++, derleme: build_ui.sh)
kanit/          — kabul testleri (test_fpu_a4, dllhost2, tlstest, iattest)

CLI ornekleri:
  XProtectUI.exe --cli gir.exe cik_p.exe --sdkonly --antidebug
  XProtectUI.exe --cli gir.exe cik_p.exe --add 1000:1032:V --iat --filecrc
  XProtectUI.exe --cli gir.exe cik_p.exe --sdkonly --checkvm --watermark "METIN"

Kalite kapisi: R5 ULTIMATE rc=42 + tamper-duru-ret + FPU 14/14 + DLL 42 +
metin2 0xd7610 ANTIDBG statik. (wine testleri; kanit/ regress_110.sh)
