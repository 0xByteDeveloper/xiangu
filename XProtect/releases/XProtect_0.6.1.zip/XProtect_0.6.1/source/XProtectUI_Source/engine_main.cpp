// ============================================================
// engine_main.cpp — koruma orkestrasyonu
// Akis: PE yukle -> fonksiyonlari bul (export+COFF+PDB/MAP) ->
//       sec -> TIP SEVKI (0.3.0: V=sanallastirma, M=mutasyon,
//       U=mutasyon+sanallastirma) -> STRDEC/state planla ->
//       sifrele -> .vmp0 kur (blob+bc+stub+mut+state) -> .text yamala ->
//       secenekler (antidebug/strenc/memprot) -> checksum -> kaydet
// ============================================================
#include "engine.hpp"
#include "engine_sym.hpp"
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <set>
#include <map>
#include <string>
#include <vector>

struct RStr { u32 rva, len; };

// ============================================================
// 0.5.0 — XProtect Runtime yardimcilari (xrt_core.c ile SOZLESME)
// ============================================================
// FNV-1a 32 — xrt_core.c fnv_a ile birebir (export isim hash'i)
static u32 xfnv_a(const char* s, size_t n) {
    u32 h = 2166136261u;
    for (size_t i = 0; i < n; i++) { h ^= (u8)s[i]; h *= 16777619u; }
    return h;
}
// FNV-1a 32 kucuk-harf — xrt fnv_w ile ayni sonucu veren ANSI surumu
// (modul adi: PEB BaseDllName kucuk-harfe indirilir)
static u32 xfnv_lower(const std::string& s) {
    u32 h = 2166136261u;
    for (char c : s) {
        if (c >= 'A' && c <= 'Z') c = (char)(c + 32);
        h ^= (u8)c; h *= 16777619u;
    }
    return h;
}
// CRC32 bitwise — xrt crc_up ile birebir
static u32 xcrc_up(u32 c, u8 by) {
    c ^= by;
    for (int k = 0; k < 8; k++) c = (c >> 1) ^ (0xEDB88320u & (0u - (c & 1u)));
    return c;
}

// ---- import tablosu (IAT yuvalari) ----
struct ImpSlot {
    u32 iat_rva = 0;
    u32 dll_hash = 0, name_hash = 0;
    bool ordinal = false;
    std::string dll, name;
};
static bool parse_imports(const PEFile& pe, std::vector<ImpSlot>& out) {
    if (pe.e_lfanew == 0 || (size_t)pe.e_lfanew + 24 + 160 > pe.buf.size()) return false;
    const u8* base = pe.buf.data();
    u16 magic; memcpy(&magic, base + pe.e_lfanew + 24, 2);
    u32 ddoff = (magic == 0x20B) ? 112 : 96;   // OptionalHeader'e gore
    u32 imp_rva, imp_sz;
    memcpy(&imp_rva, base + pe.e_lfanew + 24 + ddoff + 8, 4);
    memcpy(&imp_sz,  base + pe.e_lfanew + 24 + ddoff + 12, 4);
    if (!imp_rva || !imp_sz) return false;
    u32 psz = pe.is64 ? 8 : 4;
    bool okc;
    u32 raw = pe.rva2raw(imp_rva, &okc);
    if (!okc) return false;
    for (u32 d = 0; d < 0x10000 && raw + d * 20 + 20 <= pe.buf.size(); d++) {
        u32 doff = raw + d * 20;
        u32 oft, name_rva, ft;
        memcpy(&oft, base + doff, 4);
        memcpy(&name_rva, base + doff + 12, 4);
        memcpy(&ft, base + doff + 16, 4);
        if (!oft && !name_rva && !ft) break;   // sonlandirici descriptor
        std::string dll;
        {
            bool ok2; u32 nr = pe.rva2raw(name_rva, &ok2);
            if (ok2 && nr + 2 < pe.buf.size()) {
                const char* p = (const char*)base + nr; u32 q = 0;
                while (q < 64 && nr + q < pe.buf.size() && p[q]) { dll.push_back(p[q]); q++; }
            }
        }
        u32 thunk_rva = oft ? oft : ft;
        if (!thunk_rva) continue;
        bool okt; u32 traw = pe.rva2raw(thunk_rva, &okt);
        if (!okt) continue;
        for (u32 k = 0; k < 0x20000; k++) {
            u64 th = 0;
            u32 toff = traw + k * psz;
            if (toff + psz > pe.buf.size()) break;
            memcpy(&th, base + toff, psz);
            if (!th) break;
            ImpSlot s;
            s.dll = dll;
            s.iat_rva = ft + k * psz;
            if (th & (pe.is64 ? 0x8000000000000000ull : 0x80000000u)) {
                s.ordinal = true;
            } else {
                bool okn; u32 hn = pe.rva2raw((u32)th, &okn);
                if (okn && hn + 2 < pe.buf.size()) {
                    const char* p = (const char*)base + hn + 2;   // hint (2 bayt) atla
                    u32 q = 0;
                    while (q < 128 && hn + 2 + q < pe.buf.size() && p[q]) { s.name.push_back(p[q]); q++; }
                }
            }
            s.dll_hash = xfnv_lower(dll);
            s.name_hash = s.ordinal ? 0 : xfnv_a(s.name.c_str(), s.name.size());
            out.push_back(s);
        }
    }
    return !out.empty();
}

// ---- SDK isaret taramasi (xprotect_sdk.h sozlesmesi) ----
// B8 <BEG_MAGIC> B8 <tip 1..3> [kullanici kodu] B8 <END_MAGIC>
static const u32 SDK_BEG_MAGIC = 0x9C37E1B5u;
static const u32 SDK_END_MAGIC = 0x3D7A2C8Eu;
static void scan_sdk(const PEFile& pe, std::vector<ManFn>& out, std::vector<std::string>& log) {
    const Section* t = pe.secbyname_c(".text");
    if (!t) return;
    bool ok; u32 raw = pe.rva2raw(t->va, &ok);
    if (!ok) return;
    u32 maxn = t->vsz;
    if (raw + maxn > pe.buf.size()) maxn = (u32)(pe.buf.size() - raw);
    if (maxn < 16) return;
    const u8* p = pe.buf.data() + raw;
    u32 i = 0;
    int found = 0;
    while (i + 10 <= maxn) {
        if (p[i] == 0xB8) {
            u32 mg; memcpy(&mg, p + i + 1, 4);
            if (mg == SDK_BEG_MAGIC && p[i + 5] == 0xB8) {
                u32 ty; memcpy(&ty, p + i + 6, 4);
                if (ty >= 1 && ty <= 3) {
                    // kapanis isaretini ara
                    u32 j = i + 10;
                    u32 end_at = 0;
                    while (j + 5 <= maxn) {
                        if (p[j] == 0xB8) {
                            u32 me; memcpy(&me, p + j + 1, 4);
                            if (me == SDK_END_MAGIC) { end_at = j; break; }
                        }
                        j++;
                    }
                    if (end_at) {
                        u32 beg = t->va + i + 10;
                        u32 endr = t->va + end_at;
                        if (endr > beg + 7 && endr - beg <= 0x40000) {
                            ManFn m;
                            m.rva = beg; m.size = endr - beg; m.ty = (int)ty - 1;
                            m.is_region = true;   /* 0.5.1: SDK isareti = bolge */
                            m.name = (ty == 1 ? "SDK_V" : (ty == 2 ? "SDK_M" : "SDK_U"));
                            m.name += "_0x" + hex32(beg);
                            out.push_back(m);
                            found++;
                            log.push_back("[SDK] isaret bulundu: " + m.name +
                                          " boyut=0x" + hex32(m.size) +
                                          " tip=" + (ty == 1 ? "V" : (ty == 2 ? "M" : "U")));
                        }
                        i = end_at + 5;
                        continue;
                    }
                    // kapanis yok: bu magic yanlis pozitif olabilir — normal devam
                }
            }
        }
        i++;
    }
    (void)found;
}

// ---- IAT dolayli-cagri noktasi tarayicisi ----
// Kesfedilmis fonksiyonlari disasm ile yurur; FF15/FF25 (XP_CALLI/XP_JMPI)
// uzerinden IAT yuvasina isaret edenleri toplar. Cozulemeyen bayt gorulurse
// O fonksiyon gvenli olmayan kabul edilir (yama yok — crash riski sifir).
struct IatSite { u32 site_rva; u32 iat_rva; bool is_jmp; u32 insn_len; };
static void scan_iat_sites(const PEFile& pe, const std::vector<FnInfo>& fns,
                            const std::map<u32, ImpSlot>& by_rva,
                            std::vector<IatSite>& out, u32& n_func_skip) {
    for (auto& f : fns) {
        if (f.size < 8) continue;
        bool ok; u32 raw = pe.rva2raw(f.rva, &ok);
        if (!ok || raw + f.size > pe.buf.size()) continue;
        u32 pc = f.rva, end = f.rva + f.size;
        bool aborted = false;
        while (pc < end) {
            Insn I = disasm(&pe.buf[raw + (pc - f.rva)], (int)(end - pc), pe.is64, pc,
                            (u64)pe.imagebase, pe.sizeofimage);
            if (I.op == XP_UNKNOWN || I.len == 0) { aborted = true; break; }
            if (I.op == XP_CALLI || I.op == XP_JMPI) {
                u32 slot_rva = 0;
                if (I.mem.riprel)
                    slot_rva = pc + I.len + (u32)(i32)(u32)I.mem.disp;
                else if (I.mem.absimage) {
                    u64 va = I.mem.absval;
                    if (va >= pe.imagebase && va < (u64)pe.imagebase + pe.sizeofimage)
                        slot_rva = (u32)(va - pe.imagebase);
                }
                if (slot_rva && by_rva.count(slot_rva)) {
                    IatSite s;
                    s.site_rva = pc; s.iat_rva = slot_rva;
                    s.is_jmp = (I.op == XP_JMPI); s.insn_len = I.len;
                    out.push_back(s);
                }
            }
            pc += I.len;
        }
        if (aborted) n_func_skip++;
    }
}

// Fonksiyonun GERCEK sonunu tara: ret + dolgu (int3/nop) -> dur.
// COFF sembolu olmayan son fonksiyonlarda 0xCC firtinasi onlenir.
static u32 est_func_size(const u8* p, u32 max, bool is64, u64 ib, u32 isz) {
    u32 pc = 0; bool sawret = false;
    while (pc < max) {
        Insn I = disasm(p + pc, (int)(max - pc), is64, pc, ib, isz);
        if (I.op == XP_UNKNOWN || I.len == 0 || I.op == XP_INT3)
            return sawret ? pc : max;
        if (I.op == XP_NOP && sawret) return pc;
        if (I.op == XP_NOP && !sawret) { pc += I.len; continue; }
        pc += I.len;
        if (I.op == XP_RET || I.op == XP_RETI16) sawret = true;
    }
    return pc;
}

// .pdata (x64): RUNTIME_FUNCTION tablosundan fonksiyonun KESIN sonunu bul.
// Donus: fonksiyon sonu RVA'si (bulunamazsa 0).
static u32 pdata_func_end(const PEFile& pe, u32 rva) {
    const Section* pd = pe.secbyname_c(".pdata");
    if (!pd || pd->vsz < 12) return 0;
    bool ok; u32 raw = pe.rva2raw(pd->va, &ok);
    if (!ok) return 0;
    u32 n = pd->vsz / 12;
    // RUNTIME_FUNCTION dizisi BeginAddress'e gore siralidir -> ikili arama
    u32 lo = 0, hi = n;
    while (lo < hi) {
        u32 mid = (lo + hi) / 2;
        u32 o = raw + mid * 12;
        if (o + 12 > pe.buf.size()) return 0;
        u32 beg; memcpy(&beg, &pe.buf[o], 4);
        if (beg == rva) {
            u32 end; memcpy(&end, &pe.buf[o + 4], 4);
            return (end > beg) ? end : 0;
        }
        if (beg < rva) lo = mid + 1; else hi = mid;
    }
    return 0;
}

static void scan_strings(const PEFile& pe, std::vector<RStr>& out) {
    const Section* rd = pe.secbyname_c(".rdata");
    if (!rd) return;
    bool ok; u32 raw = pe.rva2raw(rd->va, &ok);
    if (!ok) return;
    u32 run = 0;
    for (u32 i = 0; i < rd->vsz && raw + i < pe.buf.size(); i++) {
        u8 c = pe.buf[raw + i];
        if (c >= 0x20 && c < 0x7F) { run++; continue; }
        if (run >= 4 && c == 0) out.push_back({ rd->va + i - run, run });
        run = 0;
    }
}

int protect(const std::string& in, const std::string& out, const Options& opt,
            std::vector<std::string>& log) {
    auto L = [&](const std::string& s) { log.push_back(s); };
    char b[300];

    PEFile pe; std::string err;
    if (!pe.load(in, err)) { L("[HATA] " + err); return 1; }
    snprintf(b, sizeof b, "[PE] %s | Machine=0x%04X | %s | ImageBase=0x%llX | GirisRVA=0x%X",
             in.c_str(), pe.machine, pe.is64 ? "PE32+(x64)" : "PE32(x86)",
             (unsigned long long)pe.ib64, pe.entry_rva);
    L(b);
    for (auto& s : pe.secs) {
        snprintf(b, sizeof b, "  sec %-8s RVA=0x%06X VSz=0x%06X Raw=0x%06X Chars=0x%08X",
                 s.name, s.va, s.vsz, s.rawoff, s.chars);
        L(b);
    }

    // --- fonksiyon kesfi: export + COFF sembolleri ---
    std::map<u32, std::string> fnames;
    std::vector<std::pair<std::string, u32>> ex, cs;
    pe.exports(ex);
    pe.coff_symbols(cs);
    for (auto& e : ex) fnames[e.second] = e.first;
    for (auto& c : cs) if (!fnames.count(c.second)) fnames[c.second] = c.first;
    L("[KESIF] export=" + std::to_string(ex.size()) + " coff-fonksiyon=" + std::to_string(cs.size()));

    // --- 0.3.0: PDB / MAP fonksiyon isimleri (VMProtect davranisi) ---
    // Hedefin yaninda <ad>.pdb/.map varsa veya debug dizini gecerli bir PDB
    // gosteriyorsa isimler keşfe eklenir. HICBIRI yoksa bu blogun hicbir
    // etkisi yoktur — 0.2.0'nin kullanici-dogrulanmis cikti davranisi
    // bayt bayt korunur (Test.exe pakette pdb'siz birlikte gelir).
    size_t sym_added = 0;
    {
        SymSections ss;
        for (auto& s : pe.secs)
            ss.secs.push_back({s.va, s.vsz, s.rawsz, s.rawoff, s.chars, std::string(s.name)});
        auto slurp_n = [](const std::string& p, std::vector<u8>& out) -> bool {
            FILE* f = fopen(p.c_str(), "rb");
            if (!f) return false;
            fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
            if (n <= 0) { fclose(f); return false; }
            out.resize((size_t)n);
            size_t rd = fread(out.data(), 1, (size_t)n, f);
            fclose(f);
            return rd == (size_t)n;
        };
        // hedef klasoru + ad (dar yol)
        std::string dir = ".", base;
        {
            size_t q = in.find_last_of("\\/");
            if (q != std::string::npos) { dir = in.substr(0, q); base = in.substr(q + 1); }
            else base = in;
            size_t d = base.find_last_of('.');
            if (d != std::string::npos && d > 0) base.resize(d);
        }
        std::vector<std::string> cands;
        cands.push_back(dir + "\\" + base + ".pdb");
        std::vector<DbgPdbRef> dbg_names;
        pe_debug_pdb_names(pe.buf.data(), pe.buf.size(), ss, dbg_names);
        const su8* want_guid = NULL; su32 want_age = 0;
        if (!dbg_names.empty() && dbg_names[0].has_guid) {
            want_guid = dbg_names[0].guid; want_age = dbg_names[0].age;
        }
        for (auto& r : dbg_names) {
            const std::string& n = r.name;
            bool abs_ = (n.size() > 1 && (n[1] == ':' || n[0] == '\\' || n[0] == '/'));
            if (abs_) cands.push_back(n);
            size_t q = n.find_last_of("\\/");
            cands.push_back(dir + "\\" + (q != std::string::npos ? n.substr(q + 1) : n));
        }
        // dedupe
        for (size_t i = 0; i < cands.size(); i++)
            for (size_t j = i + 1; j < cands.size(); )
                if (cands[j] == cands[i]) cands.erase(cands.begin() + j); else j++;
        std::vector<SymEntry> sfns; std::string serr;
        for (auto& c : cands) {
            std::vector<u8> pd;
            if (!slurp_n(c, pd)) continue;
            if (want_guid && !pdb_matches(pd.data(), pd.size(), want_guid, want_age))
                continue;   // bayat/eslesmeyen PDB — ele
            if (pdb_parse(pd.data(), pd.size(), ss, sfns, serr)) break;
            sfns.clear();
        }
        // MAP
        {
            std::vector<u8> md;
            if (slurp_n(dir + "\\" + base + ".map", md)) {
                std::vector<SymEntry> mfns;
                if (map_parse((const char*)md.data(), md.size(), ss, pe.imagebase, mfns, serr))
                    for (auto& e : mfns) sfns.push_back(e);
            }
        }
        for (auto& e : sfns) {
            if (fnames.count(e.rva)) continue;
            fnames[e.rva] = e.name;
            sym_added++;
        }
        if (sym_added)
            L("[KESIF] +PDB/MAP=" + std::to_string(sym_added) + " (pdb/map yaninda/hata-ayiklama dizininde)");
    }

    std::vector<FnInfo> fns;
    {
        Section* text0 = pe.secbyname(".text");
        u32 textend = text0 ? text0->va + text0->vsz : 0;
        std::vector<u32> rv;
        for (auto& kv : fnames) rv.push_back(kv.first);
        std::sort(rv.begin(), rv.end());
        for (size_t i = 0; i < rv.size(); i++) {
            u32 r = rv[i];
            if (!text0 || r < text0->va || r >= textend) continue;
            u32 next_bound = (i + 1 < rv.size() ? rv[i + 1] : textend);
            u32 sz = next_bound - r;
            if (sz > 0x8000) sz = 0x8000;
            // x64: .pdata'daki RUNTIME_FUNCTION KESIN siniri verir —
            // (BU, onceki surumdeki "est+16 tasma -> sonraki fonksiyonu
            //  int3 ile ezip acilista crash" hatasini kokten engeller)
            if (pe.is64) {
                u32 pend = pdata_func_end(pe, r);
                if (pend > r && pend <= next_bound) sz = pend - r;
            }
            // sembol araligi zenginse guven; genis aralikta gercek kod sonunu tara
            {
                bool okraw; u32 raw = pe.rva2raw(r, &okraw);
                if (okraw && raw + sz <= pe.buf.size() && sz > 16) {
                    u32 est = est_func_size(&pe.buf[raw], sz, pe.is64, pe.imagebase, pe.sizeofimage);
                    if (est + 64 < sz) sz = est + 16;   // tarayici daha erken bitirdi
                }
            }
            // KESIN GUVENLIK: sonraki sembolun icine asla tasma (x86 + pdata'siz durumlar)
            if (r + sz > next_bound) sz = next_bound - r;
            if (sz < 8) continue;
            FnInfo f; f.rva = r; f.size = sz; f.name = fnames[r];
            f.exported = std::any_of(ex.begin(), ex.end(), [&](auto& e) { return e.second == r; });
            fns.push_back(f);
        }
    }
    snprintf(b, sizeof b, "[FONKSIYON] %zu aday (.text)", fns.size());
    L(b);

    // --- 0.4.1: MANUEL fonksiyonlar (UI Manual Address Base/End) ---
    // 0.5.0: opt.manual + SDK isaretleri birlesik liste (manual_all)
    std::vector<ManFn> manual_all = opt.manual;
    if (opt.sdk_scan) scan_sdk(pe, manual_all, log);
    // Kullanici Base/End ile kesin {rva, boyut, tip} verir. 0.4.0'a kadar bu
    // liste motora hic ulasmadigindan (yalnizca tarayici adaylari eslestirilirdi)
    // ULTRA (M+V) secilse bile fonksiyona DOKUNULMIYORDU (.vmp0 yalnizca VM blob
    // tasiyordu). Artik aday-aramadan bagimsiz derlenir; ayni RVA'daki tarayici
    // adayi kesin boyut lehine cikarilir.
    for (auto& m : manual_all) {
        Section* ms = NULL;
        for (auto& s : pe.secs)
            if ((s.chars & 0x20000000) && m.rva >= s.va && m.rva < s.va + s.vsz) { ms = &s; break; }
        if (!ms) { L("[MANUEL] RED: 0x" + hex32(m.rva) + " yurutulebilir bolumde degil"); continue; }
        u32 sz = m.size;
        if (!sz || sz > 0x100000) { L("[MANUEL] RED: gecersiz boyut 0x" + hex32(sz)); continue; }
        if (m.rva + sz > ms->va + ms->vsz) {
            sz = (ms->va + ms->vsz) - m.rva;
            L("[MANUEL] uyari: End bolum sonunu asti -> 0x" + hex32(sz) + " kirpildi");
        }
        bool replaced = false;
        for (size_t i = 0; i < fns.size(); ) {
            if (fns[i].rva == m.rva) { fns.erase(fns.begin() + i); replaced = true; }
            else i++;
        }
        FnInfo f; f.rva = m.rva; f.size = sz;
        f.name = m.name.empty() ? ("MANUAL_0x" + hex32(m.rva)) : m.name;
        f.selected = true;
        fns.push_back(f);
        snprintf(b, sizeof b, "[MANUEL] %s @RVA=0x%06X boyut=0x%X tip=%s%s",
                 f.name.c_str(), f.rva, sz,
                 m.ty == 0 ? "V" : (m.ty == 1 ? "M" : "U"),
                 replaced ? " (tarayici adayi degisti)" : "");
        L(b);
    }

    // --- secim ---
    std::set<u32> man_rva; std::map<u32,int> man_ty;   // 0.4.1: manuel fonksiyonlar
    for (auto& m : manual_all) { man_rva.insert(m.rva); man_ty[m.rva] = m.ty; }
    std::set<u32> sdk_rva;
    for (auto& m : manual_all) if (m.is_region) sdk_rva.insert(m.rva);
    for (auto& f : fns) {
        if (man_rva.count(f.rva)) continue;   // manuel: kesin secili (asla ezilmez)
        if (opt.sdk_only) continue;           // 0.5.0: yalniz SDK/manual bolgeleri koru
        if (opt.manual.empty() && (opt.all || opt.funcs.empty())) { f.selected = (f.size >= 24 && f.size <= 8192); continue; }
        for (auto& want : opt.funcs) {
            if (want == f.name) { f.selected = true; break; }
            u32 rv = (u32)strtoul(want.c_str(), nullptr, 16);
            if (rv && rv == f.rva) { f.selected = true; break; }
        }
    }

    // --- 0.3.0: TIP SEVKI (V/M/U) — ftypes anahtarlari opt.funcs
    // ile ayni formattadir (isim ya da buyuk-harf RVA-hex) ---
    auto ftype_of = [&](const FnInfo& f) -> int {
        auto itm = man_ty.find(f.rva);          // 0.4.1: manuel tip onceligi
        if (itm != man_ty.end()) return itm->second;
        auto it = opt.ftypes.find(f.name);
        if (it != opt.ftypes.end()) return it->second;
        char rb[24]; snprintf(rb, sizeof rb, "%X", f.rva);
        it = opt.ftypes.find(rb);
        if (it != opt.ftypes.end()) return it->second;
        return opt.default_type;
    };

    Section* text = pe.secbyname(".text");
    Section* rdata = pe.secbyname(".rdata");
    u32 rdata_rva = rdata ? rdata->va : 0;
    u32 rdata_sz  = rdata ? rdata->vsz : 0;
    std::vector<RStr> strings;
    if (opt.strenc) {
        scan_strings(pe, strings);
        snprintf(b, sizeof b, "[STRENC] .rdata'da %zu string tespit", strings.size());
        L(b);
    }

    // ============================================================
    // 0.5.0 — ERKEN YERLESIM + IMPORT KORUMASI (derleme ONCESI)
    // .vmp0 duzeni: [vm blob][xrt kod][cfg][IAT thunklar][bc][stublar]
    //               [M kapi+govde][state][IAT cache]
    // IAT yamalari derlemeden once yapilir: boylece mutasyon/lifter
    // FF15 yerine E8 (dogrudan cagri) gorur -> API cagiran fonksiyonlar
    // da sanallastirilabilir hale gelir (VMProtect davranisi).
    // ============================================================
    const u8* blob; int blob_len;
    if (pe.is64) { blob = VM_BLOB64; blob_len = VM_BLOB64_LEN; }
    else         { blob = VM_BLOBX86; blob_len = VM_BLOBX86_LEN; }

    u32 newva_guess = 0;
    {
        u32 lastva = 0, lastvsz = 0;
        for (auto& s : pe.secs) if (s.va + s.vsz > lastva + lastvsz) { lastva = s.va; lastvsz = s.vsz; }
        newva_guess = (lastva + lastvsz + pe.secalign - 1) & ~(pe.secalign - 1);
    }

    bool rt_any  = opt.rt_selfcrc || opt.rt_textcrc || opt.rt_filecrc;
    // 0.6.0: paketleme xrt_unpack ister (EP stub cagirir)
    bool rt_blob = rt_any || opt.iat_prot || opt.pack;
    u32 xrt_len      = pe.is64 ? (u32)XRT_BLOB64_LEN : (u32)XRT_BLOBX86_LEN;
    u32 xrt_code_off = 0, cfg_off = 0;
    u32 xrt_entry_rva = 0, xrt_resolve_rva = 0, cfg_rva = 0, xrt_unpack_rva = 0;
    if (rt_blob) {
        xrt_code_off = ((u32)blob_len + 15) & ~15u;
        cfg_off      = (xrt_code_off + xrt_len + 15) & ~15u;
        u32 xrt_rva  = newva_guess + xrt_code_off;
        xrt_entry_rva   = xrt_rva + (pe.is64 ? XRT_BLOB64_ENTRY_OFF : XRT_BLOBX86_ENTRY_OFF);
        xrt_resolve_rva = xrt_rva + (pe.is64 ? XRT_BLOB64_RESOLVE_OFF : XRT_BLOBX86_RESOLVE_OFF);
        xrt_unpack_rva  = xrt_rva + (pe.is64 ? XRT_BLOB64_UNPACK_OFF : XRT_BLOBX86_UNPACK_OFF);
        cfg_rva         = newva_guess + cfg_off;
    }

    // ---- IAT korumasi: tarama + thunk planlama + cagri noktasi yamasi ----
    std::vector<ImpSlot> imps;
    std::vector<u32> thunk_rvas;          // benzersiz IAT yuvasi basina bir thunk
    std::vector<ImpSlot> thunk_slots;     // thunk ile eslesen slot
    // 0.6.1 DÜZELTME (kullanıcı bulgusu: metin2 ULTRA+loaderCRC'te sessiz
    // no-op): 0.6.0'da XCFG 0x40 -> 0x48 büyüdü (XCFG_OFF_PACKRVA) ama
    // rezerv 0x40'ta kaldı -> cfg'nin son 8B (pack_rva+reserved=0)
    // İLK bytecode'un ilk 8 baytını EZİYORDU -> VM çöp opcode okuyor,
    // fonksiyon sessizce no-op'a düşüyor (crash YOK, yanlış sonuç VAR).
    u32 thunk_area_end = rt_blob ? (cfg_off + XCFG_SIZE_E) : (u32)blob_len;
    u32 n_iat_sites = 0, n_iat_funcs_skip = 0;
    if (opt.iat_prot) {
        std::map<u32, ImpSlot> by_rva;
        if (parse_imports(pe, imps))
            for (auto& s : imps) by_rva[s.iat_rva] = s;
        if (by_rva.empty()) {
            L("[IAT] import tablosu bos/okunamadi — koruma atlandi");
        } else {
            std::vector<IatSite> sites;
            scan_iat_sites(pe, fns, by_rva, sites, n_iat_funcs_skip);
            // benzersiz yuvalar
            std::map<u32, ImpSlot> uniq;
            std::vector<u32> order;
            for (auto& st : sites)
                if (!uniq.count(st.iat_rva)) { uniq[st.iat_rva] = by_rva[st.iat_rva]; order.push_back(st.iat_rva); }
            std::vector<u8> probe = pe.is64
                ? build_thunk_x64(0, 0, 0, 0, 0, 0)
                : build_thunk_x86(0, 0, 0, 0, 0, 0);
            const u32 thlen = (u32)probe.size();
            u32 tcur = (thunk_area_end + 15) & ~15u;
            for (u32 r : order) {
                thunk_rvas.push_back(newva_guess + tcur);
                thunk_slots.push_back(uniq[r]);
                tcur += thlen;
            }
            thunk_area_end = tcur;
            // cagri noktalarini yamala: FF15->E8 (call), FF25->E9 (jmp) + nop dolgu
            // (ayni site birden fazla fonksiyon araliginda olabilir — dedupe)
            std::set<u32> done;
            for (auto& st : sites) {
                if (done.count(st.site_rva)) continue;
                done.insert(st.site_rva);
                bool okr; u32 sraw = pe.rva2raw(st.site_rva, &okr);
                if (!okr || sraw + st.insn_len > pe.buf.size()) continue;
                // thunk rvasini bul
                u32 thr = 0;
                for (size_t q = 0; q < thunk_slots.size(); q++)
                    if (thunk_slots[q].iat_rva == st.iat_rva) { thr = thunk_rvas[q]; break; }
                if (!thr) continue;
                i32 rel = (i32)(thr - (st.site_rva + 5));
                u8 jb[16];
                jb[0] = st.is_jmp ? 0xE9 : 0xE8;   // jmp / call thunk
                jb[1] = (u8)(u32)rel; jb[2] = (u8)((u32)rel >> 8);
                jb[3] = (u8)((u32)rel >> 16); jb[4] = (u8)((u32)rel >> 24);
                for (u32 q = 5; q < st.insn_len; q++) jb[q] = 0x90;  // nop dolgu
                memcpy(&pe.buf[sraw], jb, st.insn_len);
                n_iat_sites++;
            }
            snprintf(b, sizeof b, "[IAT] %zu import (benzersiz yuva=%zu) | %u cagri noktasi thunk'a cevrildi | %u fonksiyon atlandi (cozumlenemeyen bayt)",
                     imps.size(), order.size(), n_iat_sites, n_iat_funcs_skip);
            L(b);
            for (size_t q = 0; q < thunk_slots.size() && q < 12; q++)
                L("  [IAT] thunk[" + std::to_string(q) + "] " + thunk_slots[q].dll + "!" +
                  (thunk_slots[q].ordinal ? ("#" + std::to_string(thunk_slots[q].name_hash)) : thunk_slots[q].name) +
                  " IAT=0x" + hex32(thunk_slots[q].iat_rva) + " RVA=0x" + hex32(thunk_rvas[q]));
            if (thunk_slots.size() > 12)
                L("  [IAT] ... +" + std::to_string(thunk_slots.size() - 12) + " thunk daha");
        }
    }

    // --- lift / mutasyon ---
    struct Compiled {
        FnInfo* f; VFn v; std::vector<u8> plain, enc;
        u64 key = 0; u32 bc_rva = 0, stub_rva = 0;
        bool tramp = false;
        int  ty = 0;                          // 0=V 1=M 2=U
        MutFn mut;                           // M: olcum gecisi; U: kaynak mutasyon
        u32  mut_rva = 0;                    // M: .vmp0 icindeki yerlesim
        u32  mut_gate_rva = 0;               // 0.5.0: M onundeki runtime kapisI
        std::vector<u32> state_sites;         // plain icinde state rva u32 pozisyonlari
        std::vector<u32> state_strva;         // sirasiyla string rva'lari
    };
    std::vector<Compiled> comps;
    int nV = 0, nM = 0, nU = 0, nUf = 0;
    for (auto& f : fns) {
        if (!f.selected) continue;
        bool okraw; u32 raw = pe.rva2raw(f.rva, &okraw);
        if (!okraw || raw + f.size > pe.buf.size()) { f.note = "ham veri yok"; continue; }
        int ty = ftype_of(f);
        bool is_region = sdk_rva.count(f.rva) != 0;   // 0.5.1: yalniz SDK bolgesi
        if (ty == 1) {
            // --- MUTASYON (native): makine kodu kalir, yeniden uretilir ---
            MutFn m = mutate_function(&pe.buf[raw], f.rva, f.size, pe.is64,
                                      pe.imagebase, pe.sizeofimage,
                                      true /* 0.4.1: x86 dis-cagri rel32 fixup zaten destekli */,
                                      opt.mut_strength,
                                      f.rva ^ 0x9E3779B9u, 0 /*olcum gecisi*/, is_region);
            if (!m.ok) { f.note = "RED: mutasyon " + m.why; continue; }
            Compiled c; c.f = &f; c.ty = 1; c.mut = m;
            comps.push_back(c);
            nM++;
            continue;
        }
        // --- V / U: lifter kaynagi (U'da mutasyon on gecisi) ---
        std::vector<u8> mbuf;
        const u8* lcode = &pe.buf[raw];
        u32 lsize = f.size;
        int jl;
        MutFn mkeep;                            // U: istatistik/kayit tut
        if (ty == 2) {
            MutFn m = mutate_function(&pe.buf[raw], f.rva, f.size, pe.is64,
                                      pe.imagebase, pe.sizeofimage,
                                      true /* 0.4.1: x86 dis-cagri rel32 fixup zaten destekli */,
                                      opt.mut_strength,
                                      f.rva ^ 0x9E3779B9u, f.rva /*base=fonksiyon RVA*/,
                                      false /* U kaynak mutasyonu: bolge kuyrugu YOK — lifter yapay OP_RET ile cikar */);
            if (m.ok) {
                mbuf = m.code; lcode = mbuf.data(); lsize = (u32)mbuf.size();
                mkeep = m;
                nU++;
            } else {
                // mutasyon mumkun degil: 0.2.0 U davranisina dus (VM junk)
                L("[ULTRA] on-mutasyon RED: " + m.why + " -> saf V ye dusuluyor" + (is_region ? " (bolge)" : ""));
                ty = 0; nUf++;
            }
            jl = 2;
        } else {
            // V: acik tip 0 => saf sanallastirma (junk yok).
            // ftypes yoksa 0.2.0 CLI uyumu: level>=2 -> VM junk
            jl = opt.ftypes.empty() ? (opt.level >= 2 ? 2 : 0) : 0;
            nV++;
        }
        // 0.5.0: x86 VM'de dogal cagri (OP_NCALL) hala kirik (vm_natcall86
        // Unicorn testinde yigin bozumu) — x86'ta cagri iceren fonksiyonlar
        // V/U reddedilir (duru RED, sessiz yanlis SONUC yerine). M modu
        // native calistigi icin cagrilar sorunsuz. x64'te natcall CALISIYOR
        // (wine test_rt64 kaniti). 0.5.1'de x86 natcall duzeltmesi planli.
        bool lift_allow_call = true; /* EXPERIMENT */
        VFn v = lift_function(lcode, f.rva, lsize, pe.is64,
                              pe.imagebase, pe.sizeofimage,
                              lift_allow_call,
                              rdata_rva, rdata_sz,
                              jl, f.rva ^ 0x9E3779B9u,
                              mbuf.empty() /* 0.4.1: mutant girdide dolgu akisi kesmez */,
                              is_region);
        if (!v.ok) { f.note = "RED: " + v.why; continue; }
        Compiled c; c.f = &f; c.ty = ty; c.v = v;
        if (ty == 2) c.mut = mkeep;
        comps.push_back(c);
    }
    {
        u32 n_sel = 0;
        for (auto& f2 : fns) if (f2.selected) n_sel++;
        snprintf(b, sizeof b, "[LIFT] %zu/%u secili fonksiyon | V=%d M=%d U=%d (U-mutdus=%d)",
                 comps.size(), n_sel, nV, nM, nU, nUf);
        if (n_sel > (u32)comps.size())
            snprintf(b + strlen(b), sizeof b - strlen(b),
                     " | UYARI: %u fonksiyon RED edildi (asagida)", n_sel - (u32)comps.size());
    }
    L(b);
    for (auto& f : fns) {
        if (f.selected && !f.virtualized && !f.note.empty() && f.note.rfind("RED", 0) == 0)
            L("[RED] " + f.name + " @0x" + hex32(f.rva) + ": " + f.note);
    }

    // --- plain olustur: STRDEC + ANTIDBG + govde ---
    // (blob/newva_guess 0.5.0'da derleme ONCESINE tasindi — IAT thunk plani)

    for (auto& c : comps) {
        if (c.ty == 1) continue;              // M: bayt-kod yok
        std::vector<u8> plain;
        if (opt.strenc) {
            std::vector<RStr> used;
            for (u32 ref : c.v.str_refs)
                for (auto& s : strings)
                    if (ref >= s.rva && ref < s.rva + s.len)
                        if (std::find_if(used.begin(), used.end(), [&](RStr& r) { return r.rva == s.rva; }) == used.end())
                            used.push_back(s);
            for (auto& s : used) {
                plain.push_back(OP_STRDEC);
                for (int k = 0; k < 4; k++) plain.push_back((u8)(s.rva >> (8 * k)));
                c.state_sites.push_back((u32)plain.size());
                for (int k = 0; k < 4; k++) plain.push_back(0);   // state rva placeholder
                c.state_strva.push_back(s.rva);
                u32 k2 = (s.rva * 2654435761u) | 1u;
                c.v.notes.push_back("  [STRDEC] str=0x" + hex32(s.rva) + " len=" + std::to_string(s.len) + " key=0x" + hex32(k2));
            }
        }
        if (opt.antidebug) plain.push_back(OP_ANTIDBG);
        plain.insert(plain.end(), c.v.plain.begin(), c.v.plain.end());
        c.plain = plain;
    }

    // --- section icinde RVAlari planla ---
    // 0.5.0: vm blob + (xrt + cfg + thunklar erken planlandi) sonrasindan devam
    u32 cur = thunk_area_end;
    u32 xrt_after = cur;   // xrt kodu + cfg zaten secimg'in basina yazilacak
    for (auto& c : comps) {
        if (c.ty == 1) continue;              // M: bc yerlesimi yok
        cur = (cur + 7) & ~7u;
        c.bc_rva = newva_guess + cur;
        cur += (u32)c.plain.size();
    }
    u32 vent_guess = newva_guess + (pe.is64 ? VM_BLOB64_ENTRY_OFF : VM_BLOBX86_ENTRY_OFF);
    for (auto& c : comps) {
        if (c.ty == 1) continue;              // M: stub yok (native govde)
        cur = (cur + 15) & ~15u;
        c.stub_rva = newva_guess + cur;
        std::vector<u8> st;
        bool isreg = sdk_rva.count(c.f->rva) != 0;
        u32 cont = isreg ? (c.f->rva + c.f->size) : 0;
        if (pe.is64) st = build_stub_x64(c.stub_rva, vent_guess, c.key, c.bc_rva, (u32)c.plain.size(),
                                         rt_any ? xrt_entry_rva : 0, rt_any ? cfg_rva : 0, cont);
        else         st = build_stub_x86(c.stub_rva, vent_guess, c.key, c.bc_rva, (u32)c.plain.size(), c.v.retimm,
                                         rt_any ? xrt_entry_rva : 0, rt_any ? cfg_rva : 0, cont);
        c.tramp = st.size() > c.f->size;
        cur += (u32)st.size();
    }
    // --- mutasyon bloklari (tip M): runtime kapisI + olcum gecisi boyutu ---
    for (auto& c : comps) if (c.ty == 1) {
        cur = (cur + 15) & ~15u;
        u32 gate_rva = newva_guess + cur;
        u32 glen = 0;
        if (rt_any) {
            std::vector<u8> g = pe.is64
                ? build_mgate_x64(gate_rva, xrt_entry_rva, cfg_rva, 0)
                : build_mgate_x86(gate_rva, xrt_entry_rva, cfg_rva, 0);
            glen = (u32)g.size();
        }
        c.mut_gate_rva = gate_rva;
        c.mut_rva = gate_rva + glen;          // govde kapiya bitisik
        cur += glen + (u32)c.mut.code.size();
    }
    u32 state_off = cur;
    u32 nstate = 0;
    for (auto& c : comps) nstate += (u32)c.state_sites.size();
    // 0.5.0: IAT cache hucreleri (thunk basina isaretci genisligi)
    u32 psz = pe.is64 ? 8 : 4;
    u32 cache_off = state_off + nstate;
    std::vector<u32> cache_rvas;
    for (size_t q = 0; q < thunk_slots.size(); q++)
        cache_rvas.push_back(newva_guess + cache_off + (u32)q * psz);

    // --- state RVA'larini plain'e yaz ---
    u32 state_idx = 0;
    for (auto& c : comps) {
        for (size_t i = 0; i < c.state_sites.size(); i++) {
            u32 stva = newva_guess + state_off + state_idx;
            u32 at = c.state_sites[i];
            for (int k = 0; k < 4; k++) c.plain[at + k] = (u8)(stva >> (8 * k));
            state_idx++;
        }
    }

    // --- sifrele ---
    for (auto& c : comps) {
        if (c.ty == 1) continue;              // M: sifreleme yok (native kod)
        u64 key = 0;
        if (opt.vmenc) {
            key = ((u64)(u32)(c.f->rva * 2654435761u + 0x9E3779B9u) << 32)
                | (u32)((u32)c.plain.size() * 0x2545F491u + 1u) | 1ull;
        }
        c.key = key;
        c.enc.resize(c.plain.size());
        for (size_t i = 0; i < c.plain.size(); i++)
            c.enc[i] = c.plain[i] ^ VM_KS(key, i);   /* pozisyon-bazli */
    }

    // --- section goruntusunu kur ---
    std::vector<u8> secimg;
    secimg.insert(secimg.end(), blob, blob + blob_len);
    // 0.5.0: xrt blob (kod) — self-CRC bu bolgeyi kapsar (cfg haric)
    if (rt_blob) {
        secimg.resize(xrt_code_off, 0);
        const u8* xblob = pe.is64 ? XRT_BLOB64 : XRT_BLOBX86;
        secimg.insert(secimg.end(), xblob, xblob + xrt_len);
        secimg.resize(cfg_off + XCFG_SIZE_E, 0);   // cfg (0.6.1: 0x48 — 0x40 rezervi bc ezdi!)
    }
    while (secimg.size() < (size_t)state_off - (nstate ? 0 : 0)) secimg.push_back(0);
    secimg.resize(cache_off + (u32)thunk_slots.size() * psz, 0);
    for (auto& c : comps) {
        if (c.ty == 1) continue;              // M: bc/stub kopyasi yok
        u32 o = c.bc_rva - newva_guess;
        memcpy(&secimg[o], c.enc.data(), c.enc.size());
        u32 so = c.stub_rva - newva_guess;
        u32 vent = vent_guess;
        std::vector<u8> st;
        bool isreg2 = sdk_rva.count(c.f->rva) != 0;
        u32 cont2 = isreg2 ? (c.f->rva + c.f->size) : 0;
        if (pe.is64) st = build_stub_x64(c.stub_rva, vent, c.key, c.bc_rva, (u32)c.plain.size(),
                                         rt_any ? xrt_entry_rva : 0, rt_any ? cfg_rva : 0, cont2);
        else         st = build_stub_x86(c.stub_rva, vent, c.key, c.bc_rva, (u32)c.plain.size(), c.v.retimm,
                                         rt_any ? xrt_entry_rva : 0, rt_any ? cfg_rva : 0, cont2);
        memcpy(&secimg[so], st.data(), st.size());
    }
    // 0.5.0: IAT thunklari (gecikmeli import cozumleyicileri)
    for (size_t q = 0; q < thunk_slots.size(); q++) {
        std::vector<u8> th = pe.is64
            ? build_thunk_x64(thunk_rvas[q], xrt_resolve_rva, cache_rvas[q],
                              thunk_slots[q].dll_hash, thunk_slots[q].name_hash, thunk_slots[q].iat_rva)
            : build_thunk_x86(thunk_rvas[q], xrt_resolve_rva, cache_rvas[q],
                              thunk_slots[q].dll_hash, thunk_slots[q].name_hash, thunk_slots[q].iat_rva);
        std::vector<u8> probe2 = pe.is64 ? build_thunk_x64(0, 0, 0, 0, 0, 0) : build_thunk_x86(0, 0, 0, 0, 0, 0);
        u32 expected = (u32)probe2.size();
        if (th.size() != expected) {
            snprintf(b, sizeof b, "[HATA] IAT thunk boyut %zu != %u (yerlesim bozulur)", th.size(), expected);
            L(b); return 1;
        }
        u32 o = thunk_rvas[q] - newva_guess;
        memcpy(&secimg[o], th.data(), th.size());
    }
    // mutasyon bloklari: GERCEK base_rva ile yeniden uret (deterministik LCG
    // ayni seed'i verir; boyutlar bayt bayt eslesmeli)
    for (auto& c : comps) if (c.ty == 1) {
        bool okraw2; u32 raw2 = pe.rva2raw(c.f->rva, &okraw2);
        if (!okraw2) { L("[HATA] mutasyon yeniden uretim raw yok"); return 1; }
        // 0.4.3 FIX (kullanici x4: Mutation ciktisi V ile ayni cikiyordu):
        // ikinci geciste allow_call YANLISLIKLA pe.is64 yollaniyordu — x86'da
        // (is64=false) yeniden-uretim "call desteklenmiyor" diyerek dusuyor,
        // olcum gecisi ise true ile govde uretip tutarsizlik tetikliyor ->
        // [HATA] + rc=1 -> CIKTI DOSYASI HIC YAZILMIYOR. GUI eski V ciktisini
        // diskte birakip kullanici onu "mutation" saniyor (uc dosyadan ikisi
        // bayt-bayt ayni). Olcum gecisiyle AYNI parametre: allow_call=true
        // (0.4.1 x86 rel32 dis-cagri fixup'i destekliyor).
        MutFn m2 = mutate_function(&pe.buf[raw2], c.f->rva, c.f->size, pe.is64,
                                   pe.imagebase, pe.sizeofimage, true,
                                   opt.mut_strength, c.f->rva ^ 0x9E3779B9u,
                                   c.mut_rva /* GERCEK base */,
                                   sdk_rva.count(c.f->rva) != 0 /* 0.5.1: yalniz SDK bolgesi */);
        if (!m2.ok || m2.code.size() != c.mut.code.size()) {
            { FILE* f1 = fopen("/tmp/mutpass1.bin","wb"); if(f1){fwrite(c.mut.code.data(),1,c.mut.code.size(),f1);fclose(f1);} FILE* f2 = fopen("/tmp/mutpass2.bin","wb"); if(f2){fwrite(m2.code.data(),1,m2.code.size(),f2);fclose(f2);} L("[HATA] mutasyon tutarsiz: " + c.f->name + " neden=" + m2.why + " " + std::to_string(m2.code.size()) + " vs " + std::to_string(c.mut.code.size())); return 1; }
        }
        u32 o = c.mut_rva - newva_guess;
        memcpy(&secimg[o], m2.code.data(), m2.code.size());
        // 0.5.0: runtime kapisini govde onune yaz (pushad/pushaq korumali)
        if (rt_any) {
            std::vector<u8> g = pe.is64
                ? build_mgate_x64(c.mut_gate_rva, xrt_entry_rva, cfg_rva, c.mut_rva)
                : build_mgate_x86(c.mut_gate_rva, xrt_entry_rva, cfg_rva, c.mut_rva);
            u32 go = c.mut_gate_rva - newva_guess;
            memcpy(&secimg[go], g.data(), g.size());
        }
    }
    // state baytlari 0 (VM ilk calismada 1 yapar)

    u32 vmp_rva = 0;
    u32 chars = 0xE0000060u;   // CNT_CODE|MEM_EXEC|MEM_READ|MEM_WRITE
    if (!pe.add_section(".vmp0", secimg, chars, vmp_rva)) { L("[HATA] section eklenemedi"); return 1; }
    snprintf(b, sizeof b, "[SECTION] .vmp0 RVA=0x%06X boyut=0x%06X | VM blob %dB | vm_entry RVA=0x%06X",
             vmp_rva, (u32)secimg.size(), blob_len, vmp_rva + (pe.is64 ? VM_BLOB64_ENTRY_OFF : VM_BLOBX86_ENTRY_OFF));
    L(b);
    if (vmp_rva != newva_guess) L("[UYARI] section RVA beklentiyle farkli!");

    // --- .text yamalama ---
    for (auto& c : comps) {
        FnInfo& f = *c.f;
        bool okraw; u32 raw = pe.rva2raw(f.rva, &okraw);
        if (!okraw) { f.note += " | yama raw yok"; continue; }
        if (c.ty == 1) {
            // MUTASYON: giris kapisi E9 -> .vmp0'taki (runtime kapisi +)
            // mutasyonlu govde. Govde native x86/x64 kodu olarak calisir
            // (VM YOK, tam hiz); rt aciksa once bir-kez butunluk kontrolu.
            i32 rel = (i32)((rt_any ? c.mut_gate_rva : c.mut_rva) - (f.rva + 5));
            u8 j[5] = { 0xE9, (u8)(u32)rel, (u8)((u32)rel >> 8), (u8)((u32)rel >> 16), (u8)((u32)rel >> 24) };
            memcpy(&pe.buf[raw], j, 5);
            for (u32 i = 5; i < f.size; i++) pe.buf[raw + i] = 0xCC;
            f.virtualized = true;
            snprintf(b, sizeof b, "[MUT] %s @RVA=0x%06X boyut=0x%X | ikame=%u junk=%u kapi=%u (blok=%u) | %uB->%uB (x%.2f) | govde=0x%06X",
                     f.name.c_str(), f.rva, f.size,
                     c.mut.st.subst, c.mut.st.junk, c.mut.st.gates, c.mut.st.nblocks,
                     c.mut.st.orig_bytes, c.mut.st.new_bytes,
                     c.mut.st.orig_bytes ? (double)c.mut.st.new_bytes / (double)c.mut.st.orig_bytes : 0.0,
                     c.mut_rva);
            L(b);
            for (auto& n : c.mut.notes) L(n);
            continue;
        }
        if (c.tramp) {
            i32 rel = (i32)(c.stub_rva - (f.rva + 5));
            u8 j[5] = { 0xE9, (u8)(u32)rel, (u8)((u32)rel >> 8), (u8)((u32)rel >> 16), (u8)((u32)rel >> 24) };
            memcpy(&pe.buf[raw], j, 5);
            for (u32 i = 5; i < f.size; i++) pe.buf[raw + i] = 0xCC;
        } else {
            // YERINDE stub: stub_rva = fonksiyonun kendi RVA'si olacak sekilde uret
            u32 vent = vmp_rva + (pe.is64 ? VM_BLOB64_ENTRY_OFF : VM_BLOBX86_ENTRY_OFF);
            std::vector<u8> st;
            bool isreg3 = sdk_rva.count(f.rva) != 0;
            u32 cont3 = isreg3 ? (f.rva + f.size) : 0;
            if (pe.is64) st = build_stub_x64(f.rva, vent, c.key, c.bc_rva, (u32)c.plain.size(),
                                             rt_any ? xrt_entry_rva : 0, rt_any ? cfg_rva : 0, cont3);
            else         st = build_stub_x86(f.rva, vent, c.key, c.bc_rva, (u32)c.plain.size(), c.v.retimm,
                                             rt_any ? xrt_entry_rva : 0, rt_any ? cfg_rva : 0, cont3);
            memcpy(&pe.buf[raw], st.data(), st.size());
            for (u32 i = (u32)st.size(); i < f.size; i++) pe.buf[raw + i] = 0xCC;
        }
        f.virtualized = true;
        snprintf(b, sizeof b, "[YAMA] %s @RVA=0x%06X boyut=0x%X | bc=%uB key=0x%llX | stubRVA=0x%06X retimm=%u %s",
                 f.name.c_str(), f.rva, f.size, (u32)c.enc.size(),
                 (unsigned long long)c.key, c.stub_rva, c.v.retimm,
                 c.tramp ? "(trampoline)" : "(yerinde)");
        L(b);
        if (c.ty == 2 && c.mut.ok) {
            snprintf(b, sizeof b, "  [ULTRA] on-mutasyon: ikame=%u junk=%u kapi=%u | %uB->%uB (x%.2f)",
                     c.mut.st.subst, c.mut.st.junk, c.mut.st.gates,
                     c.mut.st.orig_bytes, c.mut.st.new_bytes,
                     c.mut.st.orig_bytes ? (double)c.mut.st.new_bytes / (double)c.mut.st.orig_bytes : 0.0);
            L(b);
        }
        for (auto& n : c.v.notes) L(n);
    }

    if (nM && pe.is64)
        L("[MUT] Not: x64 .pdata unwind kayitlari eski govde araligina isaret eder "
          "(mutasyonlu fonksiyonlarda istisna isleme kapali — VMProtect davranisi)");

    // --- BUGFIX #13: ezilen bolgelerin eski reloc girdilerini temizle ---
    // Yerinde stub + trampoline .text yamasi fonksiyonun TUM govdesini
    // eziyor (stub + int3). Orijinal koda ait HIGHLOW girdileri bu
    // baytlarin uzerinde kalirsa gercek Windows ASLR (DYNAMICBASE) loader
    // tarafindan +delta ile yamalanir -> stub immediateleri (VM anahtari!)
    // ve E9 rel32 bozulur -> ilk VM cagrisinda cokme. Wine preferred-base
    // yukledigi icin (delta=0) bu hata wine'da gorunmezdi.
    {
        std::vector<std::pair<u32,u32>> ranges;
        for (auto& c : comps)
            if (c.f->virtualized) ranges.push_back({ c.f->rva, c.f->size });
        u32 removed = 0; std::string rnote;
        if (pe.filter_relocs(ranges, removed, rnote)) L("[RELOC] " + rnote);
        else L("[HATA] reloc filtreleme: " + rnote);
    }

    // --- secenek bayraklari ---
    if ((opt.memprot && text) || (opt.strenc && rdata)) {
        u32 fh = pe.e_lfanew + 4;
        u16 optsize = 0; memcpy(&optsize, &pe.buf[fh + 16], 2);
        u32 sh = fh + 20 + optsize;
        for (u32 i = 0; i < pe.secs.size(); i++) {
            u32 o = sh + i * 40;
            char nm[9]; memcpy(nm, &pe.buf[o], 8); nm[8] = 0;
            if (opt.memprot && strcmp(nm, ".text") == 0) {
                u32 ch = text->chars & ~0x80000000u;   // WRITE kaldir -> EXECUTE_READ
                memcpy(&pe.buf[o + 36], &ch, 4);
                snprintf(b, sizeof b, "[MEMPROT] .text Chars=0x%08X (yazilamaz)", ch);
                L(b);
            }
            if (opt.strenc && strcmp(nm, ".rdata") == 0) {
                u32 ch = rdata->chars | 0x80000000u;   // cozum icin yazma
                memcpy(&pe.buf[o + 36], &ch, 4);
                snprintf(b, sizeof b, "[STRENC] .rdata Chars=0x%08X (yazilabilir)", ch);
                L(b);
            }
        }
    }

    // ============================================================
    // 0.5.0/0.6.0 — XRT butunlik degerleri + paketleme (SIRA KRITIK):
    //   1) reloc dizini + self CRC + text CRC  -> PRE-PACK .text baytlari
    //      (runtime acilmis bellek uzerinden hesaplar; sikistirilmis
    //       dosya uzerinden hesaplansaydi hicbir zaman eslesmezdi)
    //   2) 0.6.0 cpPack + cpStripFixups + cpStripDebugInfo
    //      (dosya compaction: file CRC'nin final dosya uzerinden
    //       hesaplanmasi icin cfg yazimindan once olmali)
    //   3) file CRC (final dosya) + cfg yazimi (0x48: pack_rva dahil)
    // NOT: add_section push_back secs vector'unu realloc eder -> pack
    // sonrasi text/rdata isaretcileri secbyname ile TAZELENIR.
    // ============================================================
    u32 xr_reloc_rva = 0, xr_reloc_sz = 0;
    u32 xr_self_len = 0, xr_sc = 0, xr_tc = 0;
    if (rt_any) {
        u32 ddoff = pe.is64 ? 112 : 96;
        memcpy(&xr_reloc_rva, &pe.buf[pe.e_lfanew + 24 + ddoff + 40], 4);
        memcpy(&xr_reloc_sz,  &pe.buf[pe.e_lfanew + 24 + ddoff + 44], 4);
        // --- self CRC: vm blob + xrt kodu (cfg haric) ---
        xr_self_len = xrt_code_off + xrt_len;
        u32 c = 0xFFFFFFFFu;
        for (u32 i = 0; i < xr_self_len && i < secimg.size(); i++) c = xcrc_up(c, secimg[i]);
        xr_sc = ~c;
        // --- text CRC: sayfa sayfa, reloc yamalarini atlayarak (PRE-PACK) ---
        if (text && text->vsz) {
            bool okt; u32 traw = pe.rva2raw(text->va, &okt);
            const u8* rraw = 0;
            if (xr_reloc_rva && xr_reloc_sz) {
                bool okr; u32 rr = pe.rva2raw(xr_reloc_rva, &okr);
                if (okr && rr + xr_reloc_sz <= pe.buf.size()) rraw = &pe.buf[rr];
            }
            u32 c2 = 0xFFFFFFFFu;
            u8 flag[4096 + 16];
            for (u32 pg = 0; pg < text->vsz; pg += 0x1000) {
                u32 pgrva = text->va + pg;
                u32 plen = (text->vsz - pg < 0x1000) ? (text->vsz - pg) : 0x1000;
                for (u32 i = 0; i < plen + 8 && i < sizeof flag; i++) flag[i] = 0;
                if (rraw) {
                    u32 ro = 0;
                    while (ro + 8 <= xr_reloc_sz) {
                        u32 page_rva; memcpy(&page_rva, rraw + ro, 4);
                        u32 bsz;     memcpy(&bsz, rraw + ro + 4, 4);
                        if (bsz < 8 || ro + bsz > xr_reloc_sz) break;
                        if (page_rva == pgrva) {
                            for (u32 eo = 8; eo + 2 <= bsz; eo += 2) {
                                u16 e; memcpy(&e, rraw + ro + eo, 2);
                                u32 typ = (u32)(e >> 12);
                                u32 off = (u32)(e & 0xFFF);
                                u32 len = (typ == 3) ? 4 : (typ == 10 ? 8 : 0);
                                if (len && off < plen + 8)
                                    for (u32 i = 0; i < len && off + i < sizeof flag; i++)
                                        flag[off + i] = 1;
                            }
                        }
                        ro += bsz;
                    }
                }
                for (u32 i = 0; i < plen; i++) {
                    if (flag[i]) continue;
                    // 0.5.0 DUZELTME: ham-boyut kelepcesi — vsz > rawsz
                    // oldugunda yuklenen goruntude sonrasi SIFIRDIR.
                    u8 by = 0;
                    u32 off = pg + i;
                    if (okt && off < text->rawsz && traw + off < pe.buf.size())
                        by = pe.buf[traw + off];
                    c2 = xcrc_up(c2, by);
                }
            }
            xr_tc = ~c2;
        }
    }

    // ---------------- 0.6.0: cpPack + strip ----------------
    u32 pack_rva = 0;
    if (opt.pack) {
        std::string perr;
        int prc = do_pack(pe, cfg_rva, xrt_unpack_rva, log, pack_rva, perr);
        if (prc != 0) {
            L(std::string("[HATA] PACK: ") + perr);
            L("[HATA] Paketleme tamamlanamadi — cikti dosyasi YAZILMADI.");
            return 4;
        }
    }
    if (opt.strip_fixups) strip_fixups(pe, log);
    if (opt.strip_debug)  strip_debug(pe, log);
    text = pe.secbyname(".text");   // add_section realloc -> tazele
    rdata = pe.secbyname(".rdata");

    if (rt_any || opt.pack) {
        // 0.6.0: pack-only derlemede bile cfg YAZILMALI (xrt_unpack cfg
        // okur; magic yoksa unpack hic calismaz -> .text sikisik kalir).
        // --- file CRC: FINAL dosya (CheckSum alani + .vmp0 ham araligi atla) ---
        u32 cksum_off = pe.e_lfanew + 24 + 64;   // OptionalHeader.CheckSum
        u32 vraw0 = 0, vraw1 = 0;
        {
            const Section* vs = pe.secbyname_c(".vmp0");
            if (vs) { vraw0 = vs->rawoff; vraw1 = vs->rawoff + vs->rawsz; }
        }
        u32 fc = 0xFFFFFFFFu;
        for (u32 i = 0; i < pe.buf.size(); i++) {
            if (i >= cksum_off && i < cksum_off + 4) continue;
            if (i >= vraw0 && i < vraw1) continue;
            fc = xcrc_up(fc, pe.buf[i]);
        }
        fc = ~fc;
        // --- cfg'yi pe.buf icine yaz (0.6.0: 0x48, pack_rva dahil) ---
        bool okc2; u32 cfg_raw = pe.rva2raw(cfg_rva, &okc2);
        if (!okc2 || cfg_raw + 0x48 > pe.buf.size()) {
            L("[HATA] XRT cfg yerlesimi raw yok"); return 1;
        }
        u8 cfg[0x48]; memset(cfg, 0, sizeof cfg);
        u32 fl = 0;
        if (opt.rt_selfcrc) fl |= 0x01;
        if (opt.rt_textcrc) fl |= 0x02;
        if (opt.rt_filecrc) fl |= 0x04;
        if (opt.rt_msg)     fl |= 0x08;
        if (opt.rt_exit)    fl |= 0x10;
        auto cwr = [&](u32 off, u32 v) { memcpy(cfg + off, &v, 4); };
        cwr(0x00, 0x31545258u);                 // 'XRT1'
        cwr(0x04, fl);
        cwr(0x08, 0);                           // state: 0 (ilk cagrida kontrol)
        cwr(0x0C, vmp_rva);                     // self_rva (vm blob basi)
        cwr(0x10, xr_self_len);
        cwr(0x14, xr_sc);
        cwr(0x18, text ? text->va : 0);
        cwr(0x1C, text ? text->vsz : 0);
        cwr(0x20, xr_tc);
        cwr(0x24, xr_reloc_rva);
        cwr(0x28, xr_reloc_sz);
        cwr(0x2C, fc);
        cwr(0x30, vraw0);
        cwr(0x34, vraw1);
        cwr(0x38, cksum_off);
        cwr(0x3C, cfg_rva);
        cwr(0x40, pack_rva);                    // 0.6.0: XPK1 blok RVA (.vmp1)
        memcpy(&pe.buf[cfg_raw], cfg, 0x48);
        // ---- 0.6.1 SAHTE-BASARI KORUMASI ----
        // cfg yazımı (0x48B) bytecode/stub uzerine tasmamali. 0.6.0'da
        // rezerv 0x40 kaldi: son 8B (pack_rva=0 + reserved=0) ilk bc'nin
        // ilk 8 baytını eziyordu (metin2 ULTRA+loaderCRC = sessiz no-op).
        // Yazım SONRASI enc baytlarını diskten doğrula — tasma varsa
        // cikti YAZILMAZ (0.5.1 sahte-başarı koruması geleneği).
        for (auto& c2 : comps) {
            if (c2.ty == 1) continue;
            if ((u32)c2.enc.size() < 16) continue;
            bool okv; u32 braw2 = pe.rva2raw(c2.bc_rva, &okv);
            if (!okv || braw2 + 16 > pe.buf.size()) continue;
            if (memcmp(&pe.buf[braw2], c2.enc.data(), 16) != 0) {
                L("[HATA] XRT cfg yazımı bytecode üzerine taştı (0.6.0 rezerv bug) — ÇIKTI YAZILMADI");
                L("[HATA] bc RVA=0x" + hex32(c2.bc_rva) + " ilk 16B ezildi. Rezerv XCFG_SIZE_E=0x48 olmalı.");
                return 5;
            }
        }
        snprintf(b, sizeof b,
                 "[XRT] runtime katmani: flags=0x%X | self=0x%08X (%uB) | text=0x%08X (0x%X, reloc-atla %uB) | file=0x%08X (atla: cksum+%u, .vmp0 %u..%u) | pack=0x%X",
                 fl, xr_sc, xr_self_len, xr_tc, text ? text->vsz : 0, xr_reloc_sz, fc,
                 cksum_off, vraw0, vraw1, pack_rva);
        L(b);
        L(std::string("[XRT] xrt_entry=0x") + hex32(xrt_entry_rva) + " cfg=0x" + hex32(cfg_rva) +
          " | her korumali giris BIR KEZ kontrol eder (state kilidi); hata: " +
          (opt.rt_msg ? "MessageBoxA + " : "") + (opt.rt_exit ? "ExitProcess" : "ud2 zehir"));
    } else if (opt.iat_prot) {
        L("[XRT] yalniz IAT korumasi: xrt_resolve gecikmeli cozumleyici yerlesti (cfg kullanilmaz)");
    }

    /* 0.5.1 SAHTE-BASARI KORUMASI: secili fonksiyonlarin HICBIRI
    uygulanamadiysa cikti dosyasi HIC YAZILMAZ (0.5.0 sessiz "korunmus"
    kopya yaziyordu). rc=3 -> GUI uyari kutusu + CLI net hata. */
    if (comps.empty() && !opt.pack && !opt.strip_fixups && !opt.strip_debug) {
        L("[HATA] HICBIR FONKSIYON UYGULANAMADI - cikti dosyasi YAZILMADI.");
        L("[HATA] Nedenler yukarida [RED] satirlarinda.");
        return 3;
    }
    pe.fix_checksum();
    if (!pe.save(out)) { L("[HATA] kaydedilemedi: " + out); return 1; }
    snprintf(b, sizeof b, "[KAYIT] %s (%zu bayt)", out.c_str(), pe.buf.size());
    L(b);
    L("[OZET] tipler: V=" + std::to_string(nV) + " M=" + std::to_string(nM) + " U=" + std::to_string(nU)
      + (nUf ? " (U->V dusus=" + std::to_string(nUf) + ")" : "")
      + " | antidebug=" + (opt.antidebug ? "ACIK" : "kapali")
      + " | strenc=" + (opt.strenc ? "ACIK" : "kapali")
      + " | memprot=" + (opt.memprot ? "ACIK" : "kapali")
      + " | vmenc=" + (opt.vmenc ? "ACIK" : "KAPALI")
      + " | mutasyon-gucu=" + std::to_string(opt.mut_strength)
      + " | runtime=" + (rt_any ? std::string("ACIK(self=") + (opt.rt_selfcrc ? "1" : "0")
          + ",text=" + (opt.rt_textcrc ? "1" : "0") + ",file=" + (opt.rt_filecrc ? "1" : "0") + ")" : "kapali")
      + " | iat=" + (opt.iat_prot ? "ACIK(" + std::to_string(thunk_slots.size()) + " thunk)" : "kapali")
      + " | sdk=" + (opt.sdk_scan ? "ACIK" : "kapali")
      + " | pack=" + (opt.pack ? (std::string("ACIK(LZMA, XPK1=0x") + hex32(pack_rva) + ")") : std::string("kapali"))
      + " | stripfix=" + (opt.strip_fixups ? "ACIK" : "kapali")
      + " | stripdbg=" + (opt.strip_debug ? "ACIK" : "kapali"));
    return 0;
}
