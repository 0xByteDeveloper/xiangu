================================================================
 XProtect 0.2.0 — Win32 API UI (universalObfusPublicSrc GUI replikasi)
================================================================

XProtect, universalObfusPublicSrc (VMProtect 3.5.1 kaynak agaci)
referans alinarak gelistirilen C++ port koruma motorudur (CPlusPort).
Bu surumun mile tasi: VMProtect'in Qt GUI'sinin birebir Win32 API
muadili — Qt KUTUPHANESI YOK, saf user32/gdi32/comctl32/comdlg32.

----------------------------------------------------------------
 YENI: XProtectUI.exe (x64) + XProtectUI32.exe (x86)
----------------------------------------------------------------

Kaynak referansi: pub1/vmp/VMProtect/ (mainwindow.cc, function_dialog.cc,
settings_dialog.cc, watermark_dialog.cc, license_dialog.cc,
about_dialog.cc, progress_dialog.cc; etiketler langs/en.lng).

Birebir tasinan yapi:
- Menuler: File (Open/Save Project/Save Project As/Save Licenses As/
  Close/Recent/Exit), Edit (Undo/Redo/Cut/Copy/Paste/Delete/Search/
  Go To Address), Project (Add > Function/License/File/Folder,
  Export Key Pair, Import > License/Import Licenses from a Project
  File, Compile F9, Execute F5), Tools (Watermarks, Settings),
  Help (Contents, Home Page, About).
- Toolbar: Open, Save, Compile, Execute (acilir: Execute Original /
  Execute Protected / Parameters), Cut/Copy/Paste, Add Function,
  Go To, Templates, sagda proje filtre kutusu.
- Sol dikey sekme seridi (VMProtect'in radio seridi): Project /
  Functions / Details.
- Project agaci: hedef dosya + Functions + Licenses klasorleri,
  V/M/U ikonlari (sanallastirma/mutasyon/ultra).
- Functions listesi: Name | Type | Address | Size | Export (PDB'siz
  COFF + export taramasi — motorun list moduyla ayni yol).
- Details: PE bilgisi (Machine/ImageBase/EP/Subsystem/ASLR/DEP/CFG)
  + bolum tablosu.
- Ozellik izgarasi (property editor): Core Properties — core.h'daki
  cp* bitlerinin TAMAMI (Debug Mode, Crypt Values, Include Watermark,
  Runner CRC, Encrypt Registers, Strip Fixups, Pack the Output File,
  Import Protection, Check Debugger, Check Virtual Machine, Memory
  Protection, Resource Protection, Check Kernel Debugger, Strip Debug
  Information, Loader CRC, Encrypt Bytecode, Virtual Files, Internal
  Memory Protection, Loader). Function Properties: Compilation Type
  (Virtualization/Mutation/Ultra (M+V)), Lock To Serial Number,
  Excluded From Compilation, External Address, End of Function.
- Diyaloglar: Add Function/Go To Address (Adres + Functions/Options
  sekmeleri — function_dialog.cc birebir), Add License (license_
  dialog.cc alan seti: Customer Name/Email/Date/Order #/Comments +
  Serial Number Contents: Name/Email/Hardware ID/Expiration Date/
  Running Time Limit/Max Build Date/User Data), Export Key Pair
  (RSA + 1024..4096), Add Watermark (Name/Value/Generate), Settings
  (Language: English/Turkce + AutoSave Project After Compilation),
  About (edition v version + build + Unregistered Version).
- Ayraclar (splitter) suruklenebilir; yerlesim XProtectUI.ini'de
  saklanir; Recent files menuyude.

Motor entegrasyonu:
- Derle (F9): motor UI ICI NDE calisir (protect() worker thread'de;
  cplport_gui.cpp mimarisi). Cikti: <hedef>_vmp.exe.
- Secili yoksa "tum uygun fonksiyonlar" sorulur (--all davranisi).
- Secenek eslemesi: Check Debugger->antidebug, Crypt Values->strenc,
  Memory Protection->memprot, Encrypt Bytecode kapaliysa->novmenc.
- Execute: Orijinal/Korumali calistirma + Parameters diyalogu.
- Proje dosyasi: .xproj (hedef + secenekler + fonksiyonlar +
  filigranlar + lisanslar). AutoSave aciksa derleme sonrasi kayit.

Dogrulama (bu paket cikmadan once):
- x64: PE32+ 0x8664, import tablosu temiz
  (COMCTL32/COMDLG32/SHELL32/GDI32/USER32/KERNEL32/ucrt).
- x86: PE32 0x14C, ayni import seti.
- wine64 + Xvfb: XProtectUI.exe --selftest = "SELFTEST OK" (ana
  pencere + tum kontroller kurulur, 1.2 sn mesaj pompalama, EXIT 0).
  --open C:\Test.exe ile PE cozumleyici + proje modeli ayni oturumda
  dogrulandi. (wine32 sandbox siniri: x86 testi PE statik + kullanici
  Windows teyidi ile.)

----------------------------------------------------------------
 Kullanim (Windows)
----------------------------------------------------------------
1) XProtectUI.exe'yi acin, Open ile Test.exe (veya herhangi bir
   PDB'siz PE) secin — fonksiyon listesi otomatik cikar.
2) Functions sekmesinde fonksiyona cift tiklayin (veya Add Function)
   -> derleme turu secin (V/M/U).
3) Details/Core Properties'ten koruma seceneklerini isaretleyin.
4) F9 (Compile) -> <ad>_vmp.exe uretilir; Log panelinde motor ciktisi.
5) Execute > Execute Protected ile korumalioyu calistirin.

----------------------------------------------------------------
 Paket icerigi
----------------------------------------------------------------
- XProtectUI.exe / XProtectUI32.exe ........ yeni Win32 UI (x64/x86)
- CPlusPort.exe / CPlusPort32.exe .......... 0.1.0 motor GUI'si
- Test.exe, Test32.exe ..................... MiniPac oyun (x64/x86)
- Test_vmp.exe, Test32_vmp.exe ............. korumali ciktilar (0.1.0)
- VMPHelper.exe ............................ canli analiz araci v1.3
- XProtectUI_Source/ ....................... UI tam kaynak + build_ui.sh
- CPlusPort_Source/, Test_exe_Source/,
  VMPHelper_Source/ ........................ 0.1.0 kaynaklari
- tools/ ................................... sandbox wine test yardimcilari
  (nssetup.c + wrun_gui2.sh — wine64+Xvfb selftest ortami)

Bilinen sinirlar (0.2.0):
- Add File / Add Folder / Templates / Export Key Pair uretimi / Import
  License motor tarafi henuz port edilmedi (UI yuzeyi hazir, "not
  ported yet" mesaji verir) — siradaki katman portlarinda acilacak.
- Lisans alanlari .xproj'da saklanir; RSA anahtar uretimi ve seri
  numarasi uretimi 0.3+ planindadir.
- Undo/Redo tek-seviye degil, 50 adim yiginidir (fonksiyon ekle/sil).
