#!/bin/sh
# wrun_gui2.sh — wine64 GUI runner (chroot'suz; nssetup C yardimcisi ile mount)
exec unshare -Ur --mount /tmp/nssetup "$@"
