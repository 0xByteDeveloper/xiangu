#!/bin/sh
# wrun_z.sh — wine64 runner (wrun'un z: drive'li varyanti; unix yollari Z:\ altina baglanir)
WROOT=/tmp/my-project/wine-root
P=/tmp/my-project/wineprefix
exec unshare -Ur --mount /bin/sh -c '
WROOT=/tmp/my-project/wine-root
P=/tmp/my-project/wineprefix
mkdir -p $WROOT/lib64 $WROOT/lib/x86_64-linux-gnu $WROOT/tmp $WROOT/dev $WROOT/proc $WROOT/home/z/my-project $WROOT/etc
mount --rbind /lib64 $WROOT/lib64
mount --rbind /lib/x86_64-linux-gnu $WROOT/lib/x86_64-linux-gnu
mount --rbind /tmp $WROOT/tmp
mount --rbind /dev $WROOT/dev
mount --rbind /proc $WROOT/proc
mount --rbind /home/z/my-project $WROOT/home/z/my-project
mount --rbind /etc $WROOT/etc
mkdir -p "$P/dosdevices/c:" "$P/dosdevices/z:"
mount --rbind "$P/drive_c" "$P/dosdevices/c:"
mount --rbind / "$P/dosdevices/z:"
export WINEPREFIX=/tmp/my-project/wineprefix
export WINEDLLOVERRIDES="mscoree,mshtml="
export LD_LIBRARY_PATH=/usr/lib/x86_64-linux-gnu:/lib32:/usr/lib/i386-linux-gnu
exec chroot $WROOT /usr/lib/wine/wine64 "$@"
' wrunz "$@"
