// nssetup.c — namespace icinde tum bind'leri yapip wine64'u exec'ler
// Sira KRITIK: /usr takas -> host lib64+lib -> wine builtin dizini geri ->
// X11/fonts. ld-linux'un goreli symlinki ../lib/... uzerinden cozulur.
#include <sys/mount.h>
#include <sys/stat.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

#include <errno.h>
static void mm(const char* s, const char* t) {
    if (mount(s, t, NULL, MS_BIND | MS_REC, NULL) != 0) {
        fprintf(stderr, "nssetup: bind %s -> %s BASARISIZ errno=%d (%s)\n", s, t, errno, strerror(errno));
        _exit(3);
    }
}
int main(int argc, char** argv) {
    mkdir("/tmp/hostusr", 0755);
    mm("/usr", "/tmp/hostusr");
    mm("/tmp/my-project/wine-root/usr", "/usr");
    mm("/tmp/hostusr/lib64", "/usr/lib64");
    // ld-linux dosya-bind: goreli symlink ../lib/... uzerinden wine agacindaki
    // placeholder'a dusar; host ld'yi uzerine bagliyoruz
    mm("/tmp/hostusr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2",
       "/usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2");
    mm("/tmp/hostusr/share/X11", "/usr/share/X11");
    mm("/tmp/hostusr/share/fonts", "/usr/share/fonts");
    setenv("WINEPREFIX", "/tmp/my-project/wineprefix", 1);
    setenv("HOME", "/tmp/my-project/wineprefix", 1);
    setenv("WINEDLLOVERRIDES", "mscoree,mshtml=", 1);
    setenv("LD_LIBRARY_PATH", "/tmp/hostusr/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu", 1);
    setenv("WINESERVER", "/usr/lib/wine/wineserver64", 1);
    // argv kaydir: argv[0]=wine64 yap
    char** av = (char**)calloc((size_t)argc + 1, sizeof(char*));
    av[0] = (char*)"wine64";
    for (int i = 1; i < argc; i++) av[i] = argv[i];
    execv("/usr/lib/wine/wine64", av);
    perror("nssetup: exec wine64");
    return 4;
}
