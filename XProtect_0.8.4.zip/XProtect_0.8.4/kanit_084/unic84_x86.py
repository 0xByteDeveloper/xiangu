#!/usr/bin/env python3
# unic84_x86.py — 0.8.4 x86 ANTIDBG (K1 KAPI-0xCC + K2 TF) Unicorn matrisi.
# Blob: gercek vmx86.bin (vm_core.c -> ld flat, Ttext=0x100000).
# K1/K2 hic API cozumlemedigi icin sahte Dunya yalniz PEB + imaj + yigin.
# Senaryolar:
#   clean     -> done=1, eax=korunmamis (42-benzeri TEMIZ)
#   kapicc    -> giris 0xCC (CE yazilim-kirici ARMALI)  -> POISON
#   beingdbg  -> PEB.BeingDebugged=1                    -> POISON
#   ntglobal  -> PEB.NtGlobalFlag 0x70                  -> POISON
#   tf        -> TF=1 aninda (debugger tek-adim izliyor)-> POISON
import struct, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.x86_const import *

M1 = 0x9E3779B97F4A7C15
M2 = 0x2545F4914F6CDD1D
M3 = 0xD1B54A32D192ED03
M4 = 0x94D049BB133111EB
M5 = 0x100000001B3
R1 = 0x51ED270B4C5A3D0F
M64 = (1 << 64) - 1
VM_OPN = 0x2C
OP_ANTIDBG = 0x1E
OP_RET = 0x1A

BLOB = 0x00100000
IMG = 0x00400000
STK = 0x7F000000
STKSZ = 0x100000
PEB = 0x7E100000
CTX = 0x03100000
SCRATCH = 0x03110000
SENTINEL = 0x031F0000
FN_RVA = 0xD7610

def rol_key(k):
    return ((k * M5) & M64) ^ (k >> 23) ^ R1

def vm_ks(key, pos):
    a = (((key ^ ((pos * M1) & M64)) * M2) & M64) + M1 & M64
    b = ((rol_key(key)) ^ (((pos >> 3) * M3) & M64)) * M4 & M64
    return ((a ^ b) >> 56) & 0xFF

def vm_ksc(key, prev, pos):
    return vm_ks(key ^ ((prev * M2) & M64), pos)

def vm_keyxor(rva, ln):
    x = (0x5850424D ^ ((rva & 0xFFFFFFFF) << 32) ^ (ln & 0xFFFFFFFF)) & M64
    x ^= x >> 30; x = (x * 0xBF58476D1CE4E5B9) & M64
    x ^= x >> 27; x = (x * M4) & M64; x ^= x >> 31
    return x

def perm_p(seed):
    p = list(range(VM_OPN))
    z = ((seed ^ 0x5850424D9E3779B9) & M64) | 1
    for i in range(VM_OPN - 1, 0, -1):
        z ^= z >> 30; z = (z * 0xBF58476D1CE4E5B9) & M64
        z ^= z >> 27; z = (z * M4) & M64; z ^= z >> 31
        j = (z >> 32) % (i + 1)
        p[i], p[j] = p[j], p[i]
    return p

def find_offsets(blob):
    fs_sites = []
    i = 0
    pat = b'\x64\xA1\x30\x00\x00\x00'
    while True:
        i = blob.find(pat, i)
        if i < 0: break
        fs_sites.append(i)
        i += 1
    k2_site = -1
    for s in fs_sites:
        j = blob.find(b'\x9C\x58', s, s + 0x80)   # pushfl; popl %eax
        if j >= 0:
            k2_site = j
            break
    return fs_sites, k2_site

def run_scenario(blob, sc, off_vm_entry, verbose=False):
    mu = Uc(UC_ARCH_X86, UC_MODE_32)
    for a, sz in [(BLOB, 0x40000), (IMG, 0x600000), (STK, STKSZ),
                  (PEB, 0x1000), (CTX, 0x1000), (SCRATCH, 0x1000),
                  (SENTINEL, 0x1000)]:
        mu.mem_map(a, sz)
    mu.mem_write(BLOB, blob)
    fs_sites, k2_site = find_offsets(blob)
    assert fs_sites, 'fs:0x30 sitesi yok'
    assert k2_site >= 0, 'K2 pushfl yok'

    mu.mem_write(PEB + 2, struct.pack('<B', sc.get('beingdbg', 0)))
    mu.mem_write(PEB + 0x68, struct.pack('<I', sc.get('ntglobal', 0)))

    # oyun imaji: orijinal fonksiyon giris bayti (E9 tramp / 0xCC kirici)
    mu.mem_write(IMG + FN_RVA, b'\xCC' if sc.get('kapicc') else b'\xE9')

    # sentetik bytecode: [ANTIDBG][RET] (perm + CFB, etkin anahtar 0)
    p = perm_p(FN_RVA)
    bc_rva = 0x545BC8
    bc_len = 8
    plain = bytes([p.index(OP_ANTIDBG), p.index(OP_RET), 0x90, 0x90, 0x90, 0x90, 0x90, 0x90])
    enc = bytearray()
    prev = 0
    for i, b in enumerate(plain):
        c = b ^ vm_ksc(0, prev, i)
        enc.append(c)
        prev = c
    mu.mem_write(IMG + bc_rva, bytes(enc))
    key = vm_keyxor(bc_rva, bc_len)

    mu.mem_write(CTX + 0x00, struct.pack('<I', IMG + bc_rva))
    mu.mem_write(CTX + 0x08, struct.pack('<I', bc_len))
    mu.mem_write(CTX + 0x10, struct.pack('<I', key & 0xFFFFFFFF))
    mu.mem_write(CTX + 0x14, struct.pack('<I', (key >> 32) & 0xFFFFFFFF))
    mu.mem_write(CTX + 0x18, struct.pack('<I', IMG))
    mu.mem_write(CTX + 0xA8, struct.pack('<I', SCRATCH))            # push_area
    mu.mem_write(SCRATCH + 28, struct.pack('<I', 0x11223344))       # push_area[7]=EAX
    mu.mem_write(CTX + 0xB0, struct.pack('<I', STK + STKSZ - 0x1000))  # init_rsp
    mu.mem_write(CTX + 0xE0, struct.pack('<I', FN_RVA))             # scratch[3]=seed

    def hook_code(mu, addr, size, ud):
        if addr in (BLOB + o for o in fs_sites):
            mu.reg_write(UC_X86_REG_EAX, PEB)
            mu.reg_write(UC_X86_REG_EIP, addr + 6)   # movl %fs:0x30,%eax atla
        elif addr == BLOB + k2_site and sc.get('tf', 0):
            # pushfl ONCESI TF=1 (debugger izliyor); pushfl bayrak imajini
            # yigina alir, #DB olmasin diye hemen ardindan TF temizlenir.
            efl = mu.reg_read(UC_X86_REG_EFLAGS)
            mu.reg_write(UC_X86_REG_EFLAGS, efl | 0x100)
            mu.reg_write(UC_X86_REG_EIP, addr + 1)   # pushfl (1B) calisti sayildi
            mu.reg_write(UC_X86_REG_ESP, mu.reg_read(UC_X86_REG_ESP) - 4)
            mu.mem_write(mu.reg_read(UC_X86_REG_ESP), struct.pack('<I', efl | 0x100))
            mu.reg_write(UC_X86_REG_EFLAGS, (efl | 0x100) & ~0x100)
    mu.hook_add(UC_HOOK_CODE, hook_code)
    if verbose:
        def mem_inv(mu, access, address, size, value, ud):
            print('  !! INVALID acc=%d addr=0x%08X eip=0x%08X' % (
                access, address, mu.reg_read(UC_X86_REG_EIP)))
            return False
        mu.hook_add(UC_HOOK_MEM_READ_UNMAPPED | UC_HOOK_MEM_WRITE_UNMAPPED
                    | UC_HOOK_MEM_FETCH_UNMAPPED, mem_inv)

    esp0 = STK + STKSZ - 0x2000
    mu.mem_write(esp0, struct.pack('<I', SENTINEL))
    mu.mem_write(esp0 + 4, struct.pack('<I', CTX))
    mu.reg_write(UC_X86_REG_ESP, esp0)
    try:
        mu.emu_start(BLOB + off_vm_entry, SENTINEL, timeout=10_000_000, count=1_000_000)
        err = 'OK'
    except UcError as e:
        err = 'UCERR %s eip=0x%X' % (e, mu.reg_read(UC_X86_REG_EIP))
    done = struct.unpack('<I', mu.mem_read(CTX + 0xC0, 4))[0]
    eax = struct.unpack('<I', mu.mem_read(CTX + 0x20, 4))[0]
    return done, eax, err

def main():
    blob = open('/home/z/my-project/scripts/xp081/XProtect/source/XProtectUI_Source/vmx86.bin', 'rb').read()
    off_vm_entry = 0xE80   # gen_blob.py ciktisi (x86)
    cases = [
        ('clean',    dict(),                              ('OK',   0x11223344)),
        ('kapicc',   dict(kapicc=1),                      ('OK',   0xDEADBEEF)),
        ('beingdbg', dict(beingdbg=1),                     ('OK',   0xDEADBEEF)),
        ('ntglobal', dict(ntglobal=0x70),                  ('OK',   0xDEADBEEF)),
        ('tf',       dict(tf=1),                          ('OK',   0xDEADBEEF)),
    ]
    ok = 0
    for name, sc, (want_err, want_eax) in cases:
        done, eax, err = run_scenario(blob, sc, off_vm_entry)
        good = (err == want_err and eax == want_eax and done == 1)
        print('%-9s done=%d eax=0x%08X %s -> %s' % (
            name, done, eax, err, 'TAMAM' if good else 'HATA'))
        ok += good
    print('SONUC: %d/%d' % (ok, len(cases)))
    return 0 if ok == len(cases) else 1

if __name__ == '__main__':
    sys.exit(main())
