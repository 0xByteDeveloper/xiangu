// test_veh84.c — 0.8.4 VEH debugger test gövdesi (x64+x86)
// Modlar:
//   clean   : VEH yok                      → damage() NORMAL (rc=42)
//   ceveh   : YABANCI VEH (VirtualAlloc sayfa — CE vehdebug taklidi)
//             tek-adımı YUTAR, bp yok      → DURDU (zehir; 0.8.4'te yeni)
//   gameveh : OYUN-VEH taklidi (handler ANA EXE içinde) tek-adımı yutar
//                                          → TEMİZ rc=42 (yanlış-pozitif YOK!)
//   gamedrx : gameveh + DR0=damage (oyun gözetim noktası taklidi)
//                                          → TEMİZ rc=42 (DRx tek başına karar değil)
//   sw      : yabancı VEH + damage girişine 0xCC (CE F5 yazılım-bp)
//                                          → DURDU
//   cevehdr : yabancı VEH + DR0=damage (CE donanım-bp)
//                                          → DURDU
//   tfstep  : oyun-VEH + TF kendiliinden-kur (tek-adim izleme taklidi)
//                                          → DURDU (K2)
//   peb     : PEB.BeingDebugged kendiliinden-yaz (Windows debugger yolu)
//                                          → DURDU (0.8.1 kanıtı)
// Çıktı: veh84_sonuc.txt + stdout. CORRECT=3812, POISON EAX=-559038737.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

static void*  g_veh   = NULL;
static void*  g_veh2  = NULL;
static BYTE*  g_bp    = NULL;
static BYTE   g_orig  = 0;
static int    g_tfkeep = 0;

/* ---- oyun-VEH taklidi (ANA EXE içinde derlenir) ----
   STATUS_SINGLE_STEP'i yutar (bazı oyun korumaları böyle yapar);
   BREAKPOINT'i (sw modu) CE gibi işler: baytı geri koy, TF kur, Eip=bp. */
static LONG CALLBACK game_sim_veh(void* expp) {
    void** ep = (void**)expp;
    unsigned char* rec = (unsigned char*)ep[0];
    void* ctx = ep[1];
    unsigned long code = *(unsigned long*)(rec + 0);
    void* addr = *(void**)(rec + 0x10);
    if (code == 0x80000003 && g_bp && addr == (void*)g_bp) {
        *g_bp = g_orig;
#if defined(_WIN64)
        *(unsigned long*)((char*)ctx + 0x44) |= 0x100;              /* EFlags TF */
        *(unsigned long long*)((char*)ctx + 0xF8) = (unsigned long long)g_bp; /* Rip */
#else
        *(unsigned long*)((char*)ctx + 0xC0) |= 0x100;              /* EFlags TF (dogru ofset!) */
        *(unsigned long*)((char*)ctx + 0xB8) = (unsigned long)g_bp; /* Eip */
#endif
        return -1;
    }
    if (code == 0x80000004) {
        if (g_bp) *g_bp = 0xCC;         /* bp'yi tek-adimda geri kur (CE gibi) */
#if defined(_WIN64)
        if (g_tfkeep) *(unsigned long*)((char*)ctx + 0x44) |= 0x100;
#else
        if (g_tfkeep) *(unsigned long*)((char*)ctx + 0xC0) |= 0x100;
#endif
        return -1;                      /* tek-adimi YUT (oyun koruma taklidi) */
    }
    return 0;
}

/* ---- YABANCI VEH (CE vehdebug taklidi): VirtualAlloc sayfasına yazılan
   makine kodu; yalnız STATUS_SINGLE_STEP'i yutar, gerisini geçirir.
   Global YOK (taşınabilir). ---- */
#if defined(_WIN64)
static const unsigned char FOR_STUB[] = {
    0x48,0x8B,0x01,                   /* mov rax,[rcx]         ; rec   */
    0x81,0x38,0x04,0x00,0x00,0x80,    /* cmp dword [rax],0x80000004    */
    0xB8,0x00,0x00,0x00,0x00,         /* mov eax,0                     */
    0x75,0x01,                        /* jne done                      */
    0xFF,0xC8,                        /* dec eax               ; -1    */
    0xC3                              /* done: ret                     */
};
#else
static const unsigned char FOR_STUB[] = {
    0x8B,0x44,0x24,0x04,              /* mov eax,[esp+4]       ; expp  */
    0x8B,0x00,                        /* mov eax,[eax]         ; rec   */
    0x81,0x38,0x04,0x00,0x00,0x80,    /* cmp dword [eax],0x80000004    */
    0xB8,0x00,0x00,0x00,0x00,         /* mov eax,0                     */
    0x75,0x01,                        /* jne done                      */
    0x48,                             /* dec eax               ; -1    */
    0xC2,0x04,0x00                    /* done: ret 4 (stdcall)         */
};
#endif

static void* add_foreign_swallow(void) {
    DWORD sz = sizeof(FOR_STUB);
    void* pg = VirtualAlloc(NULL, 0x1000, MEM_COMMIT | MEM_RESERVE,
                            PAGE_EXECUTE_READWRITE);
    if (!pg) return NULL;
    memcpy(pg, FOR_STUB, sz);
    return AddVectoredExceptionHandler(1, (PVECTORED_EXCEPTION_HANDLER)pg);
}

__attribute__((noinline)) static int damage(int a, int b) {
    __asm__ volatile(".byte 0x90,0x90,0xB8,0x5A,0x6B,0x7C,0x11");  /* iz */
    volatile int r = 0;
    r = a + b;
    r = r * 3 + 7;
    r = r ^ 0x55;
    r = r - b;
    return r;
}

static const char* OUTPATH =
#ifdef _WIN64
    "Z:\\home\\z\\my-project\\scripts\\xp081\\test\\veh84_sonuc64.txt";
#else
    "Z:\\home\\z\\my-project\\scripts\\xp081\\test\\veh84_sonuc32.txt";
#endif

int main(int argc, char** argv) {
    const char* mode = (argc > 1) ? argv[1] : "clean";
    int is_foreign = 0, is_game = 0, is_dr = 0, is_sw = 0, is_peb = 0, is_tf = 0;
    if      (!strcmp(mode, "ceveh"))   { is_foreign = 1; }
    else if (!strcmp(mode, "gameveh")) { is_game = 1; }
    else if (!strcmp(mode, "gamedrx")) { is_game = 1; is_dr = 1; }
    else if (!strcmp(mode, "sw"))      { is_foreign = 1; is_game = 1; is_sw = 1; }
    else if (!strcmp(mode, "cevehdr")) { is_foreign = 1; is_dr = 1; }
    else if (!strcmp(mode, "tfstep"))  { is_game = 1; is_tf = 1; }
    else if (!strcmp(mode, "peb"))     { is_peb = 1; }

    if (is_foreign) { g_veh = add_foreign_swallow(); }         /* CE: yabanci, kafa */
    if (is_game)    { g_veh2 = AddVectoredExceptionHandler(1, (PVECTORED_EXCEPTION_HANDLER)game_sim_veh); }
    if (is_sw) {
        g_bp = (BYTE*)damage;
        DWORD oldp = 0;
        VirtualProtect(g_bp, 16, PAGE_EXECUTE_READWRITE, &oldp);
        g_orig = *g_bp;
        *g_bp = 0xCC;                                          /* CE F5 */
    }
    if (is_dr) {
        CONTEXT c2; memset(&c2, 0, sizeof c2);
        c2.ContextFlags = CONTEXT_DEBUG_REGISTERS;
        GetThreadContext(GetCurrentThread(), &c2);
        c2.Dr0 = (DWORD_PTR)damage;
        c2.Dr7 = 1;
        SetThreadContext(GetCurrentThread(), &c2);
    }
    if (is_tf) { g_tfkeep = 1; }
    if (is_peb) {
#ifdef _WIN64
        unsigned long long peb2; __asm__ volatile("movq %%gs:0x60, %0" : "=r"(peb2));
#else
        unsigned int peb2; __asm__ volatile("movl %%fs:0x30, %0" : "=r"(peb2));
#endif
        *(unsigned char*)(peb2 + 2) = 1;
    }

    if (is_tf) {
#if defined(_WIN64)
        __asm__ volatile("pushfq\n\t orq $0x100, (%%rsp)\n\t popfq" :: : "cc", "memory");
#else
        __asm__ volatile("pushfl\n\t orl $0x100, (%%esp)\n\t popfl" :: : "cc", "memory");
#endif
    }
    int r = damage(1234, 77);
    if (is_tf) { g_tfkeep = 0; }

    unsigned long dr0 = 0;
    {
        CONTEXT c3; memset(&c3, 0, sizeof c3);
        c3.ContextFlags = CONTEXT_DEBUG_REGISTERS;
        if (GetThreadContext(GetCurrentThread(), &c3)) dr0 = (unsigned long)c3.Dr0;
    }
    FILE* f = fopen(OUTPATH, "w");
    if (f) { fprintf(f, "mode=%s r=%d dr0=%lu\n", mode, r, dr0); fclose(f); }
    printf("mode=%s r=%d dr0=%lu\n", mode, r, dr0);
    fflush(stdout);
    return (r == 3812) ? 42 : 1;
}
