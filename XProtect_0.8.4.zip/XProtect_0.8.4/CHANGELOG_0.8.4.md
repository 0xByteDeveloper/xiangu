# XProtect 0.8.4 — VEH debugger yakalama (0.8.1 tabani + 2 oyun-guvenli kontrol)

## Kok-neden arastirmasi (0.8.2/0.8.3 neden coktu?)

Kullanicinin kaniti: 0.8.2 temiz oyunda, 0.8.3 debugger acilinca cokuyordu.
Kok-neden (bu oturumda kanitlandi):

1. **0.8.2/0.8.3'un x86 CONTEXT ofsetleri YANLISTI**: `XA_CTX_EFLAGS=0xB8`
   (gercekte Eip!) ve `XA_CTX_RAX=0xA8` (gercekte Edx!). VEH isleyicisi
   TF'yi temizleyEMIYOR ve Eip'nin bit-8'ini sifirliyordu -> temiz surecte
   tek-adim istisnasi sonsuza kadar yeniden tetikleniyor / Eip bozuluyor
   -> oyun cagiricisi cokuyor. (winnt.h PE32 birebir: EFlags=0xC0, Eax=0xB0.)
2. **Istisna-dispatch'in yorumlayici cerceveleriyle carpismasi**: TF-probu
   VM yorumlayicisinin canli C cerceveleri arasinda istisna dispatch
   ediyordu; dispatch + wine ic cagrilari yorumlayici durumunu bozuyordu
   (s.ic/regs[RSP] vild deger -> wild write).
3. **Wine dogrulamasi**: yigin-degistirme veya yeni is-parcacigi uzerinden
   yapilan VEH baglam-yazimi wine'da YITIRILIYOR (tfprobe2 deneysel kaniti:
   ayni kod normal yiginda CLEAN-OK, degistirilmis yiginda mark=0).

## 0.8.4 tasarimi — istisna-dispatch'i hic devreye sokmayan iki kontrol

0.8.1 kodu birebir korundu; yalniz OP_ANTIDBG icine iki kontrol eklendi:

- **(K1) KAPI-0xCC**: korunan fonksiyonun ORIJINAL giris bayti (E9 tramp)
  okunur (stub scratch[3] = fonksiyon RVA'si). CE VEH debugger'in
  yazilim-kirici (F5/breakpoint) girise 0xCC yazar ve ARMALI birakir.
  Temiz oyunda o bayt hicbir zaman 0xCC olamaz -> 0xCC = kesin kanit.
  (UniversalObfuscator loader.cc:2120 0xCC-taramasinin XProtect'e ozel,
  yanlis-pozitifsiz formu: yalniz KENDI girisimiz taranir.)
- **(K2) TF-BAYRAGI**: pushfq ile anlik TF okunur. Bir debugger (CE VEH /
  Windows) fonksiyonu tek-adim izlerken TF=1'dir. Temiz oyunda ring3'te
  TF asla 1 kalmaz -> TF=1 = kesin kanit. (VMProtect loader.cc:2446
  TF-probunun istisnasiz formu.)

## Bilincli olarak YAPILMAYANLAR (0.8.2 yanlis-pozitif yuzeyleri)

- GetThreadContext DRx okumasi (oyun gozetim noktalari dolu olabilir)
- NtQueryInformationProcess (ProcessDebugPort/ObjectHandle)
- ntdll API 0xCC taramasi (oyun int3-hook'lari ile carpisir)
- PAGE_GUARD/NOACCESS probu
- Yabanci-VEH zincir gezinmesi (AV/crash-raporlayici VEH'leri yanlis-
  pozitif yapar; ayrica wine'da kayit-basina cozum kirilgan)

## Kanitlar (bu oturum)

- **x64 wine matrisi 8/8**: clean=42, gameveh(games own VEH swallows
  single-step)=42 TEMIZ, gamedrx(+DR0 watchpoint)=42 TEMIZ, cevehdr/
  ceveh(idle VEH)=42 TEMIZ; **sw(CE yazilim-bp)=ZEHIR 0xDEADBEEF**,
  **tfstep(debugger tek-adim izliyor)=ZEHIR**, **peb=ZEHIR**.
- **x86 Unicorn matrisi 5/5** (oyun mimarisi PE32): clean TEMIZ;
  kapicc/beingdbg/ntglobal/tf -> POISON.
- **R5 ULTIMATE rc=42** (0.8.1 ile bayt-bayt ayni cikti: a=57 b=0x16f9
  c=0xdb57 d=58); SELFTEST OK (0.8.1 ile ayni).
- **metin2 d7610 statik**: seed=0xD7610, bc_len=546,
  bc[0]=0x0A -> itab -> 0x1E=ANTIDBG.
- **BC ESDEGERLIGI**: 0.8.4'un metin2 d7610 bytecode'u, kullanicinin
  KENDI calisan 0.8.1 ciktisiyla (metin2client_vmp_ultra_checkdebugger.exe)
  **bayt-bayt AYNI** (len=546, tum akis) — tek fark VM blob'undaki K1/K2.
- Tamper parite: 0.8.1 ile ayni davranis.

## Paket

XProtect_0.8.4.zip: XProtectUI.exe (x64) + XProtectUI32.exe (x86) +
source/ + kanit_084/ + worklog.md. Surum: 0.8.4 (About/title).
