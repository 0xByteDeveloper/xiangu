XProtect 0.8.4 — VEH debugger yakalama (0.8.1 tabani)
=====================================================

Bu surum KULLANICI TALEBI UZERINE 0.8.1'den yeniden insa edildi:
0.8.2/0.8.3'un tum bataryasi ATILDI; yalniz VEH debugger yakalamasi
eklendi. 0.8.1'in temiz-oyun davranisi birebir korunur.

COZUM (iki oyun-guvenli kontrol, istisna-dispatch'siz):
  K1  Korunan fonksiyon girisinde 0xCC yazilim-kirici (CE VEH F5/bp)
  K2  TF bayragi = debugger su anda fonksiyonu tek-adim izliyor

KULLANIM: 0.8.1 ile ayni — XProtectUI'den fonksiyon sec, ULTRA,
  Check Debugger = Yes, Compile.

TEST MATRISI (kanit_084/):
  x64 wine 8/8  : clean/gameveh/gamedrx/ceveh/cevehdr TEMIZ;
                  sw/tfstep/peb ZEHIR (0xDEADBEEF)
  x86 Unicorn 5/5 (oyun mimarisi)
  metin2 d7610  : bc bayt-bayt 0.8.1 ciktisiyla AYNI (len=546)
  R5 ULTIMATE rc=42, SELFTEST OK

NOT: CE VEH debugger "bos bagli" (kirici/tek-adim yokken) bilincli
  olarak yakalanmaz — bos VEH kaniti AV/koruma yazilimlarinda da
  gorulur ve 0.8.2'nin temiz-oyun cokmesinin sebebiydi. Fonksiyona
  kirici konan/izleme YAPAN her VEH debugger yakalanir.
